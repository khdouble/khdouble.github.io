% Estimation of Specification Type 2. 
% It can implement both recursive and rolling estimation.  
clear
load Dataset02.mat;         % Call orginal data files.

% Parameter Setting -------------------------------------------------------
c = 1.96;                   % Critical Value for Bagging 
M = 50;                     % Boosting iteration
nburn = 100; nkeep = 1000;  % Loop for BMA
hmax = 12; pmax = 4;        % Setting for max horizon and max lag.
fmax = 4;                   % Maximum lags of factors
sp = 156;   rw = 156;       % Starting period of forecasting // Rolling windows size
intv = 20;                  % For interval of progress display.
xx = TrDataTr;              % Set explanatory data which are alread transformed. 
yy = TrYvarTr;              % Set dependant data which are alread transformed.

% Estimation On/Off Control -----------------------------------------------
% If method is 1, it's on. else if's off. 
mc = ones(1,13);            % All estimation are turned on. 
mc(2:6)=0;            % To prevent waste of time for doing same procedure.
disp(' ');disp('Starting Forecasting for FACTOR MODEL');disp(' ');
disp('Specification Type 2 : Estimation with Factors from selected variables from All Regressors')
disp(' ');rero = input('Select 1 for Recursive Model, 2 for Rolling Estimation Model - ');
if rero == 1;
    load betas_re.mat;
    load betas_re_sel.mat;
else 
    load betas_ro.mat;
    load betas_ro_sel.mat;
end

[ mx , nx ] = size(xx);[ my , ny ] = size(yy);

disp(' ');disp('Progress Report');disp(' ');

yhat_ar=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_bag=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_cbst=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_bma1=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_bma2=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_lars=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_en=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_nng=zeros(mx-sp-hmax-pmax+2,ny,4);

for mm = 1:1:7          
    % The following if phrases are for implementing each methods with
    % associated selected variables by each type of method. 
    if mm == 1
        mc(1) = 1;        mc(6) = 1;
    elseif mm == 2
        mc = zeros(1,13);
        mc(1) = 1;        mc(7) = 1;
    elseif mm == 3
        mc = zeros(1,13);
        mc(1) = 1;        mc(8) = 1;
    elseif mm == 4 
        mc = zeros(1,13);
        mc(1) = 1;        mc(9) = 1;
    elseif mm == 5 
        mc = zeros(1,13);
        mc(1) = 1;        mc(11) = 1;
    elseif mm == 6 
        mc = zeros(1,13);
        mc(1) = 1;        mc(12) = 1;
    elseif mm == 7 
        mc = zeros(1,13);
        mc(1) = 1;        mc(13) = 1;
    end
    
for j = 1 : 1 : ny
    y = yy(:,j);
    xx_ex = xx;
    xx_ex(:,YInd(j))=[];
    
    for i = 1 : 1 : mx-sp-hmax-pmax+2
        progtime3(mm,i,j,intv) % Progress Time Display.
        if rero == 1
            yyt = y(1:i+sp+hmax+pmax-2,:);        ylag = divlag(yyt,pmax+hmax-1);        
        else 
            yyt = y(i:i+sp+hmax+pmax-2,:);        ylag = divlag(yyt,pmax+hmax-1);        
        end
        y_tar  = ylag(:,1);    % y_tar is the target varialbe. (That is, Y(t+h))

        % Setting lagged variable of dependent variable -------------------
        [IC_tar,sel_tar]=ar_sel(y_tar);        seld = sel_tar(2);             %seld_all(i,j) = seld;
        y_lags_h1  = [ones(rows(ylag),1),ylag(:,2:2+seld-1)];        y_lags_h3  = [ones(rows(ylag),1),ylag(:,4:4+seld-1)];                    y_lags_h6  = [ones(rows(ylag),1),ylag(:,7:7+seld-1)];                    y_lags_h12 = [ones(rows(ylag),1),ylag(:,13:13+seld-1)];            
        if rero == 1 
            xx_h1  = xx(pmax+hmax-fmax-0 :pmax+hmax-1+i+sp-1,:);
            xx_h3  = xx(pmax+hmax-fmax-2 :pmax+hmax-1+i+sp-3,:);
            xx_h6  = xx(pmax+hmax-fmax-5 :pmax+hmax-1+i+sp-6,:);
            xx_h12 = xx(pmax+hmax-fmax-11:pmax+hmax-1+i+sp-12,:);
            xx_ex_h1  = xx_ex(pmax+hmax-fmax+1-1:pmax+hmax-1+i+sp-1,:); 
            xx_ex_h3  = xx_ex(pmax+hmax-fmax+1-3:pmax+hmax-1+i+sp-3,:);
            xx_ex_h6  = xx_ex(pmax+hmax-fmax+1-6:pmax+hmax-1+i+sp-6,:);
            xx_ex_h12 = xx_ex(pmax+hmax-fmax+1-12:pmax+hmax-1+i+sp-12,:);
        else
            xx_h1  = xx(pmax+hmax-fmax-0+(i-1) :pmax+hmax-1+i+sp-1,:);
            xx_h3  = xx(pmax+hmax-fmax-2+(i-1) :pmax+hmax-1+i+sp-3,:);
            xx_h6  = xx(pmax+hmax-fmax-5+(i-1) :pmax+hmax-1+i+sp-6,:);
            xx_h12 = xx(pmax+hmax-fmax-11+(i-1):pmax+hmax-1+i+sp-12,:);
            xx_ex_h1  = xx_ex(pmax+hmax-fmax+1-1+(i-1):pmax+hmax-1+i+sp-1,:); 
            xx_ex_h3  = xx_ex(pmax+hmax-fmax+1-3+(i-1):pmax+hmax-1+i+sp-3,:);
            xx_ex_h6  = xx_ex(pmax+hmax-fmax+1-6+(i-1):pmax+hmax-1+i+sp-6,:);
            xx_ex_h12 = xx_ex(pmax+hmax-fmax+1-12+(i-1):pmax+hmax-1+i+sp-12,:);
            end
        %if rero == 1
        %    xx_h1  = xx(pmax+hmax-1:pmax+hmax-1+i+sp-1,:);        xx_h3  = xx(pmax+hmax-3:pmax+hmax-1+i+sp-3,:);        xx_h6  = xx(pmax+hmax-6:pmax+hmax-1+i+sp-6,:);        xx_h12 = xx(pmax+hmax-12:pmax+hmax-1+i+sp-12,:);
        %    xx_ex_h1  = xx_ex(pmax+hmax-1:pmax+hmax-1+i+sp-1,:);         xx_ex_h3  = xx_ex(pmax+hmax-3:pmax+hmax-1+i+sp-3,:);        xx_ex_h6  = xx_ex(pmax+hmax-6:pmax+hmax-1+i+sp-6,:);        xx_ex_h12 = xx_ex(pmax+hmax-12:pmax+hmax-1+i+sp-12,:);
        %else
        %    xx_h1  = xx(pmax+hmax-1+(i-1):pmax+hmax-1+i+sp-1,:);        xx_h3  = xx(pmax+hmax-3+(i-1):pmax+hmax-1+i+sp-3,:);        xx_h6  = xx(pmax+hmax-6+(i-1):pmax+hmax-1+i+sp-6,:);        xx_h12 = xx(pmax+hmax-12+(i-1):pmax+hmax-1+i+sp-12,:);
        %    xx_ex_h1  = xx_ex(pmax+hmax-1+(i-1):pmax+hmax-1+i+sp-1,:);         xx_ex_h3  = xx_ex(pmax+hmax-3+(i-1):pmax+hmax-1+i+sp-3,:);        xx_ex_h6  = xx_ex(pmax+hmax-6+(i-1):pmax+hmax-1+i+sp-6,:);        xx_ex_h12 = xx_ex(pmax+hmax-12+(i-1):pmax+hmax-1+i+sp-12,:);
        %end
            xx_sel_h1 = xx_h1(:,find(betas_sel(:,i,j,mm,1)==1)');
            xx_sel_h3 = xx_h3(:,find(betas_sel(:,i,j,mm,2)==1)');
            xx_sel_h6 = xx_h6(:,find(betas_sel(:,i,j,mm,3)==1)');        
            xx_sel_h12= xx_h12(:,find(betas_sel(:,i,j,mm,4)==1)');     
        
        if sum(betas_sel(:,i,j,mm,1))==0
            xx_sel_h1 = xx_h1(:,find(betas_sel(:,i+1,j,mm,1)==1)');
        end
        if sum(betas_sel(:,i,j,mm,2))==0
            xx_sel_h3 = xx_h3(:,find(betas_sel(:,i+1,j,mm,2)==1)');
        end
        if sum(betas_sel(:,i,j,mm,3))==0
            xx_sel_h6 = xx_h6(:,find(betas_sel(:,i+1,j,mm,3)==1)');
        end
        if sum(betas_sel(:,i,j,mm,4))==0
            xx_sel_h12 = xx_h12(:,find(betas_sel(:,i+1,j,mm,4)==1)');
        end
        betas_sel_ex=betas_sel;
        betas_sel_ex(YInd(j),i,j,mm,:)=0;
        xx_sel_ex_h1 = xx_ex_h1(:,find(betas_sel_ex(:,i,j,mm,1)==1)');
        xx_sel_ex_h3 = xx_ex_h3(:,find(betas_sel_ex(:,i,j,mm,2)==1)');
        xx_sel_ex_h6 = xx_ex_h6(:,find(betas_sel_ex(:,i,j,mm,3)==1)');        
        xx_sel_ex_h12= xx_ex_h12(:,find(betas_sel_ex(:,i,j,mm,4)==1)');     
        
        %if sum(betas_sel(:,i,j,mm,1))==0
        %    xx_sel_ex_h1 = xx_h1(:,find(betas_sel_ex(:,i+1,j,mm,1)==1)');
        %end
        %if sum(betas_sel(:,i,j,mm,2))==0
        %    xx_sel_ex_h3 = xx_h3(:,find(betas_sel_ex(:,i+1,j,mm,2)==1)');
        %end
        %if sum(betas_sel(:,i,j,mm,3))==0
        %    xx_sel_ex_h6 = xx_h6(:,find(betas_sel_ex(:,i+1,j,mm,3)==1)');
        %end
        %if sum(betas_sel(:,i,j,mm,4))==0
        %    xx_sel_ex_h12 = xx_h12(:,find(betas_sel_ex(:,i+1,j,mm,4)==1)');
        %end              
        % Flexible Model setup --------------------------------------------
        % If number of selected variables are small, we estimate with original variables. 
        if cols(xx_sel_h1)>=20       
           [icasig_h1, A_h1, W_h1] = fastica2(xx_sel_h1','verbose','off');
           if isempty(W_h1)
               [icasig_h1, A_h1, W_h1] = fastica2(xx_h1','verbose','off');
               SCORE1 = xx_h1*W_h1';
           else
               SCORE1 = xx_sel_h1*W_h1';
           end
           n_fac_h1 = rows(W_h1);
        elseif cols(xx_sel_ex_h1)>0&cols(xx_sel_ex_h1)<20
           SCORE1 = xx_sel_ex_h1;
           n_fac_h1  = cols(xx_sel_ex_h1); 
        elseif cols(xx_sel_ex_h1)==0
           [icasig_h1, A_h1, W_h1] = fastica2(xx_h1','verbose','off');
           n_fac_h1 = rows(W_h1);
           SCORE1 = xx_h1*W_h1';
        end
        for k=1:1:cols(SCORE1)
            fac_lags1(:,(k-1)*fmax+1:k*fmax) = divlag(SCORE1(:,k),fmax-1);
        end
        fac1 = fac_lags1(1:end-1,1:n_fac_h1*fmax);
        xvar_h1  = [y_lags_h1,fac1];
        predx_h1  = [ones(1,1),ylag(end,1 :1+seld-1 ),fac_lags1( end,1:n_fac_h1 *fmax)];
        predx_fac1 = fac_lags1(end,1:n_fac_h1*fmax);
        clear SCORE1 matLoads1 fac_lags1
        
        if cols(xx_sel_h3)>=20       
           [icasig_h3, A_h3, W_h3] = fastica2(xx_sel_h3','verbose','off');
           if isempty(W_h3)
               [icasig_h3, A_h3, W_h3] = fastica2(xx_h3','verbose','off');
               SCORE3 = xx_h3*W_h3';
           else
               SCORE3 = xx_sel_h3*W_h3';
           end
           n_fac_h3 = rows(W_h3);
        elseif cols(xx_sel_ex_h3)>0&cols(xx_sel_ex_h3)<20
           SCORE3 = xx_sel_ex_h3;
           n_fac_h3  = cols(xx_sel_ex_h3); 
        elseif cols(xx_sel_ex_h3)==0
           [icasig_h3, A_h3, W_h3] = fastica2(xx_h3','verbose','off');
           n_fac_h3 = rows(W_h3);
           SCORE3 = xx_h3*W_h3';
        end
        for k=1:1:cols(SCORE3)
           fac_lags3(:,(k-1)*fmax+1:k*fmax) = divlag(SCORE3(:,k),fmax-1);
        end
        fac3 = fac_lags3(1:end-1,1:n_fac_h3*fmax);
        xvar_h3  = [y_lags_h3,fac3];
        predx_h3  = [ones(1,1),ylag(end,3 :3+seld-1 ),fac_lags3( end,1:n_fac_h3 *fmax)];           
        predx_fac3 = fac_lags3(end,1:n_fac_h3*fmax);
        clear SCORE3 matLoads3 fac_lags3
        
        if cols(xx_sel_h6)>=20       
           [icasig_h6, A_h6, W_h6] = fastica2(xx_sel_h6','verbose','off');
           if isempty(W_h6)
               [icasig_h6, A_h6, W_h6] = fastica2(xx_h6','verbose','off');
               SCORE6 = xx_h6*W_h6';
           else
               SCORE6 = xx_sel_h6*W_h6';
           end
           n_fac_h6 = rows(W_h6);
        elseif cols(xx_sel_ex_h6)>0&cols(xx_sel_ex_h6)<20
           SCORE6 = xx_sel_ex_h6;
           n_fac_h6  = cols(xx_sel_ex_h6); 
        elseif cols(xx_sel_ex_h6)==0
           [icasig_h6, A_h6, W_h6] = fastica2(xx_h6','verbose','off');
           n_fac_h6 = rows(W_h6);
           SCORE6 = xx_h6*W_h6';
        end 
        for k=1:1:cols(SCORE6)
           fac_lags6(:,(k-1)*fmax+1:k*fmax) = divlag(SCORE6(:,k),fmax-1);
        end
        fac6 = fac_lags6(1:end-1,1:n_fac_h6*fmax);
        xvar_h6  = [y_lags_h6,fac6];
        predx_h6  = [ones(1,1),ylag(end,6 :6+seld-1 ),fac_lags6( end,1:n_fac_h6 *fmax)];
        predx_fac6 = fac_lags6(end,1:n_fac_h6*fmax);
        clear SCORE6 matLoads6 fac_lags6
        
        if cols(xx_sel_h12)>=20       
           [icasig_h12, A_h12,W_h12]= fastica2(xx_sel_h12','verbose','off');
           if isempty(W_h12)
               [icasig_h12, A_h12, W_h12] = fastica2(xx_h12','verbose','off');
               SCORE12= xx_h12*W_h12';
           else
               SCORE12= xx_sel_h12*W_h12';
           end
           n_fac_h12 = rows(W_h12);
        elseif cols(xx_sel_ex_h12)>0&cols(xx_sel_ex_h12)<20
           SCORE12 = xx_sel_ex_h12;
           n_fac_h12  = cols(xx_sel_ex_h12); 
        elseif cols(xx_sel_ex_h12)==0
           [icasig_h12, A_h12,W_h12]= fastica2(xx_h12','verbose','off');
           n_fac_h12 = rows(W_h12);
           SCORE12= xx_h12*W_h12';
        end
        for k=1:1:cols(SCORE12)
           fac_lags12(:,(k-1)*fmax+1:k*fmax)= divlag(SCORE12(:,k),fmax-1);
        end
        fac12 = fac_lags12(1:end-1,1:n_fac_h12*fmax);
        xvar_h12 = [y_lags_h12,fac12];
        predx_h12 = [ones(1,1),ylag(end,12:12+seld-1),fac_lags12(end,1:n_fac_h12*fmax)];
        predx_fac12= fac_lags12(end,1:n_fac_h12*fmax);
        clear SCORE12 matLoads12 fac_lags12
        
        B_h1  = (y_lags_h1' *y_lags_h1)\y_lags_h1'*y_tar;
        B_h3  = (y_lags_h3' *y_lags_h3)\y_lags_h3'*y_tar;
        B_h6  = (y_lags_h6' *y_lags_h6)\y_lags_h6'*y_tar;
        B_h12 = (y_lags_h12'*y_lags_h12)\y_lags_h12'*y_tar;
        
        z0_h1 = y_tar - y_lags_h1 * B_h1 ;         % Residual : z0 
        z0_h3 = y_tar - y_lags_h3 * B_h3 ;         % Residual : z0 
        z0_h6 = y_tar - y_lags_h6 * B_h6 ;         % Residual : z0 
        z0_h12= y_tar - y_lags_h12* B_h12;         % Residual : z0 
    % LARS, EN, NNG Setup--------------------------------------------------
        facnorm_h1  = normalize([fac1;predx_fac1]);
        znorm_h1  = center(z0_h1);
        facnorm_h3  = normalize([fac3;predx_fac3]);
        znorm_h3  = center(z0_h3);
        facnorm_h6  = normalize([fac6;predx_fac6]);
        znorm_h6  = center(z0_h6);
        facnorm_h12 = normalize([fac12;predx_fac12]);
        znorm_h12 = center(z0_h12);
         
% -------------------------------------------------------------------------
% Forecating Methods 
% [1] Autoregressive ------------------------------------------------------
        if mc(1) == 1
            predx_ar_h1  = [ones(1,1),ylag(end,1:1+seld-1)];
            predx_ar_h3  = [ones(1,1),ylag(end,3:3+seld-1)];
            predx_ar_h6  = [ones(1,1),ylag(end,6:6+seld-1)];
            predx_ar_h12 = [ones(1,1),ylag(end,12:12+seld-1)];
            
            yhat_ar(i,j,1) = predx_ar_h1*B_h1;
            yhat_ar(i,j,2) = predx_ar_h3*B_h3;
            yhat_ar(i,j,3) = predx_ar_h6*B_h6;
            yhat_ar(i,j,4) = predx_ar_h12*B_h12;
        end  
% -------------------------------------------------------------------------
% [6] Bagging -------------------------------------------------------------
        if mc(6) == 1
            [yhat_bag_t_h1,qq,qqq,beta_bag1]  = bagging_shrink2(y_tar,xvar_h1,seld,fac1,predx_fac1,[ones(1,1),ylag(end,1:1+seld-1)],c);
            [yhat_bag_t_h3,qq,qqq,beta_bag3]  = bagging_shrink2(y_tar,xvar_h3,seld,fac3,predx_fac3,[ones(1,1),ylag(end,3:3+seld-1)],c);
            [yhat_bag_t_h6,qq,qqq,beta_bag6]  = bagging_shrink2(y_tar,xvar_h6,seld,fac6,predx_fac6,[ones(1,1),ylag(end,6:6+seld-1)],c);
            [yhat_bag_t_h12,qq,qqq,beta_bag12]= bagging_shrink2(y_tar,xvar_h12,seld,fac12,predx_fac12,[ones(1,1),ylag(end,12:12+seld-1)],c);
            
            yhat_bag(i,j,1) = yhat_bag_t_h1;
            yhat_bag(i,j,2) = yhat_bag_t_h3;
            yhat_bag(i,j,3) = yhat_bag_t_h6;
            yhat_bag(i,j,4) = yhat_bag_t_h12;
            clear yhat_bag_t_h1 yhat_bag_t_h3 yhat_bag_t_h6 yhat_bag_t_h12 lamda pac_hat
        end
% -------------------------------------------------------------------------
% [7] Component Boosting --------------------------------------------------
        if mc(7) == 1
        [qq,qqq,qqqq,beta_IC_h1] = com_boost_ic(fac1,z0_h1,.5,M);
        [qq,qqq,qqqq,beta_IC_h3] = com_boost_ic(fac3,z0_h3,.5,M);
        [qq,qqq,qqqq,beta_IC_h6] = com_boost_ic(fac6,z0_h6,.5,M);
        [PHI,beta,IC,beta_IC_h12]= com_boost_ic(fac12,z0_h12,.5,M);
        
        yhat_cbst(i,j,1) = predx_ar_h1*B_h1 + predx_fac1 * beta_IC_h1;    
        yhat_cbst(i,j,2) = predx_ar_h3*B_h3 + predx_fac3 * beta_IC_h3;    
        yhat_cbst(i,j,3) = predx_ar_h6*B_h6 + predx_fac6 * beta_IC_h6;    
        yhat_cbst(i,j,4) = predx_ar_h12*B_h12+ predx_fac12* beta_IC_h12;    
        clear PHI beta IC beta_IC_h1 beta_IC_h3 beta_IC_h6 beta_IC_h12 qq qqq qqqq
        end
        
% -------------------------------------------------------------------------
% [8] Bayesian Model Averaging I ( g = 1/n ) ------------------------------
        if mc(8) == 1
        opt1 = 0; opt2 = 1; opt3 = 1;        
        beta_bma1_h1  = bma_koop(nburn,nkeep,z0_h1,fac1,opt1,opt2,opt3);
        beta_bma1_h3  = bma_koop(nburn,nkeep,z0_h3,fac3,opt1,opt2,opt3);
        beta_bma1_h6  = bma_koop(nburn,nkeep,z0_h6,fac6,opt1,opt2,opt3);
        beta_bma1_h12 = bma_koop(nburn,nkeep,z0_h12,fac12,opt1,opt2,opt3);

        yhat_bma1(i,j,1) = predx_ar_h1*B_h1 + predx_fac1 * beta_bma1_h1;    
        yhat_bma1(i,j,2) = predx_ar_h3*B_h3 + predx_fac3 * beta_bma1_h3;    
        yhat_bma1(i,j,3) = predx_ar_h6*B_h6 + predx_fac6 * beta_bma1_h6;    
        yhat_bma1(i,j,4) = predx_ar_h12*B_h12 + predx_fac12 * beta_bma1_h12;    
        end
% -------------------------------------------------------------------------
% [9] Bayesian Model Averaging II ( g = 1/(k^2) ) ------------------------- 
        if mc(9) == 1
        opt1 = 1; opt2 = 1; opt3 = 1;    
        beta_bma2_h1 = bma_koop(nburn,nkeep,z0_h1,fac1,opt1,opt2,opt3);
        beta_bma2_h3 = bma_koop(nburn,nkeep,z0_h3,fac3,opt1,opt2,opt3);
        beta_bma2_h6 = bma_koop(nburn,nkeep,z0_h6,fac6,opt1,opt2,opt3);
        beta_bma2_h12= bma_koop(nburn,nkeep,z0_h12,fac12,opt1,opt2,opt3);

        yhat_bma2(i,j,1) = predx_ar_h1*B_h1 + predx_fac1 * beta_bma2_h1;    
        yhat_bma2(i,j,2) = predx_ar_h3*B_h3 + predx_fac3 * beta_bma2_h3;    
        yhat_bma2(i,j,3) = predx_ar_h6*B_h6 + predx_fac6 * beta_bma2_h6;    
        yhat_bma2(i,j,4) = predx_ar_h12*B_h12 + predx_fac12 * beta_bma2_h12;    
        end
% -------------------------------------------------------------------------            
% [11] Least Angle Regression ---------------------------------------------
        if mc(11) == 1
        beta_tar1 = lars(facnorm_h1(1:end-1,:), znorm_h1,'lars',0,0,[],1);
        beta_tar3 = lars(facnorm_h3(1:end-1,:), znorm_h3,'lars',0,0,[],1);
        beta_tar6 = lars(facnorm_h6(1:end-1,:), znorm_h6,'lars',0,0,[],1);
        beta_tar12= lars(facnorm_h12(1:end-1,:), znorm_h12,'lars',0,0,[],1);
        
        beta_tar1  = real(beta_tar1);
        beta_tar3  = real(beta_tar3);
        beta_tar6  = real(beta_tar6);
        beta_tar12 = real(beta_tar12);
        
        IC_h1 = zeros(cols(fac1),1);
        IC_h3 = zeros(cols(fac3),1);
        IC_h6 = zeros(cols(fac6),1);
        IC_h12 = zeros(cols(fac12),1);
        
        for f = 1: 1: cols(fac1)
            sig2_h1  = (z0_h1  - fac1  * beta_tar1(f+1,:)')' *(z0_h1  - fac1  * beta_tar1(f+1,:)');
            IC_h1(f,1)  = log(sig2_h1)  + ( cols(beta_tar1)  * log(rows(z0_h1) )) / rows(z0_h1);
        end
        for f = 1: 1: cols(fac3)
            sig2_h3  = (z0_h3  - fac3  * beta_tar3(f+1,:)')' *(z0_h3  - fac3  * beta_tar3(f+1,:)');
            IC_h3(f,1)  = log(sig2_h3)  + ( cols(beta_tar3)  * log(rows(z0_h3) )) / rows(z0_h3);
        end
        for f = 1: 1: cols(fac6)
            sig2_h6  = (z0_h6  - fac6  * beta_tar6(f+1,:)')' *(z0_h6  - fac6  * beta_tar6(f+1,:)');
            IC_h6(f,1)  = log(sig2_h6)  + ( cols(beta_tar6)  * log(rows(z0_h6) )) / rows(z0_h6);
        end
        for f = 1: 1: cols(fac12)
            sig2_h12 = (z0_h12 - fac12 * beta_tar12(f+1,:)')'*(z0_h12 - fac12 * beta_tar12(f+1,:)');
            IC_h12(f,1) = log(sig2_h12) + ( cols(beta_tar12) * log(rows(z0_h12) )) / rows(z0_h12);
        end
        
        [val_h1,IC_i_h1]  = min(IC_h1);
        [val_h3,IC_i_h3]  = min(IC_h3);
        [val_h6,IC_i_h6]  = min(IC_h6);
        [val_h12,IC_i_h12]= min(IC_h12);
        
        beta_IC_h1 = beta_tar1(IC_i_h1+1,:);      % Finding beta by BIC
        beta_IC_h3 = beta_tar3(IC_i_h3+1,:);      % Finding beta by BIC
        beta_IC_h6 = beta_tar6(IC_i_h6+1,:);      % Finding beta by BIC
        beta_IC_h12= beta_tar12(IC_i_h12+1,:);    % Finding beta by BIC
        
        beta_lars_h1 = [B_h1;beta_IC_h1'];           % Put together 
        beta_lars_h3 = [B_h3;beta_IC_h3'];           % Put together 
        beta_lars_h6 = [B_h6;beta_IC_h6'];           % Put together 
        beta_lars_h12= [B_h12;beta_IC_h12'];         % Put together 
        
        yhat_lars(i,j,1) = mean(z0_h1) + [ones(1,1),(ylag(end,1:1+seld-1)-mean(z0_h1)),facnorm_h1(end,:)] * beta_lars_h1;
        yhat_lars(i,j,2) = mean(z0_h3) + [ones(1,1),(ylag(end,3:3+seld-1)-mean(z0_h3)),facnorm_h3(end,:)] * beta_lars_h3;
        yhat_lars(i,j,3) = mean(z0_h6) + [ones(1,1),(ylag(end,6:6+seld-1)-mean(z0_h6)),facnorm_h6(end,:)] * beta_lars_h6;
        yhat_lars(i,j,4) = mean(z0_h12)+ [ones(1,1),(ylag(end,12:12+seld-1)-mean(z0_h12)),facnorm_h12(end,:)]* beta_lars_h12;
        end
% -------------------------------------------------------------------------
% [12] Elastic Net --------------------------------------------------------
        if mc(12) == 1
        beta1_en_h1 = larsen(facnorm_h1(1:end-1,:), znorm_h1,0.1,0,1);
        beta1_en_h3 = larsen(facnorm_h3(1:end-1,:), znorm_h3,0.1,0,1);
        beta1_en_h6 = larsen(facnorm_h6(1:end-1,:), znorm_h6,0.1,0,1);
        beta1_en_h12 = larsen(facnorm_h12(1:end-1,:), znorm_h12,0.1,0,1);

        beta_en_h1  = real(beta1_en_h1);
        beta_en_h3  = real(beta1_en_h3);
        beta_en_h6  = real(beta1_en_h6);
        beta_en_h12 = real(beta1_en_h12);

        IC_h1  = zeros(cols(fac1),1);
        IC_h3  = zeros(cols(fac3),1);
        IC_h6  = zeros(cols(fac6),1);
        IC_h12 = zeros(cols(fac12),1);
        
        for f = 1: 1: cols(fac1)
            sig2_h1  = (z0_h1  - fac1  * beta_en_h1(f+1,:)')' *(z0_h1  - fac1  * beta_en_h1(f+1,:)');
            IC_h1(f,1)  = log(sig2_h1)  + ( cols(beta_en_h1)  * log(rows(z0_h1) )) / rows(z0_h1);
        end
        for f = 1: 1: cols(fac3)
            sig2_h3  = (z0_h3  - fac3  * beta_en_h3(f+1,:)')' *(z0_h3  - fac3  * beta_en_h3(f+1,:)');
            IC_h3(f,1)  = log(sig2_h3)  + ( cols(beta_en_h3)  * log(rows(z0_h3) )) / rows(z0_h3);
        end
        for f = 1: 1: cols(fac6)
            sig2_h6  = (z0_h6  - fac6  * beta_en_h6(f+1,:)')' *(z0_h6  - fac6  * beta_en_h6(f+1,:)');
            IC_h6(f,1)  = log(sig2_h6)  + ( cols(beta_en_h6)  * log(rows(z0_h6) )) / rows(z0_h6);
        end
        for f = 1: 1: cols(fac12)
            sig2_h12 = (z0_h12 - fac12 * beta_en_h12(f+1,:)')'*(z0_h12 - fac12 * beta_en_h12(f+1,:)');
            IC_h12(f,1) = log(sig2_h12) + ( cols(beta_en_h12) * log(rows(z0_h12) )) / rows(z0_h12);
        end
         
        [val_h1,IC_i_h1]   = min(IC_h1);
        [val_h3,IC_i_h3]   = min(IC_h3);
        [val_h6,IC_i_h6]   = min(IC_h6);
        [val_h12,IC_i_h12] = min(IC_h12);
        
        beta_en_IC_h1  = beta1_en_h1(IC_i_h1+1,:);      % Finding beta by BIC
        beta_en_IC_h3  = beta1_en_h3(IC_i_h3+1,:);      % Finding beta by BIC
        beta_en_IC_h6  = beta1_en_h6(IC_i_h6+1,:);      % Finding beta by BIC
        beta_en_IC_h12 = beta1_en_h12(IC_i_h12+1,:);    % Finding beta by BIC
    
        beta_en_h1  = [B_h1;beta_en_IC_h1'];           % Put together 
        beta_en_h3  = [B_h3;beta_en_IC_h3'];           % Put together 
        beta_en_h6  = [B_h6;beta_en_IC_h6'];           % Put together                 
        beta_en_h12 = [B_h12;beta_en_IC_h12'];         % Put together 

        yhat_en(i,j,1) = mean(z0_h1) + [ones(1,1),(ylag(end,1:1+seld-1)-mean(z0_h1)),facnorm_h1(end,:)] * beta_en_h1;
        yhat_en(i,j,2) = mean(z0_h3) + [ones(1,1),(ylag(end,3:3+seld-1)-mean(z0_h3)),facnorm_h3(end,:)] * beta_en_h3;
        yhat_en(i,j,3) = mean(z0_h6) + [ones(1,1),(ylag(end,6:6+seld-1)-mean(z0_h6)),facnorm_h6(end,:)] * beta_en_h6;
        yhat_en(i,j,4) = mean(z0_h12)+ [ones(1,1),(ylag(end,12:12+seld-1)-mean(z0_h12)),facnorm_h12(end,:)]* beta_en_h12;
        end
% -------------------------------------------------------------------------
% [13] Nonnegative Garrote ------------------------------------------------
        if mc(13) == 1
        [beta13_h1,qq,qqq] = nng_garotte_new(facnorm_h1(1:end-1,:), znorm_h1);
        [beta13_h3,qq,qqq] = nng_garotte_new(facnorm_h3(1:end-1,:), znorm_h3);
        [beta13_h6,qq,qqq] = nng_garotte_new(facnorm_h6(1:end-1,:), znorm_h6);
        [beta13_h12,qq,qqq]= nng_garotte_new(facnorm_h12(1:end-1,:),znorm_h12);
        
        beta_nng_h1  = [B_h1;beta13_h1];           % Put together 
        beta_nng_h3  = [B_h3;beta13_h3];           % Put together 
        beta_nng_h6  = [B_h6;beta13_h6];           % Put together 
        beta_nng_h12 = [B_h12;beta13_h12];           % Put together 
        
        yhat_nng(i,j,1) = mean(z0_h1) + [ones(1,1),(ylag(end,1:1+seld-1)-mean(z0_h1)),facnorm_h1(end,:)] * beta_nng_h1;
        yhat_nng(i,j,2) = mean(z0_h3) + [ones(1,1),(ylag(end,3:3+seld-1)-mean(z0_h3)),facnorm_h3(end,:)] * beta_nng_h3;
        yhat_nng(i,j,3) = mean(z0_h6) + [ones(1,1),(ylag(end,6:6+seld-1)-mean(z0_h6)),facnorm_h6(end,:)] * beta_nng_h6;
        yhat_nng(i,j,4) = mean(z0_h12)+ [ones(1,1),(ylag(end,12:12+seld-1)-mean(z0_h12)),facnorm_h12(end,:)]* beta_nng_h12;
        end
% -------------------------------------------------------------------------
    end
end
end
        

disp(' ')
if rero == 1
    disp('End of the Estimation for RECURSIVE Sample Estimation Under Specification Type 3')
else
    disp('End of the Estimation for ROLLING Sample Estimation Under Specification Type 3')
end
disp(' ')

% Result ------------------------------------------------------------------ 

Y_real = TrYvarTr(end-457+36:end,:); % Actual Value : Mar.1974~May.2009

Yhat(:,:,:,1)=yhat_ar; Yhat(:,:,:,2)=yhat_cbst; Yhat(:,:,:,3)=yhat_bma1; Yhat(:,:,:,4)=yhat_bma2;
Yhat(:,:,:,5)=yhat_lars; Yhat(:,:,:,6)=yhat_en; Yhat(:,:,:,7)=yhat_nng;
Yhat(:,:,:,8)=sum(Yhat(:,:,:,1:7),4)/7;

Yhat(rows(Yhat),:,:,:) = [];        % Get rid of last forecasting since it is for unobserved sample.(June.2009)
[rr cc dd kk] = size(Yhat);

MSE = zeros(rr,cc,kk,dd);
MSE_ratio = zeros(kk,cc,dd);


for h=1:1:dd
    for l = 1 : 1 : kk
        MSE(:,:,l,h) = (Yhat(:,:,h,l)-Y_real).^2;
    end
end

for h=1:1:dd
    MSE_ratio(1,:,h) = sum(MSE(:,:,1,h));
    for i = 2 : 1 : kk
        MSE_ratio(i,:,h) = sum(MSE(:,:,i,h))./sum(MSE(:,:,1,h));
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Divide MSE into subperiod.
% RW=120 or SP=120 case
% Business Cycle Divide. 

MSE1=MSE(12:69,:,:,:);            % 75:03~79:12 
MSE2=MSE(76:87,:,:,:);            % 80:07~81:06
MSE3=MSE(104:195,:,:,:);          % 82:11~90:06
MSE4=MSE(204:323,:,:,:);          % 91:03~01:02
MSE5=MSE(332:404,:,:,:);          % 01:11~07:11
MSE6=MSE([12:69,76:87,104:195,204:323,332:404],:,:,:);
MSE7=MSE([1:11,70:75,88:103,196:203,324:333,405:422],:,:,:);

[rr cc dd kk]=size(Yhat);

for h=1:1:dd
    MSE1_ratio(1,:,h) = sum(MSE1(:,:,1,h));
    MSE2_ratio(1,:,h) = sum(MSE2(:,:,1,h));
    MSE3_ratio(1,:,h) = sum(MSE3(:,:,1,h));
    MSE4_ratio(1,:,h) = sum(MSE4(:,:,1,h));
    MSE5_ratio(1,:,h) = sum(MSE5(:,:,1,h));
    MSE6_ratio(1,:,h) = sum(MSE6(:,:,1,h));
    MSE7_ratio(1,:,h) = sum(MSE7(:,:,1,h));
    for i = 2 : 1 : kk
        MSE1_ratio(i,:,h) = sum(MSE1(:,:,i,h))./sum(MSE1(:,:,1,h));
        MSE2_ratio(i,:,h) = sum(MSE2(:,:,i,h))./sum(MSE2(:,:,1,h));
        MSE3_ratio(i,:,h) = sum(MSE3(:,:,i,h))./sum(MSE3(:,:,1,h));
        MSE4_ratio(i,:,h) = sum(MSE4(:,:,i,h))./sum(MSE4(:,:,1,h));
        MSE5_ratio(i,:,h) = sum(MSE5(:,:,i,h))./sum(MSE5(:,:,1,h));
        MSE6_ratio(i,:,h) = sum(MSE6(:,:,i,h))./sum(MSE6(:,:,1,h));
        MSE7_ratio(i,:,h) = sum(MSE7(:,:,i,h))./sum(MSE7(:,:,1,h));
    end
end

if rero == 1
    fn1=input('Specify the name of the file to store results: ','s');
    fid=fopen(fn1,'wt');
    
    fprintf(fid, '\n             Table 5. Relative Mean Square Forecast Errors: Recursive Estimation, Specification Type 2  \n');
    fprintf(fid, '\n                                               Panel A: Recursive, h = 1  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,1) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(2,:,1) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(3,:,1) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(4,:,1) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(5,:,1) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(6,:,1) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(7,:,1) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(8,:,1) );    
    fprintf(fid, '\n                                                Panel B: Recursive, h = 3  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,2) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(2,:,2) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(3,:,2) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(4,:,2) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(5,:,2) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(6,:,2) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(7,:,2) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(8,:,2) );    
    fprintf(fid, '\n                                                Panel C: Recursive, h = 12  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,4) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(2,:,4) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(3,:,4) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(4,:,4) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(5,:,4) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(6,:,4) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(7,:,4) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(8,:,4) );    
    fclose(fid);
else
    fn1=input('Specify the name of the file to store results: ','s');
    fid=fopen(fn1,'wt');
    
    fprintf(fid, '\n             Table 5-1. Relative Mean Square Forecast Errors: Rolling Estimation, Specification Type 2  \n');
    fprintf(fid, '\n                                               Panel A: Rolling, h = 1  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,1) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(2,:,1) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(3,:,1) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(4,:,1) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(5,:,1) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(6,:,1) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(7,:,1) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(8,:,1) );    
    fprintf(fid, '\n                                                Panel B: Rolling, h = 3  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,2) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(2,:,2) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(3,:,2) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(4,:,2) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(5,:,2) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(6,:,2) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(7,:,2) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(8,:,2) );    
    fprintf(fid, '\n                                                Panel C: Rolling, h = 12  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,4) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(2,:,4) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(3,:,4) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(4,:,4) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(5,:,4) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(6,:,4) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(7,:,4) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(8,:,4) );    
    fclose(fid);
end

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        