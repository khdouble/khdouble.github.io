spcabeta<-function(xx_h1,selcol,betas_sel){
    if (selcol>=20) {   
      xx_sel_h1<-xx_h1[,betas_sel[,idx,cc,mm,hh]==1]
      out1<-spca(xx_sel_h1,K=numK,type="predictor",sparse="penalty",trace=TRUE,para=t(pt))
      beta00<-out1$loadings
      beta0[1:dim(beta00)[1],1:dim(beta00)[2]]<-beta00
    }
    if (selcol<20&selcol>5) {
      xx_sel_h1<-xx_h1[,betas_sel[,idx,cc,mm,hh]==1]
      out1<-spca(xx_sel_h1,K=selcol,type="predictor",sparse="penalty",trace=TRUE,para=t(pt))
      beta00<-out1$loadings
      beta0[1:dim(beta00)[1],1:dim(beta00)[2]]<-beta00
    }
    if (selcol==0) {
      out1<-spca(xx_h1,K=numK,type="predictor",sparse="penalty",trace=TRUE,para=t(pt))
      beta00<-out1$loadings
      beta0[1:dim(beta00)[1],1:dim(beta00)[2]]<-beta00
    }
    return(beta0)
}