MATLAB Codes for 

"Mining Big Data Using Parsimonious Factor and Shrinkage Methods", IJF
by Hyun Hak Kim and Norman R. Swanson, 2016

All of errors are ours. Please send any queries to hyunhak.kim@kookmin.ac.kr
-------------------------------------------------------------------------------

# Many of codes are using Econometric Toolbox by James P. LeSage
  You can get these codes from www.spatial-econometrics.com 

# Some of results, especially regarding Sparse Pricncipal Components Anaylsis
  are from R code. See www.r-project.org for the information about R. 
  For SPCA, spcabeta.R is used which is written in R. And its result was imported 
  to MATLAB as 'spca_loadings_rec.mat' and 'spca_loadings_rol.mat'.

# Dataset02.data is the MATLAB dataset used in our forecasting experiment. 
  It includes all 144 variables and series are from Jan.1960 to May. 2009. 

# If there is missing matlab function, please find the code for our previous paper, 
  "Forecasting Financial and Macroeconomic Variables Using Data Reduction Methods",
  Journal of Econometrics, 2014 or please contact me and let me know which files 
  are missing. 

-------------------------------------------------------------------------------

These programs replicate result in Table 3 and 4. 
Main Program select various specification in itselt. The following program explains
details about each of them. You can run the following program itself for your own convenience.

SP1_PCA.m

-> By running this program, you can get the result of 14 forecasting methods 
   under Specification Type 1 without lags with factors estimated by PCA. 
   The result table is identical to Table 3 of Kim and Swanson (2013).

SP1_PCA_L.m

-> This gives you the result of Specification Type 1 with lags, with factors 
   estimated by PCA, which is identical to Table 4 of Kim ans Swanson (2013). 

SP1_ICA.m and SP1_ICA_L.m

-> These give you the result of Specification Type 1 without lags and with lags,
   with factors estimated by ICA. You can idnetical tables to Table 3 and 4 of 
   KS(2013) but this is for the Independent Component Analysis

SP1_SPCA.m and SP1_SPCA_L.m

-> These give you the result of Specification Type 1 without lags and with lags,
   with factors estimated by SPCA. You also get tables like Table 3 and 4 of KS(2013)
   but these are for the Sparse Principal Component Analysis
   
   Be aware of that it calls the result of Sparse Principal Component Analysis 
   by R. We use R for estimating SPCA. 
   "spca_loadings_rec.mat" calls the SPCA result for recursive estimation. 
   "spca_loadings_rol.mat" calls the SPCA result for rolling estimation. 

   * "spcabeta.R" is the program is the one which estimates factor loading and factors by SPCA.
     To produce result file like "spca_loading_rec.mat", it requires appropriate 
     assignment for forecast horiozn. 

SP2_PCA.m, SP2_PCA_L and others

-> By same way, all these SP2_***.m and SP2_***_L.m calls the result under 
   Specification Type 2 

SP3.m 

-> Specification Type 3 does not use any of component analysis there is no permutation.
   The result table is identical to Table 6 of KS(2013). 

SP4.m and SP4_L.m 

-> These give the results for Specification Type 4 without lags and with lags. The result
   tables also resembles those of other specification types. 

SummaryResult.m
-> This organizes entire tables in the paper which was not made in MainProg.m It uses 
   other functions like MSE_result.m, PickTheBest.m and Result_to_EXCEL.m and etc to produce
   tables. 
   

