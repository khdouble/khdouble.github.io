% Rolling Estimation ------------------------------------------------------

% Yhat FIXING 
Yhat_SP1L_ROL(:,:,:,[1:3]) = Yhat_SP1_ROL(:,:,:,[1:3]);
Yhat_SP2_ROL(:,:,:,[1:3]) = Yhat_SP1_ROL(:,:,:,[1:3]);
Yhat_SP3_ROL(:,:,:,[1:3]) = Yhat_SP1_ROL(:,:,:,[1:3]);

% Mean redirecting
Yhat_SP1L_ROL(:,:,:,14) = sum(Yhat_SP1L_ROL(:,:,:,[1:13]),4)/13;
Yhat_SP2_ROL(:,:,:,14)  = sum(Yhat_SP2_ROL(:,:,:,[1,2,3,6,7,8,9,10,11,12,13]),4)/11;
Yhat_SP3_ROL(:,:,:,14)  = sum(Yhat_SP3_ROL(:,:,:,[1,2,3,6,7,8,9,10,11,12,13]),4)/11;

% Yhat FIXING 
Yhat_SP1L_REC(:,:,:,[1:3]) = Yhat_SP1_REC(:,:,:,[1:3]);
Yhat_SP2_REC(:,:,:,[1:3]) = Yhat_SP1_REC(:,:,:,[1:3]);
Yhat_SP3_REC(:,:,:,[1:3]) = Yhat_SP1_REC(:,:,:,[1:3]);

% Mean redirecting
Yhat_SP1L_REC(:,:,:,14) = sum(Yhat_SP1L_REC(:,:,:,[1:13]),4)/13;
Yhat_SP2_REC(:,:,:,14)  = sum(Yhat_SP2_REC(:,:,:,[1,2,3,6,7,8,9,10,11,12,13]),4)/11;
Yhat_SP3_REC(:,:,:,14)  = sum(Yhat_SP3_REC(:,:,:,[1,2,3,6,7,8,9,10,11,12,13]),4)/11;

% -------------------------------------------------------------------------

% MSE_ratio RE-calculating
[rr cc dd kk] = size(Yhat_SP1_REC);

for h=1:1:dd
    for l = 1 : 1 : kk
        MSE_ROL_SP1(:,:,l,h) = (Yhat_SP1_ROL(:,:,h,l)-Y_real).^2;
        MSE_ROL_SP1L(:,:,l,h)= (Yhat_SP1L_ROL(:,:,h,l)-Y_real).^2;        
        MSE_ROL_SP2(:,:,l,h) = (Yhat_SP2_ROL(:,:,h,l)-Y_real).^2;
        MSE_ROL_SP3(:,:,l,h) = (Yhat_SP3_ROL(:,:,h,l)-Y_real).^2;
    end
end

for h=1:1:dd
    MSE_ratio_ROL_SP1(1,:,h) = sum(MSE_ROL_SP1(:,:,1,h));
    MSE_ratio_ROL_SP1L(1,:,h)= sum(MSE_ROL_SP1L(:,:,1,h));
    MSE_ratio_ROL_SP2(1,:,h) = sum(MSE_ROL_SP2(:,:,1,h));
    MSE_ratio_ROL_SP3(1,:,h) = sum(MSE_ROL_SP3(:,:,1,h));
    for i = 2 : 1 : kk
        MSE_ratio_ROL_SP1(i,:,h) = sum(MSE_ROL_SP1(:,:,i,h))./sum(MSE_ROL_SP1(:,:,1,h));
        MSE_ratio_ROL_SP1L(i,:,h)= sum(MSE_ROL_SP1L(:,:,i,h))./sum(MSE_ROL_SP1L(:,:,1,h));
        MSE_ratio_ROL_SP2(i,:,h) = sum(MSE_ROL_SP2(:,:,i,h))./sum(MSE_ROL_SP2(:,:,1,h));
        MSE_ratio_ROL_SP3(i,:,h) = sum(MSE_ROL_SP3(:,:,i,h))./sum(MSE_ROL_SP3(:,:,1,h));
    end
end

for h=1:1:dd
    for l = 1 : 1 : kk
        MSE_REC_SP1(:,:,l,h) = (Yhat_SP1_REC(:,:,h,l)-Y_real).^2;
        MSE_REC_SP1L(:,:,l,h)= (Yhat_SP1L_REC(:,:,h,l)-Y_real).^2;        
        MSE_REC_SP2(:,:,l,h) = (Yhat_SP2_REC(:,:,h,l)-Y_real).^2;
        MSE_REC_SP3(:,:,l,h) = (Yhat_SP3_REC(:,:,h,l)-Y_real).^2;
    end
end

for h=1:1:dd
    MSE_ratio_REC_SP1(1,:,h) = sum(MSE_REC_SP1(:,:,1,h));
    MSE_ratio_REC_SP1L(1,:,h)= sum(MSE_REC_SP1L(:,:,1,h));
    MSE_ratio_REC_SP2(1,:,h) = sum(MSE_REC_SP2(:,:,1,h));
    MSE_ratio_REC_SP3(1,:,h) = sum(MSE_REC_SP3(:,:,1,h));
    for i = 2 : 1 : kk
        MSE_ratio_REC_SP1(i,:,h) = sum(MSE_REC_SP1(:,:,i,h))./sum(MSE_REC_SP1(:,:,1,h));
        MSE_ratio_REC_SP1L(i,:,h)= sum(MSE_REC_SP1L(:,:,i,h))./sum(MSE_REC_SP1L(:,:,1,h));
        MSE_ratio_REC_SP2(i,:,h) = sum(MSE_REC_SP2(:,:,i,h))./sum(MSE_REC_SP2(:,:,1,h));
        MSE_ratio_REC_SP3(i,:,h) = sum(MSE_REC_SP3(:,:,i,h))./sum(MSE_REC_SP3(:,:,1,h));
    end
end
clear rr cc dd kk h i l
% -------------------------------------------------------------------------

% SAVED to Core_P300_ROL.mat till here

% DM-TEST
[S1] = dmtest_4d(MSE_ROL_SP1);
[S1L] = dmtest_4d(MSE_ROL_SP1L)
[S2] = dmtest_4d(MSE_ROL_SP2)
[S3] = dmtest_4d(MSE_ROL_SP3)


% COPYING TO EXCEL 
ROL_R1 = [MSE_ratio_ROL_SP1(:,:,1);nan(1,11);MSE_ratio_ROL_SP1(:,:,2);nan(1,11);MSE_ratio_ROL_SP1(:,:,3);nan(1,11);MSE_ratio_ROL_SP1(:,:,4)];
ROL_R2 = [zeros(1,11);S1(:,:,1);nan(1,11);zeros(1,11);S1(:,:,2);nan(1,11);zeros(1,11);S1(:,:,3);nan(1,11);zeros(1,11);S1(:,:,4)];

ROL_R1L = [MSE_ratio_ROL_SP1L(:,:,1);nan(1,11);MSE_ratio_ROL_SP1L(:,:,2);nan(1,11);MSE_ratio_ROL_SP1L(:,:,3);nan(1,11);MSE_ratio_ROL_SP1L(:,:,4)];
ROL_R2L = [zeros(1,11);S1L(:,:,1);nan(1,11);zeros(1,11);S1L(:,:,2);nan(1,11);zeros(1,11);S1L(:,:,3);nan(1,11);zeros(1,11);S1L(:,:,4)];

ROL_R12 = [MSE_ratio_ROL_SP2([1,2,3,6,7,8,9,10,11,12,13,14],:,1);nan(1,11);MSE_ratio_ROL_SP2([1,2,3,6,7,8,9,10,11,12,13,14],:,2);nan(1,11);MSE_ratio_ROL_SP2([1,2,3,6,7,8,9,10,11,12,13,14],:,3);nan(1,11);MSE_ratio_ROL_SP2([1,2,3,6,7,8,9,10,11,12,13,14],:,4)];
ROL_R22 = [zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,1);nan(1,11);zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,2);nan(1,11);zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,3);nan(1,11);zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,4)];
%ROL_R12 = [MSE_ratio_ROL_SP2([1,2,3,7,8,9,11,12,13,14],:,1);nan(1,11);MSE_ratio_ROL_SP2([1,2,3,7,8,9,11,12,13,14],:,2);nan(1,11);MSE_ratio_ROL_SP2([1,2,3,7,8,9,11,12,13,14],:,3);nan(1,11);MSE_ratio_ROL_SP2([1,2,3,7,8,9,11,12,13,14],:,4)];
%ROL_R22 = [zeros(1,11);S2([1,2,6,7,8,10,11,12,13],:,1);nan(1,11);zeros(1,11);S2([1,2,6,7,8,10,11,12,13],:,2);nan(1,11);zeros(1,11);S2([1,2,6,7,8,10,11,12,13],:,3);nan(1,11);zeros(1,11);S2([1,2,6,7,8,10,11,12,13],:,4)];

ROL_R13 = [MSE_ratio_ROL_SP3([1,2,3,6,7,8,9,10,11,12,13,14],:,1);nan(1,11);MSE_ratio_ROL_SP3([1,2,3,6,7,8,9,10,11,12,13,14],:,2);nan(1,11);MSE_ratio_ROL_SP3([1,2,3,6,7,8,9,10,11,12,13,14],:,3);nan(1,11);MSE_ratio_ROL_SP3([1,2,3,6,7,8,9,10,11,12,13,14],:,4)];
ROL_R23 = [zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,1);nan(1,11);zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,2);nan(1,11);zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,3);nan(1,11);zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,4)];
%ROL_R13 = [MSE_ratio_ROL_SP3([1,2,3,7,8,9,10,11,12,13,14],:,1);nan(4,11);MSE_ratio_ROL_SP3([1,2,3,7,8,9,10,11,12,13,14],:,2);nan(4,11);MSE_ratio_ROL_SP3([1,2,3,7,8,9,10,11,12,13,14],:,4)];
%ROL_R23 = [zeros(1,11);S3([1,2,6,7,8,9,10,11,12,13],:,1);nan(4,11);zeros(1,11);S3([1,2,6,7,8,9,10,11,12,13],:,2);nan(4,11);zeros(1,11);S3([1,2,6,7,8,9,10,11,12,13],:,4)];

clear S1 S1L S2 S3
% -------------------------------------------------------------------------
[S1] = dmtest_4d(MSE_REC_SP1);
[S1L] = dmtest_4d(MSE_REC_SP1L)
[S2] = dmtest_4d(MSE_REC_SP2)
[S3] = dmtest_4d(MSE_REC_SP3)


% COPYING TO EXCEL 
REC_R1 = [MSE_ratio_REC_SP1(:,:,1);nan(1,11);MSE_ratio_REC_SP1(:,:,2);nan(1,11);MSE_ratio_REC_SP1(:,:,3);nan(1,11);MSE_ratio_REC_SP1(:,:,4)];
REC_R2 = [zeros(1,11);S1(:,:,1);nan(1,11);zeros(1,11);S1(:,:,2);nan(1,11);zeros(1,11);S1(:,:,3);nan(1,11);zeros(1,11);S1(:,:,4)];

REC_R1L = [MSE_ratio_REC_SP1L(:,:,1);nan(1,11);MSE_ratio_REC_SP1L(:,:,2);nan(1,11);MSE_ratio_REC_SP1L(:,:,3);nan(1,11);MSE_ratio_REC_SP1L(:,:,4)];
REC_R2L = [zeros(1,11);S1L(:,:,1);nan(1,11);zeros(1,11);S1L(:,:,2);nan(1,11);zeros(1,11);S1L(:,:,3);nan(1,11);zeros(1,11);S1L(:,:,4)];

REC_R12 = [MSE_ratio_REC_SP2([1,2,3,6,7,8,9,10,11,12,13,14],:,1);nan(1,11);MSE_ratio_REC_SP2([1,2,3,6,7,8,9,10,11,12,13,14],:,2);nan(1,11);MSE_ratio_REC_SP2([1,2,3,6,7,8,9,10,11,12,13,14],:,3);nan(1,11);MSE_ratio_REC_SP2([1,2,3,6,7,8,9,10,11,12,13,14],:,4)];
REC_R22 = [zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,1);nan(1,11);zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,2);nan(1,11);zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,3);nan(1,11);zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,4)];
%REC_R12 = [MSE_ratio_REC_SP2([1,2,3,7,8,9,11,12,13,14],:,1);nan(1,11);MSE_ratio_REC_SP2([1,2,3,7,8,9,11,12,13,14],:,2);nan(1,11);MSE_ratio_REC_SP2([1,2,3,7,8,9,11,12,13,14],:,3);nan(1,11);MSE_ratio_REC_SP2([1,2,3,7,8,9,11,12,13,14],:,4)];
%REC_R22 = [zeros(1,11);S2([1,2,6,7,8,10,11,12,13],:,1);nan(1,11);zeros(1,11);S2([1,2,6,7,8,10,11,12,13],:,2);nan(1,11);zeros(1,11);S2([1,2,6,7,8,10,11,12,13],:,3);nan(1,11);zeros(1,11);S2([1,2,6,7,8,10,11,12,13],:,4)];

REC_R13 = [MSE_ratio_REC_SP3([1,2,3,6,7,8,9,10,11,12,13,14],:,1);nan(1,11);MSE_ratio_REC_SP3([1,2,3,6,7,8,9,10,11,12,13,14],:,2);nan(1,11);MSE_ratio_REC_SP3([1,2,3,6,7,8,9,10,11,12,13,14],:,3);nan(1,11);MSE_ratio_REC_SP3([1,2,3,6,7,8,9,10,11,12,13,14],:,4)];
REC_R23 = [zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,1);nan(1,11);zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,2);nan(1,11);zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,3);nan(1,11);zeros(1,11);S2([1,2,5,6,7,8,9,10,11,12,13],:,4)];
%REC_R13 = [MSE_ratio_REC_SP3([1,2,3,7,8,9,10,11,12,13,14],:,1);nan(4,11);MSE_ratio_REC_SP3([1,2,3,7,8,9,10,11,12,13,14],:,2);nan(4,11);MSE_ratio_REC_SP3([1,2,3,7,8,9,10,11,12,13,14],:,4)];
%REC_R23 = [zeros(1,11);S3([1,2,6,7,8,9,10,11,12,13],:,1);nan(4,11);zeros(1,11);S3([1,2,6,7,8,9,10,11,12,13],:,2);nan(4,11);zeros(1,11);S3([1,2,6,7,8,9,10,11,12,13],:,4)];

% -------------------------------------------------------------------------
% Pick the BEST 

% for ROLLING 

% BEST in each specification
BestMet1_ROL  = PickTheBest(MSE_ratio_ROL_SP1);
BestMet1L_ROL = PickTheBest(MSE_ratio_ROL_SP1L);
MSE_ratio_ROL_SP2([4,5],:,:) = 10e3;
BestMet2_ROL  = PickTheBest(MSE_ratio_ROL_SP2);
MSE_ratio_ROL_SP3([4,5],:,:) = 10e3;
BestMet3_ROL  = PickTheBest(MSE_ratio_ROL_SP3);

% BEST in each specificationa
BestMet1_REC  = PickTheBest(MSE_ratio_REC_SP1);
BestMet1L_REC = PickTheBest(MSE_ratio_REC_SP1L);
MSE_ratio_REC_SP2([4,5],:,:) = 10e3;
BestMet2_REC  = PickTheBest(MSE_ratio_REC_SP2);
MSE_ratio_REC_SP3([4,5],:,:) = 10e3;
BestMet3_REC  = PickTheBest(MSE_ratio_REC_SP3);
% -------------------------------------------------------------------------

% SUB PERIOD DIVISION
% PANEL A
clear MSE
    MSE = MSE_REC_SP3;          % <---------- Change MSE appropriately ----------------------------------------------------------------------------------------------

    MSE1=MSE(1:73,:,:,:);             % 84:06~90:06
    MSE2=MSE(82:201,:,:,:);           % 91:03~01:02
    MSE3=MSE(210:282,:,:,:);          % 01:11~07:11
    MSE4=MSE([1:73,82:201,210:282],:,:,:);   % Expansion
    MSE5=MSE([74:81,202:209],:,:,:);   %Recession

    %[rr cc dd kk]=size(Yhat);
    dd=4; kk=14;
    for h=1:1:dd
        MSE1_ratio(1,:,h) = sum(MSE1(:,:,1,h));
        MSE2_ratio(1,:,h) = sum(MSE2(:,:,1,h));
        MSE3_ratio(1,:,h) = sum(MSE3(:,:,1,h));
        MSE4_ratio(1,:,h) = sum(MSE4(:,:,1,h));
        MSE5_ratio(1,:,h) = sum(MSE5(:,:,1,h));
    %    MSE6_ratio(1,:,h) = sum(MSE6(:,:,1,h));
    %    MSE7_ratio(1,:,h) = sum(MSE7(:,:,1,h));
        for i = 2 : 1 : kk
            MSE1_ratio(i,:,h) = sum(MSE1(:,:,i,h))./sum(MSE1(:,:,1,h));
            MSE2_ratio(i,:,h) = sum(MSE2(:,:,i,h))./sum(MSE2(:,:,1,h));
            MSE3_ratio(i,:,h) = sum(MSE3(:,:,i,h))./sum(MSE3(:,:,1,h));
            MSE4_ratio(i,:,h) = sum(MSE4(:,:,i,h))./sum(MSE4(:,:,1,h));
            MSE5_ratio(i,:,h) = sum(MSE5(:,:,i,h))./sum(MSE5(:,:,1,h));
    %        MSE6_ratio(i,:,h) = sum(MSE6(:,:,i,h))./sum(MSE6(:,:,1,h));
    %        MSE7_ratio(i,:,h) = sum(MSE7(:,:,i,h))./sum(MSE7(:,:,1,h));
        end
    end

    [BestMet1, BestMetN1, BestMet_V1]  = PickTheBest(MSE1_ratio);
    [BestMet2, BestMetN2, BestMet_V2]  = PickTheBest(MSE2_ratio);
    [BestMet3, BestMetN3, BestMet_V3]  = PickTheBest(MSE3_ratio);
    [BestMet4, BestMetN4, BestMet_V4]  = PickTheBest(MSE4_ratio);
    [BestMet5, BestMetN5, BestMet_V5]  = PickTheBest(MSE5_ratio);

    [BestMetN1(1,:);BestMetN2(1,:);BestMetN3(1,:);BestMetN4(1,:);BestMetN5(1,:)]
    [BestMet_V1(1,:);BestMet_V2(1,:);BestMet_V3(1,:);BestMet_V4(1,:);BestMet_V5(1,:)]

    [BestMetN1(2,:);BestMetN2(2,:);BestMetN3(2,:);BestMetN4(2,:);BestMetN5(2,:)]
    [BestMet_V1(2,:);BestMet_V2(2,:);BestMet_V3(2,:);BestMet_V4(2,:);BestMet_V5(2,:)]

    [BestMetN1(4,:);BestMetN2(4,:);BestMetN3(4,:);BestMetN4(4,:);BestMetN5(4,:)]
    [BestMet_V1(4,:);BestMet_V2(4,:);BestMet_V3(4,:);BestMet_V4(4,:);BestMet_V5(4,:)]

