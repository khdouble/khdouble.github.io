function [BestMet,BestMetN,BestMet_V] = PickTheBest(MSE_ratio)
% Pick the Best method using Relative MSFE for Kim&Swanson (2012)

MethodName = strvcat('AR','ARX','CADL','FAAR','PCR','Bag','Boost','BMA1','BMA2','Ridge','LAR','EN','NNG','Mean');
[m,n,h] =size(MSE_ratio);

for h=1:1:h
    [mR2,mV2] = min(MSE_ratio(2:end,:,h));
    for j=1:1:n
        if mR2(j)>=1
            f2(j)=1;
            BestMet_V(h,j) = MSE_ratio(1,j,h);
        else
           f2(j)=mV2(j)+1;
           BestMet_V(h,j) = mR2(j);
        end
        BestMet(j,:,h) = strvcat(MethodName(f2(j),:));
        BestMetN(h,j) = f2(j);
    end
    clear f2
end