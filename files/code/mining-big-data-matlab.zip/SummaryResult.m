clear
load MSEr_result

% Result Comaring Procedure

TargetVar = {'UR','PI','TB10Y','CPI','PPI','NPE','HS','IPX','M2','SNP','GDP'};
Methods1 = {'AR','ARX','CADL','FAAR','PCR','Bagg','Boost','BMA1','BMA2','Ridge','LARs','EN','NNG','Mean'};
Methods2 = {'AR','ARX','CADL','Boost','BMA1','BMA2','LARs','EN','NNG','Mean'};
Methods3 = {'AR','ARX','CADL','Boost','BMA1','BMA2','Ridge','LARs','EN','NNG','Mean'};
Methods4 = {'AR','ARX','CADL','Boost','BMA1','BMA2','Ridge','LARs','EN','NNG','Mean'};
AllMethodsRecRol= {'Recur','Roll'};
PCMethods = {'PCA','ICA','SPCA'};
Specification = {'SP1','SP1L','SP2','SP2L','SP3','SP4'};

% TABLE 01 ----------------------------------------------------------------
% (1) Min of each method 
[val01,ix_sp1_rec] =min(MSEr_SP1_Rec(2:end,:,:,:));
[val02,ix_sp1_rol] =min(MSEr_SP1_Rol(2:end,:,:,:));
[val03,ix_sp1l_rec]=min(MSEr_SP1L_Rec(2:end,:,:,:));
[val04,ix_sp1l_rol]=min(MSEr_SP1L_Rol(2:end,:,:,:));
[val05,ix_sp2_rec] =min(MSEr_SP2_Rec(2:end,:,:,:));
[val06,ix_sp2_rol] =min(MSEr_SP2_Rol(2:end,:,:,:));
[val07,ix_sp2l_rec]=min(MSEr_SP2L_Rec(2:end,:,:,:));
[val08,ix_sp2l_rol]=min(MSEr_SP2L_Rol(2:end,:,:,:));
[val09,ix_sp3_rec] =min(MSEr_SP3_Rec(2:end,:,:,:));
[val10,ix_sp3_rol] =min(MSEr_SP3_Rol(2:end,:,:,:));
[val11,ix_sp4_rec] =min(MSEr_SP4_Rec(2:end,:,:,:));
[val12,ix_sp4_rol] =min(MSEr_SP4_Rol(2:end,:,:,:));

% valxx(1,j,hh,mm)
% -------------------------------------------------------------------------
% TABLE 01 - Summary of MSFE-best Models Along Target Variable (NUMERIC)
for hh = 1:1:3
        MinMethods_Val_SP1_Rec((hh-1)*3+1:hh*3,:) = [val01(:,:,hh,1);val01(:,:,hh,2);val01(:,:,hh,3)];
        MinMethods_Val_SP1_Rol((hh-1)*3+1:hh*3,:) = [val02(:,:,hh,1);val02(:,:,hh,2);val02(:,:,hh,3)];
        MinMethods_Val_SP1L_Rec((hh-1)*3+1:hh*3,:)= [val03(:,:,hh,1);val03(:,:,hh,2);val03(:,:,hh,3)];
        MinMethods_Val_SP1L_Rol((hh-1)*3+1:hh*3,:)= [val04(:,:,hh,1);val04(:,:,hh,2);val04(:,:,hh,3)];
        MinMethods_Val_SP2_Rec((hh-1)*3+1:hh*3,:) = [val05(:,:,hh,1);val05(:,:,hh,2);val05(:,:,hh,3)];
        MinMethods_Val_SP2_Rol((hh-1)*3+1:hh*3,:) = [val06(:,:,hh,1);val06(:,:,hh,2);val06(:,:,hh,3)];
        MinMethods_Val_SP2L_Rec((hh-1)*3+1:hh*3,:)= [val07(:,:,hh,1);val07(:,:,hh,2);val07(:,:,hh,3)];
        MinMethods_Val_SP2L_Rol((hh-1)*3+1:hh*3,:)= [val08(:,:,hh,1);val08(:,:,hh,2);val08(:,:,hh,3)];
end
MinMethods_Val_SP3_Rec = [val09(:,:,1);val09(:,:,2);val09(:,:,3)];
MinMethods_Val_SP3_Rol = [val10(:,:,1);val10(:,:,2);val10(:,:,3)];
MinMethods_Val_SP4_Rec = [val11(:,:,1);val11(:,:,2);val11(:,:,3)];
MinMethods_Val_SP4_Rol = [val12(:,:,1);val12(:,:,2);val12(:,:,3)];

MinMethods_Val_Rec = [MinMethods_Val_SP1_Rec;MinMethods_Val_SP1L_Rec;MinMethods_Val_SP2_Rec;MinMethods_Val_SP2L_Rec;MinMethods_Val_SP3_Rec;MinMethods_Val_SP4_Rec];
MinMethods_Val_Rol = [MinMethods_Val_SP1_Rol;MinMethods_Val_SP1L_Rol;MinMethods_Val_SP2_Rol;MinMethods_Val_SP2L_Rol;MinMethods_Val_SP3_Rol;MinMethods_Val_SP4_Rol];

% -------------------------------------------------------------------------
% TABLE 01 - Summary of MSFE-best Models Along Target Variable (METHODS!!)
ix_sp1_rec((val01>=1))=0;
ix_sp1_rol((val02>=1))=0;
ix_sp1l_rec((val03>=1))=0;
ix_sp1l_rol((val04>=1))=0;
ix_sp2_rec((val05>=1))=0;
ix_sp2_rol((val06>=1))=0;
ix_sp2l_rec((val07>=1))=0;
ix_sp2l_rol((val08>=1))=0;
ix_sp3_rec((val09>=1))=0;
ix_sp3_rol((val10>=1))=0;
ix_sp4_rec((val11>=1))=0;
ix_sp4_rol((val12>=1))=0;

for hh = 1:1:3
        MinMethods_SP1_Rec((hh-1)*3+1:hh*3,:) = [Methods1(ix_sp1_rec(:,:,hh,1)+1); Methods1(ix_sp1_rec(:,:,hh,2)+1); Methods1(ix_sp1_rec(:,:,hh,3)+1)];
        MinMethods_SP1_Rol((hh-1)*3+1:hh*3,:) = [Methods1(ix_sp1_rol(:,:,hh,1)+1); Methods1(ix_sp1_rol(:,:,hh,2)+1); Methods1(ix_sp1_rol(:,:,hh,3)+1)];
        MinMethods_SP1L_Rec((hh-1)*3+1:hh*3,:)= [Methods1(ix_sp1l_rec(:,:,hh,1)+1);Methods1(ix_sp1l_rec(:,:,hh,2)+1);Methods1(ix_sp1l_rec(:,:,hh,3)+1)];
        MinMethods_SP1L_Rol((hh-1)*3+1:hh*3,:)= [Methods1(ix_sp1l_rol(:,:,hh,1)+1);Methods1(ix_sp1l_rol(:,:,hh,2)+1);Methods1(ix_sp1l_rol(:,:,hh,3)+1)];
        MinMethods_SP2_Rec((hh-1)*3+1:hh*3,:) = [Methods2(ix_sp2_rec(:,:,hh,1)+1); Methods2(ix_sp2_rec(:,:,hh,2)+1); Methods2(ix_sp2_rec(:,:,hh,3)+1)];
        MinMethods_SP2_Rol((hh-1)*3+1:hh*3,:) = [Methods2(ix_sp2_rol(:,:,hh,1)+1); Methods2(ix_sp2_rol(:,:,hh,2)+1); Methods2(ix_sp2_rol(:,:,hh,3)+1)];
        MinMethods_SP2L_Rec((hh-1)*3+1:hh*3,:)= [Methods2(ix_sp2l_rec(:,:,hh,1)+1);Methods2(ix_sp2l_rec(:,:,hh,2)+1);Methods2(ix_sp2l_rec(:,:,hh,3)+1)];
        MinMethods_SP2L_Rol((hh-1)*3+1:hh*3,:)= [Methods2(ix_sp2l_rol(:,:,hh,1)+1);Methods2(ix_sp2l_rol(:,:,hh,2)+1);Methods2(ix_sp2l_rol(:,:,hh,3)+1)];
end
MinMethods_SP3_Rec = [Methods3(ix_sp3_rec(:,:,1)+1); Methods3(ix_sp3_rec(:,:,2)+1); Methods3(ix_sp3_rec(:,:,3)+1)];
MinMethods_SP3_Rol = [Methods3(ix_sp3_rol(:,:,1)+1); Methods3(ix_sp3_rol(:,:,2)+1); Methods3(ix_sp3_rol(:,:,3)+1)];
MinMethods_SP4_Rec = [Methods4(ix_sp4_rec(:,:,1)+1); Methods4(ix_sp4_rec(:,:,2)+1); Methods4(ix_sp4_rec(:,:,3)+1)];
MinMethods_SP4_Rol = [Methods4(ix_sp4_rol(:,:,1)+1); Methods4(ix_sp4_rol(:,:,2)+1); Methods4(ix_sp4_rol(:,:,3)+1)];

MinMethods_Rec = [MinMethods_SP1_Rec;MinMethods_SP1L_Rec;MinMethods_SP2_Rec;MinMethods_SP2L_Rec;MinMethods_SP3_Rec;MinMethods_SP4_Rec];
MinMethods_Rol = [MinMethods_SP1_Rol;MinMethods_SP1L_Rol;MinMethods_SP2_Rol;MinMethods_SP2L_Rol;MinMethods_SP3_Rol;MinMethods_SP4_Rol];

% -------------------------------------------------------------------------
% TABLE 02 - Summary of MSFE-best Models of PC Methods Within SP 
for hh = 1 : 1 : 3
    [val_best01(hh,:),ix_vel_best01(hh,:)] = min(MinMethods_Val_SP1_Rec((hh-1)*3+1:3*hh,:));
    [val_best02(hh,:),ix_vel_best02(hh,:)] = min(MinMethods_Val_SP1_Rol((hh-1)*3+1:3*hh,:));
    [val_best03(hh,:),ix_vel_best03(hh,:)] = min(MinMethods_Val_SP1L_Rec((hh-1)*3+1:3*hh,:));
    [val_best04(hh,:),ix_vel_best04(hh,:)] = min(MinMethods_Val_SP1L_Rol((hh-1)*3+1:3*hh,:));
    [val_best05(hh,:),ix_vel_best05(hh,:)] = min(MinMethods_Val_SP2_Rec((hh-1)*3+1:3*hh,:));
    [val_best06(hh,:),ix_vel_best06(hh,:)] = min(MinMethods_Val_SP2_Rol((hh-1)*3+1:3*hh,:));
    [val_best07(hh,:),ix_vel_best07(hh,:)] = min(MinMethods_Val_SP2L_Rec((hh-1)*3+1:3*hh,:));
    [val_best08(hh,:),ix_vel_best08(hh,:)] = min(MinMethods_Val_SP2L_Rol((hh-1)*3+1:3*hh,:));
end

% Version 1 
for hh = 1 : 1 : 3
    MinMethods_Est_Val_SP1((hh-1)*2+1:hh*2,:) = [val_best01(hh,:);val_best02(hh,:)];
    MinMethods_Est_Val_SP1L((hh-1)*2+1:hh*2,:)= [val_best03(hh,:);val_best04(hh,:)];
    MinMethods_Est_Val_SP2((hh-1)*2+1:hh*2,:) = [val_best05(hh,:);val_best06(hh,:)];
    MinMethods_Est_Val_SP2L((hh-1)*2+1:hh*2,:)= [val_best07(hh,:);val_best08(hh,:)];
end
MinMethods_Est_Val_SP3 = [val09(:,:,1);val10(:,:,1);val09(:,:,2);val10(:,:,2);val09(:,:,3);val10(:,:,3)];
MinMethods_Est_Val_SP4 = [val11(:,:,1);val12(:,:,1);val11(:,:,2);val12(:,:,2);val11(:,:,3);val12(:,:,3)];

for hh = 1 : 1 : 3
    MinMethods_Est_PCs_SP1((hh-1)*2+1:hh*2,:) = [PCMethods(ix_vel_best01(hh,:));PCMethods(ix_vel_best02(hh,:))];
    MinMethods_Est_PCs_SP1L((hh-1)*2+1:hh*2,:)= [PCMethods(ix_vel_best03(hh,:));PCMethods(ix_vel_best04(hh,:))];
    MinMethods_Est_PCs_SP2((hh-1)*2+1:hh*2,:) = [PCMethods(ix_vel_best05(hh,:));PCMethods(ix_vel_best06(hh,:))];
    MinMethods_Est_PCs_SP2L((hh-1)*2+1:hh*2,:)= [PCMethods(ix_vel_best07(hh,:));PCMethods(ix_vel_best08(hh,:))];
end

% (NUMERIC)
MinMethods_Est_Val = [MinMethods_Est_Val_SP1;MinMethods_Est_Val_SP1L;MinMethods_Est_Val_SP2;MinMethods_Est_Val_SP2L;MinMethods_Est_Val_SP3;MinMethods_Est_Val_SP4];
% (PCs)
MinMethods_Est_PCs = [MinMethods_Est_PCs_SP1;MinMethods_Est_PCs_SP1L;MinMethods_Est_PCs_SP2;MinMethods_Est_PCs_SP2L];

% Version 2 - Recursive, Rolling Each

% (NUMERIC)
MinMethods_Best_Val_Rec = [val_best01;val_best03;val_best05;val_best07;MinMethods_Val_SP3_Rec;MinMethods_Val_SP4_Rec];
MinMethods_Best_Val_Rol = [val_best02;val_best04;val_best06;val_best08;MinMethods_Val_SP3_Rol;MinMethods_Val_SP4_Rol];

% (PCs)
MinMethods_Best_PCs_Rec = [PCMethods(ix_vel_best01);PCMethods(ix_vel_best03);PCMethods(ix_vel_best05);PCMethods(ix_vel_best07)];
MinMethods_Best_PCs_Rol = [PCMethods(ix_vel_best02);PCMethods(ix_vel_best04);PCMethods(ix_vel_best06);PCMethods(ix_vel_best08)];

% Version 3 - Method + PCs
for hh = 1:1:3
    temp_MinMethods1 = MinMethods_SP1_Rec((hh-1)*3+1:hh*3,:);
    temp_MinMethods2 = MinMethods_SP1_Rol((hh-1)*3+1:hh*3,:);
    temp_MinMethods3 = MinMethods_SP1L_Rec((hh-1)*3+1:hh*3,:);
    temp_MinMethods4 = MinMethods_SP1L_Rol((hh-1)*3+1:hh*3,:);
    temp_MinMethods5 = MinMethods_SP2_Rec((hh-1)*3+1:hh*3,:);
    temp_MinMethods6 = MinMethods_SP2_Rol((hh-1)*3+1:hh*3,:);
    temp_MinMethods7 = MinMethods_SP2L_Rec((hh-1)*3+1:hh*3,:);
    temp_MinMethods8 = MinMethods_SP2L_Rol((hh-1)*3+1:hh*3,:);
    for jj = 1:1:11
        MinMethods_PC_Combi_SP1_Rec((hh-1)*2+1:hh*2,jj)  = [PCMethods(ix_vel_best01(hh,jj));temp_MinMethods1(ix_vel_best01(hh,jj),jj)];     
        MinMethods_PC_Combi_SP1_Rol((hh-1)*2+1:hh*2,jj)  = [PCMethods(ix_vel_best02(hh,jj));temp_MinMethods2(ix_vel_best02(hh,jj),jj)];     
        MinMethods_PC_Combi_SP1L_Rec((hh-1)*2+1:hh*2,jj) = [PCMethods(ix_vel_best03(hh,jj));temp_MinMethods3(ix_vel_best03(hh,jj),jj)];     
        MinMethods_PC_Combi_SP1L_Rol((hh-1)*2+1:hh*2,jj) = [PCMethods(ix_vel_best04(hh,jj));temp_MinMethods4(ix_vel_best04(hh,jj),jj)];     
        MinMethods_PC_Combi_SP2_Rec((hh-1)*2+1:hh*2,jj)  = [PCMethods(ix_vel_best05(hh,jj));temp_MinMethods5(ix_vel_best05(hh,jj),jj)];     
        MinMethods_PC_Combi_SP2_Rol((hh-1)*2+1:hh*2,jj)  = [PCMethods(ix_vel_best06(hh,jj));temp_MinMethods6(ix_vel_best06(hh,jj),jj)];     
        MinMethods_PC_Combi_SP2L_Rec((hh-1)*2+1:hh*2,jj) = [PCMethods(ix_vel_best07(hh,jj));temp_MinMethods7(ix_vel_best07(hh,jj),jj)];     
        MinMethods_PC_Combi_SP2L_Rol((hh-1)*2+1:hh*2,jj) = [PCMethods(ix_vel_best08(hh,jj));temp_MinMethods8(ix_vel_best08(hh,jj),jj)];     
    end
end
clear temp_*

MinMethods_PC_Combi_Rec = [MinMethods_PC_Combi_SP1_Rec;MinMethods_PC_Combi_SP1L_Rec;MinMethods_PC_Combi_SP2_Rec;MinMethods_PC_Combi_SP2L_Rec];
MinMethods_PC_Combi_Rol = [MinMethods_PC_Combi_SP1_Rol;MinMethods_PC_Combi_SP1L_Rol;MinMethods_PC_Combi_SP2_Rol;MinMethods_PC_Combi_SP2L_Rol];

% -------------------------------------------------------------------------
% TABLE 03 - Summary of MSFE-best Models for PC, Estimation within Spec. 
% Final Result : MinMethods_Combi_Spec
for gg = 1:1:18
    [MinMethods_Est_Best_Val(gg,:),ix_est_best(gg,:)] = min(MinMethods_Est_Val((gg-1)*2+1:gg*2,:));
end    
MinMethods_Est_Best = AllMethodsRecRol(ix_est_best);

for gg = 1:1:12
    for jj = 1:1:11
        if ix_est_best(gg,jj) == 1
            MinMethods_Combi_Spec((gg-1)*3+1:gg*3,jj) = [MinMethods_Est_Best(gg,jj);MinMethods_PC_Combi_Rec((gg-1)*2+1:gg*2,jj)];
        else
            MinMethods_Combi_Spec((gg-1)*3+1:gg*3,jj) = [MinMethods_Est_Best(gg,jj);MinMethods_PC_Combi_Rol((gg-1)*2+1:gg*2,jj)];
        end
    end
end

for gg = 1:1:6
    for jj = 1:1:11
        if ix_est_best(gg+12,jj) == 1
            MinMethods_Combi_Spec((gg-1)*2+1+36:gg*2+36,jj) = [MinMethods_Est_Best(gg+12,jj);MinMethods_Rec(gg+36,jj)];
        else 
            MinMethods_Combi_Spec((gg-1)*2+1+36:gg*2+36,jj) = [MinMethods_Est_Best(gg+12,jj);MinMethods_Rol(gg+36,jj)];
        end
    end
end

% Version 2 - Sort by Horizon
for sp = 1:1:6
    MinMethods_Est_Best_Val_byH01(sp,:) = MinMethods_Est_Best_Val((sp-1)*3+1,:);
    MinMethods_Est_Best_Val_byH03(sp,:) = MinMethods_Est_Best_Val((sp-1)*3+2,:);
    MinMethods_Est_Best_Val_byH12(sp,:) = MinMethods_Est_Best_Val((sp-1)*3+3,:);
end
MinMethods_Est_Best_Val_byH = [MinMethods_Est_Best_Val_byH01;MinMethods_Est_Best_Val_byH03;MinMethods_Est_Best_Val_byH12];
for sp = 1:1:4
    MinMethods_Combi_Spec_byH01((sp-1)*3+1:sp*3,:) = MinMethods_Combi_Spec((sp-1)*9+1:(sp-1)*9+3,:);
    MinMethods_Combi_Spec_byH03((sp-1)*3+1:sp*3,:) = MinMethods_Combi_Spec((sp-1)*9+4:(sp-1)*9+6,:);
    MinMethods_Combi_Spec_byH12((sp-1)*3+1:sp*3,:) = MinMethods_Combi_Spec((sp-1)*9+7:(sp-1)*9+9,:);
end
MinMethods_Combi_Spec_byH01(13:16,:) = [MinMethods_Combi_Spec(37:38,:);MinMethods_Combi_Spec(43:44,:)];
MinMethods_Combi_Spec_byH03(13:16,:) = [MinMethods_Combi_Spec(39:40,:);MinMethods_Combi_Spec(45:46,:)];
MinMethods_Combi_Spec_byH12(13:16,:) = [MinMethods_Combi_Spec(41:42,:);MinMethods_Combi_Spec(47:48,:)];

MinMethods_Combi_Spec_byH =[MinMethods_Combi_Spec_byH01;MinMethods_Combi_Spec_byH03;MinMethods_Combi_Spec_byH12];

% -------------------------------------------------------------------------
% TABLE 04 - Summary of MSFE-best Models for only Horizon! 
for hh = 1:1:3
    [MinMethods_ALL_Val(hh,:),ix_spec_all(hh,:)] = min(MinMethods_Est_Best_Val_byH((hh-1)*6+1:hh*6,:));
end

for hh = 1:1:3
    for jj = 1:1:11
        if ix_spec_all(hh,jj)<=4
            MinMethods_ALL((hh-1)*4+1:hh*4,jj) = [Specification(ix_spec_all(hh,jj));MinMethods_Combi_Spec((ix_spec_all(hh,jj)-1)*9+(hh-1)*3+1:(ix_spec_all(hh,jj)-1)*9+(hh-1)*3+3,jj)];
        else
            MinMethods_ALL((hh-1)*4+1:hh*4,jj) = [Specification(ix_spec_all(hh,jj));MinMethods_Combi_Spec(36+(ix_spec_all(hh,jj)-5)*6+(hh-1)*2+1,jj);{'N/A'};MinMethods_Combi_Spec(36+(ix_spec_all(hh,jj)-5)*6+(hh-1)*2+2,jj)];
        end
    end
end











% Table 3 

% Update along with forecast horizon (2016.2.10)
MinMethods_Val_H1_Rec = [val01(:,:,1,1);val01(:,:,1,2);val01(:,:,1,3);...
                         val03(:,:,1,1);val03(:,:,1,2);val03(:,:,1,3);...
                         val05(:,:,1,1);val05(:,:,1,2);val05(:,:,1,3);...
                         val07(:,:,1,1);val07(:,:,1,2);val07(:,:,1,3);...
                         val09(:,:,1);val11(:,:,1)];
MinMethods_Val_H3_Rec = [val01(:,:,2,1);val01(:,:,2,2);val01(:,:,2,3);...
                         val03(:,:,2,1);val03(:,:,2,2);val03(:,:,2,3);...
                         val05(:,:,2,1);val05(:,:,2,2);val05(:,:,2,3);...
                         val07(:,:,2,1);val07(:,:,2,2);val07(:,:,2,3);...
                         val09(:,:,2);val11(:,:,2)];
MinMethods_Val_H12_Rec = [val01(:,:,3,1);val01(:,:,3,2);val01(:,:,3,3);...
                         val03(:,:,3,1);val03(:,:,3,2);val03(:,:,3,3);...
                         val05(:,:,3,1);val05(:,:,3,2);val05(:,:,3,3);...
                         val07(:,:,3,1);val07(:,:,3,2);val07(:,:,3,3);...
                         val09(:,:,3);val11(:,:,3)];
MinMethods_Val_Rec_by_Horizon = [MinMethods_Val_H1_Rec;MinMethods_Val_H3_Rec;MinMethods_Val_H12_Rec];

MinMethods_Val_H1_Rol = [val02(:,:,1,1);val02(:,:,1,2);val02(:,:,1,3);...
                         val04(:,:,1,1);val04(:,:,1,2);val04(:,:,1,3);...
                         val06(:,:,1,1);val06(:,:,1,2);val06(:,:,1,3);...
                         val08(:,:,1,1);val08(:,:,1,2);val08(:,:,1,3);...
                         val10(:,:,1);val12(:,:,1)];
MinMethods_Val_H3_Rol = [val02(:,:,2,1);val02(:,:,2,2);val02(:,:,2,3);...
                         val04(:,:,2,1);val04(:,:,2,2);val04(:,:,2,3);...
                         val06(:,:,2,1);val06(:,:,2,2);val06(:,:,2,3);...
                         val08(:,:,2,1);val08(:,:,2,2);val08(:,:,2,3);...
                         val10(:,:,2);val12(:,:,2)];
MinMethods_Val_H12_Rol = [val02(:,:,3,1);val02(:,:,3,2);val02(:,:,3,3);...
                         val04(:,:,3,1);val04(:,:,3,2);val04(:,:,3,3);...
                         val06(:,:,3,1);val06(:,:,3,2);val06(:,:,3,3);...
                         val08(:,:,3,1);val08(:,:,3,2);val08(:,:,3,3);...
                         val10(:,:,3);val12(:,:,3)];
MinMethods_Val_Rol_by_Horizon = [MinMethods_Val_H1_Rol;MinMethods_Val_H3_Rol;MinMethods_Val_H12_Rol];

% Table 4 
Index.rec.h1 = [ix_sp1_rec(:,:,1,1)+1;ix_sp1_rec(:,:,1,2)+1;ix_sp1_rec(:,:,1,3)+1;...
            ix_sp1l_rec(:,:,1,1)+1;ix_sp1l_rec(:,:,1,2)+1;ix_sp1l_rec(:,:,1,3)+1;...
            ix_sp2_rec(:,:,1,1)+1;ix_sp2_rec(:,:,1,2)+1;ix_sp2_rec(:,:,1,3)+1;...
            ix_sp2l_rec(:,:,1,1)+1;ix_sp2l_rec(:,:,1,2)+1;ix_sp2l_rec(:,:,1,3)+1;...
            ix_sp3_rec(:,:,1,1)+1;ix_sp4_rec(:,:,1,1)+1];
Index.rec.h3 = [ix_sp1_rec(:,:,2,1)+1;ix_sp1_rec(:,:,2,2)+1;ix_sp1_rec(:,:,2,3)+1;...
            ix_sp1l_rec(:,:,2,1)+1;ix_sp1l_rec(:,:,2,2)+1;ix_sp1l_rec(:,:,2,3)+1;...
            ix_sp2_rec(:,:,2,1)+1;ix_sp2_rec(:,:,2,2)+1;ix_sp2_rec(:,:,2,3)+1;...
            ix_sp2l_rec(:,:,2,1)+1;ix_sp2l_rec(:,:,2,2)+1;ix_sp2l_rec(:,:,2,3)+1;...
            ix_sp3_rec(:,:,2,1)+1;ix_sp4_rec(:,:,2,1)+1];
Index.rec.h12 = [ix_sp1_rec(:,:,3,1)+1;ix_sp1_rec(:,:,3,2)+1;ix_sp1_rec(:,:,3,3)+1;...
            ix_sp1l_rec(:,:,3,1)+1;ix_sp1l_rec(:,:,3,2)+1;ix_sp1l_rec(:,:,3,3)+1;...
            ix_sp2_rec(:,:,3,1)+1;ix_sp2_rec(:,:,3,2)+1;ix_sp2_rec(:,:,3,3)+1;...
            ix_sp2l_rec(:,:,3,1)+1;ix_sp2l_rec(:,:,3,2)+1;ix_sp2l_rec(:,:,3,3)+1;...
            ix_sp3_rec(:,:,3,1)+1;ix_sp4_rec(:,:,3,1)+1];

Index.rol.h1 = [ix_sp1_rol(:,:,1,1)+1;ix_sp1_rol(:,:,1,2)+1;ix_sp1_rol(:,:,1,3)+1;...
            ix_sp1l_rol(:,:,1,1)+1;ix_sp1l_rol(:,:,1,2)+1;ix_sp1l_rol(:,:,1,3)+1;...
            ix_sp2_rol(:,:,1,1)+1;ix_sp2_rol(:,:,1,2)+1;ix_sp2_rol(:,:,1,3)+1;...
            ix_sp2l_rol(:,:,1,1)+1;ix_sp2l_rol(:,:,1,2)+1;ix_sp2l_rol(:,:,1,3)+1;...
            ix_sp3_rol(:,:,1,1)+1;ix_sp4_rol(:,:,1,1)+1];
Index.rol.h3 = [ix_sp1_rol(:,:,2,1)+1;ix_sp1_rol(:,:,2,2)+1;ix_sp1_rol(:,:,2,3)+1;...
            ix_sp1l_rol(:,:,2,1)+1;ix_sp1l_rol(:,:,2,2)+1;ix_sp1l_rol(:,:,2,3)+1;...
            ix_sp2_rol(:,:,2,1)+1;ix_sp2_rol(:,:,2,2)+1;ix_sp2_rol(:,:,2,3)+1;...
            ix_sp2l_rol(:,:,2,1)+1;ix_sp2l_rol(:,:,2,2)+1;ix_sp2l_rol(:,:,2,3)+1;...
            ix_sp3_rol(:,:,2,1)+1;ix_sp4_rol(:,:,2,1)+1];
Index.rol.h12 = [ix_sp1_rol(:,:,3,1)+1;ix_sp1_rol(:,:,3,2)+1;ix_sp1_rol(:,:,3,3)+1;...
            ix_sp1l_rol(:,:,3,1)+1;ix_sp1l_rol(:,:,3,2)+1;ix_sp1l_rol(:,:,3,3)+1;...
            ix_sp2_rol(:,:,3,1)+1;ix_sp2_rol(:,:,3,2)+1;ix_sp2_rol(:,:,3,3)+1;...
            ix_sp2l_rol(:,:,3,1)+1;ix_sp2l_rol(:,:,3,2)+1;ix_sp2l_rol(:,:,3,3)+1;...
            ix_sp3_rol(:,:,3,1)+1;ix_sp4_rol(:,:,3,1)+1];



Index.SP1_REC = [ix_sp1_rec(:,:,1,1)+1; ix_sp1_rec(:,:,1,2)+1; ix_sp1_rec(:,:,1,3)+1;...
                 ix_sp1_rec(:,:,2,1)+1; ix_sp1_rec(:,:,2,2)+1; ix_sp1_rec(:,:,2,3)+1;...
                 ix_sp1_rec(:,:,3,1)+1; ix_sp1_rec(:,:,3,2)+1; ix_sp1_rec(:,:,3,3)+1];
Index.SP1L_REC = [ix_sp1l_rec(:,:,1,1)+1; ix_sp1l_rec(:,:,1,2)+1; ix_sp1l_rec(:,:,1,3)+1;...
                 ix_sp1l_rec(:,:,2,1)+1; ix_sp1l_rec(:,:,2,2)+1; ix_sp1l_rec(:,:,2,3)+1;...
                 ix_sp1l_rec(:,:,3,1)+1; ix_sp1l_rec(:,:,3,2)+1; ix_sp1l_rec(:,:,3,3)+1];
Index.SP2_REC = [ix_sp2_rec(:,:,1,1)+1; ix_sp2_rec(:,:,1,2)+1; ix_sp2_rec(:,:,1,3)+1;...
                 ix_sp2_rec(:,:,2,1)+1; ix_sp2_rec(:,:,2,2)+1; ix_sp2_rec(:,:,2,3)+1;...
                 ix_sp2_rec(:,:,3,1)+1; ix_sp2_rec(:,:,3,2)+1; ix_sp2_rec(:,:,3,3)+1];
Index.SP2L_REC = [ix_sp2l_rec(:,:,1,1)+1; ix_sp2l_rec(:,:,1,2)+1; ix_sp2l_rec(:,:,1,3)+1;...
                 ix_sp2l_rec(:,:,2,1)+1; ix_sp2l_rec(:,:,2,2)+1; ix_sp2l_rec(:,:,2,3)+1;...
                 ix_sp2l_rec(:,:,3,1)+1; ix_sp2l_rec(:,:,3,2)+1; ix_sp2l_rec(:,:,3,3)+1];
Index.SP3_REC = [ix_sp1_rec(:,:,1)+1; ix_sp1_rec(:,:,2)+1; ix_sp1_rec(:,:,3)+1];
Index.SP4_REC = [ix_sp1_rec(:,:,1)+1; ix_sp1_rec(:,:,2)+1; ix_sp1_rec(:,:,3)+1];

Index.SP1_ROL = [ix_sp1_rol(:,:,1,1)+1; ix_sp1_rol(:,:,1,2)+1; ix_sp1_rol(:,:,1,3)+1;...
                 ix_sp1_rol(:,:,2,1)+1; ix_sp1_rol(:,:,2,2)+1; ix_sp1_rol(:,:,2,3)+1;...
                 ix_sp1_rol(:,:,3,1)+1; ix_sp1_rol(:,:,3,2)+1; ix_sp1_rol(:,:,3,3)+1];
Index.SP1L_ROL = [ix_sp1l_rol(:,:,1,1)+1; ix_sp1l_rol(:,:,1,2)+1; ix_sp1l_rol(:,:,1,3)+1;...
                 ix_sp1l_rol(:,:,2,1)+1; ix_sp1l_rol(:,:,2,2)+1; ix_sp1l_rol(:,:,2,3)+1;...
                 ix_sp1l_rol(:,:,3,1)+1; ix_sp1l_rol(:,:,3,2)+1; ix_sp1l_rol(:,:,3,3)+1];
Index.SP2_ROL = [ix_sp2_rol(:,:,1,1)+1; ix_sp2_rol(:,:,1,2)+1; ix_sp2_rol(:,:,1,3)+1;...
                 ix_sp2_rol(:,:,2,1)+1; ix_sp2_rol(:,:,2,2)+1; ix_sp2_rol(:,:,2,3)+1;...
                 ix_sp2_rol(:,:,3,1)+1; ix_sp2_rol(:,:,3,2)+1; ix_sp2_rol(:,:,3,3)+1];
Index.SP2L_ROL = [ix_sp2l_rol(:,:,1,1)+1; ix_sp2l_rol(:,:,1,2)+1; ix_sp2l_rol(:,:,1,3)+1;...
                 ix_sp2l_rol(:,:,2,1)+1; ix_sp2l_rol(:,:,2,2)+1; ix_sp2l_rol(:,:,2,3)+1;...
                 ix_sp2l_rol(:,:,3,1)+1; ix_sp2l_rol(:,:,3,2)+1; ix_sp2l_rol(:,:,3,3)+1];
Index.SP3_ROL = [ix_sp1_rol(:,:,1)+1; ix_sp1_rol(:,:,2)+1; ix_sp1_rol(:,:,3)+1];
Index.SP4_ROL = [ix_sp1_rol(:,:,1)+1; ix_sp1_rol(:,:,2)+1; ix_sp1_rol(:,:,3)+1];



for hh = 1:1:3
        MinMethods_SP1_Rec((hh-1)*3+1:hh*3,:) = [Methods1(ix_sp1_rec(:,:,hh,1)+1); Methods1(ix_sp1_rec(:,:,hh,2)+1); Methods1(ix_sp1_rec(:,:,hh,3)+1)];
        MinMethods_SP1_Rol((hh-1)*3+1:hh*3,:) = [Methods1(ix_sp1_rol(:,:,hh,1)+1); Methods1(ix_sp1_rol(:,:,hh,2)+1); Methods1(ix_sp1_rol(:,:,hh,3)+1)];
        MinMethods_SP1L_Rec((hh-1)*3+1:hh*3,:)= [Methods1(ix_sp1l_rec(:,:,hh,1)+1);Methods1(ix_sp1l_rec(:,:,hh,2)+1);Methods1(ix_sp1l_rec(:,:,hh,3)+1)];
        MinMethods_SP1L_Rol((hh-1)*3+1:hh*3,:)= [Methods1(ix_sp1l_rol(:,:,hh,1)+1);Methods1(ix_sp1l_rol(:,:,hh,2)+1);Methods1(ix_sp1l_rol(:,:,hh,3)+1)];
        MinMethods_SP2_Rec((hh-1)*3+1:hh*3,:) = [Methods2(ix_sp2_rec(:,:,hh,1)+1); Methods2(ix_sp2_rec(:,:,hh,2)+1); Methods2(ix_sp2_rec(:,:,hh,3)+1)];
        MinMethods_SP2_Rol((hh-1)*3+1:hh*3,:) = [Methods2(ix_sp2_rol(:,:,hh,1)+1); Methods2(ix_sp2_rol(:,:,hh,2)+1); Methods2(ix_sp2_rol(:,:,hh,3)+1)];
        MinMethods_SP2L_Rec((hh-1)*3+1:hh*3,:)= [Methods2(ix_sp2l_rec(:,:,hh,1)+1);Methods2(ix_sp2l_rec(:,:,hh,2)+1);Methods2(ix_sp2l_rec(:,:,hh,3)+1)];
        MinMethods_SP2L_Rol((hh-1)*3+1:hh*3,:)= [Methods2(ix_sp2l_rol(:,:,hh,1)+1);Methods2(ix_sp2l_rol(:,:,hh,2)+1);Methods2(ix_sp2l_rol(:,:,hh,3)+1)];
end
MinMethods_SP3_Rec = [Methods3(ix_sp3_rec(:,:,1)+1); Methods3(ix_sp3_rec(:,:,2)+1); Methods3(ix_sp3_rec(:,:,3)+1)];
MinMethods_SP3_Rol = [Methods3(ix_sp3_rol(:,:,1)+1); Methods3(ix_sp3_rol(:,:,2)+1); Methods3(ix_sp3_rol(:,:,3)+1)];
MinMethods_SP4_Rec = [Methods4(ix_sp4_rec(:,:,1)+1); Methods4(ix_sp4_rec(:,:,2)+1); Methods4(ix_sp4_rec(:,:,3)+1)];
MinMethods_SP4_Rol = [Methods4(ix_sp4_rol(:,:,1)+1); Methods4(ix_sp4_rol(:,:,2)+1); Methods4(ix_sp4_rol(:,:,3)+1)];

MinMethods_Rec = [MinMethods_SP1_Rec;MinMethods_SP1L_Rec;MinMethods_SP2_Rec;MinMethods_SP2L_Rec;MinMethods_SP3_Rec;MinMethods_SP4_Rec];
MinMethods_Rol = [MinMethods_SP1_Rol;MinMethods_SP1L_Rol;MinMethods_SP2_Rol;MinMethods_SP2L_Rol;MinMethods_SP3_Rol;MinMethods_SP4_Rol];
