% MATLAB Code for "Mining Big Data Using Parsimonious Factor and Shrinkage 
% Methods" By Hyun Hak Kim

% Estimating Specification Type 1 

% Original Data : 144 Monthly Macroeconomic Series from Jan 1960 - May 2009
% Since the copyright of data, it is missing in this program. 

% INSTRUCTION 1. Data 
% Data file is supposed to be TxN matrix where T is time and N is the
% number of data. It must be transformed appropriately following stationarity.  
disp(' ')
disp('PROGRAM for')
disp('Mining Big Data Using Parsimonious Factor and Shrinkage Methods')
disp('by Hyun Hak Kim')

disp(' ')
%data = input('Type in the title of data here, or if you do not have data and run with artificial data, just enter');
%if isempty(data)==1
%    data = dgp1;
%end

% Call orginal data files.
load Dataset02.mat;         

% Parameter Setting -------------------------------------------------------
c = 1.96;                   % Critical Value for Bagging 
M = 50;                     % Boosting iteration
nburn = 100; nkeep = 1000;  % Loop for BMA
hmax = 12; pmax = 4;        % Setting for max horizon and max lag.
sp = 156;   rw = 156;       % Starting period of forecasting // Rolling windows size
intv = 20;                  % For interval of progress display.

% Data Allocation ---------------------------------------------------------
xx = TrDataTr;              % Set explanatory data which are alread transformed. 
yy = TrYvarTr;              % Set dependant data which are alread transformed.

% Estimation and Specification Type SETUP -----------------------------------------------
disp(' ');
disp('Starting Forecasting for FACTOR MODEL');
disp(' ');
disp('Which Specification Type do you want to run?')
spectype = input(' 1 for Specification Type1 without lags, 2 for Specification Type1 without lags,3 for Specification Type3, 4 for Specification Type4, 5 for Specification Type1 with lags,6 for Specification Type2 with lags');
disp(' ');
disp('Which Estimation Strategy do you want to use?')
rero = input('Select 1 for Recursive Model, 2 for Rolling Estimation Model - ');
disp(' ');
if spectype ~= 3&&4
    disp('Which Factor Construction Method do you want to use?')
    facmet = input('Select 1 for Principal Component Analysis, 2 for Independent Component Analysis, 3 for Sparse Principal Component Analysis ');
end

disp(' ');
disp('Which methods do you want to run?');
mcontrol = input('If you want to run all methods, type in 1 and enter. If you want to run some ot them, please just enter');
if mcontrol == 1
    mc = ones(1,13);            % All estimation are turned on. 
else
    mc = zeros(1,13);
 
mc(2,1)  = input('If you want to run ARX model, type in 1. Otherwise, just enter');
mc(3,1)  = input('If you want to run CDAL model, type in 1. Otherwise, just enter');
mc(4,1)  = input('If you want to run FAAR model, type in 1. Otherwise, just enter');
mc(5,1)  = input('If you want to run PCR model, type in 1. Otherwise, just enter');
mc(6,1)  = input('If you want to run BAGGING model, type in 1. Otherwise, just enter');
mc(7,1)  = input('If you want to run BOOSTING model, type in 1. Otherwise, just enter');
mc(8,1)  = input('If you want to run BMA1model, type in 1. Otherwise, just enter');
mc(9,1)  = input('If you want to run BMA2 model, type in 1. Otherwise, just enter');
mc(10,1) = input('If you want to run RIDGE model, type in 1. Otherwise, just enter');
mc(11,1) = input('If you want to run LAR model, type in 1. Otherwise, just enter');
mc(12,1) = input('If you want to run EN model, type in 1. Otherwise, just enter');
mc(10,1) = input('If you want to run NNG model, type in 1. Otherwise, just enter');
end
    
% If method is 1, it's on. else if's off. 

[ mx , nx ] = size(xx);[ my , ny ] = size(yy);

% Allocate predicted value matrix 
yhat_ar=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_ols=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_CADL=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_faar=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_pcr=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_bag=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_cbst=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_bma1=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_bma2=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_ridge=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_lars=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_en=zeros(mx-sp-hmax-pmax+2,ny,4);
yhat_nng=zeros(mx-sp-hmax-pmax+2,ny,4);

disp(' ');
disp('Progress Report');
disp(' ')
        
% Allocate matrix for lag selection and number of selected factors. 
seld_all = zeros(mx-sp-hmax-pmax+2,ny);
n_fac = zeros(mx-sp-hmax-pmax+2,ny,4);
   

% Main Loop Program : Specification Type 1 w/o Lags-------------------------------------------------------

%if spectype == 1
    [yhat_ar,yhat_ols,yhat_CADL,yhat_faar,yhat_pcr,yhat_bag,yhat_cbst,yhat_bma1,yhat_bma2,yhat_ridge,yhat_lars,yhat_en,yhat_nng] = spectype1(ny,mx,mc,xx,yy,facmet,rero,YInd)
%elseif spectype == 2
%    [] = spectype1(nx,ny,xx,yy,rero);
%end


disp(' ')
disp('End of the Estimation ')

% Result ------------------------------------------------------------------ 

Y_real = TrYvarTr(end-457+36:end,:); % Actual Value : Mar.1974~May.2009

Yhat(:,:,:,1)=yhat_ar;Yhat(:,:,:,2)=yhat_ols; 
Yhat(:,:,:,3)=yhat_CADL;Yhat(:,:,:,4)=yhat_faar; Yhat(:,:,:,5)=yhat_pcr;
Yhat(:,:,:,6)=yhat_bag; Yhat(:,:,:,7)=yhat_cbst; 
Yhat(:,:,:,8)=yhat_bma1; Yhat(:,:,:,9)=yhat_bma2;
Yhat(:,:,:,10)=yhat_ridge; Yhat(:,:,:,11)=yhat_lars; Yhat(:,:,:,12)=yhat_en; Yhat(:,:,:,13)=yhat_nng;
Yhat(:,:,:,14)=sum(Yhat(:,:,:,1:13),4)/13;

Yhat(rows(Yhat),:,:,:) = [];        % Get rid of last forecasting since it is for unobserved sample.(June.2009)
[rr cc dd kk] = size(Yhat);

MSE = zeros(rr,cc,kk,dd);
MSE_ratio = zeros(kk,cc,dd);


for h=1:1:dd
    for l = 1 : 1 : kk
        MSE(:,:,l,h) = (Yhat(:,:,h,l)-Y_real).^2;
    end
end

for h=1:1:dd
    MSE_ratio(1,:,h) = sum(MSE(:,:,1,h));
    for i = 2 : 1 : kk
        MSE_ratio(i,:,h) = sum(MSE(:,:,i,h))./sum(MSE(:,:,1,h));
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Divide MSE into subperiod.
% RW=120 or SP=120 case
% Business Cycle Divide. 

MSE1=MSE(12:69,:,:,:);            % 75:03~79:12 
MSE2=MSE(76:87,:,:,:);            % 80:07~81:06
MSE3=MSE(104:195,:,:,:);          % 82:11~90:06
MSE4=MSE(204:323,:,:,:);          % 91:03~01:02
MSE5=MSE(332:404,:,:,:);          % 01:11~07:11
MSE6=MSE([12:69,76:87,104:195,204:323,332:404],:,:,:);
MSE7=MSE([1:11,70:75,88:103,196:203,324:333,405:422],:,:,:);

[rr cc dd kk]=size(Yhat);

for h=1:1:dd
    MSE1_ratio(1,:,h) = sum(MSE1(:,:,1,h));
    MSE2_ratio(1,:,h) = sum(MSE2(:,:,1,h));
    MSE3_ratio(1,:,h) = sum(MSE3(:,:,1,h));
    MSE4_ratio(1,:,h) = sum(MSE4(:,:,1,h));
    MSE5_ratio(1,:,h) = sum(MSE5(:,:,1,h));
    MSE6_ratio(1,:,h) = sum(MSE6(:,:,1,h));
    MSE7_ratio(1,:,h) = sum(MSE7(:,:,1,h));
    for i = 2 : 1 : kk
        MSE1_ratio(i,:,h) = sum(MSE1(:,:,i,h))./sum(MSE1(:,:,1,h));
        MSE2_ratio(i,:,h) = sum(MSE2(:,:,i,h))./sum(MSE2(:,:,1,h));
        MSE3_ratio(i,:,h) = sum(MSE3(:,:,i,h))./sum(MSE3(:,:,1,h));
        MSE4_ratio(i,:,h) = sum(MSE4(:,:,i,h))./sum(MSE4(:,:,1,h));
        MSE5_ratio(i,:,h) = sum(MSE5(:,:,i,h))./sum(MSE5(:,:,1,h));
        MSE6_ratio(i,:,h) = sum(MSE6(:,:,i,h))./sum(MSE6(:,:,1,h));
        MSE7_ratio(i,:,h) = sum(MSE7(:,:,i,h))./sum(MSE7(:,:,1,h));
    end
end

if rero == 1
    fn1=input('Specify the name of the file to store results: ','s');
    fid=fopen(fn1,'wt');
    
    fprintf(fid, '\n     Table 3. Relative Mean Square Forecast Errors: Recursive Estimation, Specification Type 1 (no lags)  \n');
    fprintf(fid, '\n                                               Panel A: Recursive, h = 1  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,1) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','ARX(SIC)', MSE_ratio(2,:,1) );
    fprintf(fid, '%s  %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Combined-ADL', MSE_ratio(3,:,1) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','FAAR', MSE_ratio(4,:,1) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','PCR', MSE_ratio(5,:,1) );
    fprintf(fid, '%s       %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Bagging', MSE_ratio(6,:,1) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(7,:,1) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(8,:,1) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(9,:,1) );
    fprintf(fid, '%s         %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Ridge', MSE_ratio(10,:,1) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(11,:,1) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(12,:,1) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(13,:,1) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(14,:,1) );    
    fprintf(fid, '\n                                                Panel B: Recursive, h = 3  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,2) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','ARX(SIC)', MSE_ratio(2,:,2) );
    fprintf(fid, '%s  %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Combined-ADL', MSE_ratio(3,:,2) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','FAAR', MSE_ratio(4,:,2) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','PCR', MSE_ratio(5,:,2) );
    fprintf(fid, '%s       %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Bagging', MSE_ratio(6,:,2) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(7,:,2) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(8,:,2) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(9,:,2) );
    fprintf(fid, '%s         %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Ridge', MSE_ratio(10,:,2) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(11,:,2) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(12,:,2) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(13,:,2) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(14,:,2) );    
    fprintf(fid, '\n                                                Panel C: Recursive, h = 12  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,4) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','ARX(SIC)', MSE_ratio(2,:,4) );
    fprintf(fid, '%s  %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Combined-ADL', MSE_ratio(3,:,4) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','FAAR', MSE_ratio(4,:,4) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','PCR', MSE_ratio(5,:,4) );
    fprintf(fid, '%s       %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Bagging', MSE_ratio(6,:,4) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(7,:,4) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(8,:,4) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(9,:,4) );
    fprintf(fid, '%s         %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Ridge', MSE_ratio(10,:,4) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(11,:,4) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(12,:,4) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(13,:,4) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(14,:,4) );    
    fclose(fid);
else

    fn1=input('Specify the name of the file to store results: ','s');
    fid=fopen(fn1,'wt');
    
    fprintf(fid, '\n     Table 3-1. Relative Mean Square Forecast Errors: Rolling Estimation, Specification Type 1 (no lags)  \n');
    fprintf(fid, '\n                                               Panel A: Rolling, h = 1  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,1) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','ARX(SIC)', MSE_ratio(2,:,1) );
    fprintf(fid, '%s  %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Combined-ADL', MSE_ratio(3,:,1) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','FAAR', MSE_ratio(4,:,1) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','PCR', MSE_ratio(5,:,1) );
    fprintf(fid, '%s       %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Bagging', MSE_ratio(6,:,1) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(7,:,1) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(8,:,1) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(9,:,1) );
    fprintf(fid, '%s         %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Ridge', MSE_ratio(10,:,1) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(11,:,1) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(12,:,1) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(13,:,1) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(14,:,1) );    
    fprintf(fid, '\n                                                Panel B: Rolling, h = 3  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,2) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','ARX(SIC)', MSE_ratio(2,:,2) );
    fprintf(fid, '%s  %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Combined-ADL', MSE_ratio(3,:,2) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','FAAR', MSE_ratio(4,:,2) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','PCR', MSE_ratio(5,:,2) );
    fprintf(fid, '%s       %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Bagging', MSE_ratio(6,:,2) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(7,:,2) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(8,:,2) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(9,:,2) );
    fprintf(fid, '%s         %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Ridge', MSE_ratio(10,:,2) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(11,:,2) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(12,:,2) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(13,:,2) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(14,:,2) );    
    fprintf(fid, '\n                                                Panel C: Rolling, h = 12  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,4) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','ARX(SIC)', MSE_ratio(2,:,4) );
    fprintf(fid, '%s  %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Combined-ADL', MSE_ratio(3,:,4) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','FAAR', MSE_ratio(4,:,4) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','PCR', MSE_ratio(5,:,4) );
    fprintf(fid, '%s       %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Bagging', MSE_ratio(6,:,4) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(7,:,4) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(8,:,4) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(9,:,4) );
    fprintf(fid, '%s         %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Ridge', MSE_ratio(10,:,4) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(11,:,4) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(12,:,4) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(13,:,4) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(14,:,4) );    
    fclose(fid);
end
