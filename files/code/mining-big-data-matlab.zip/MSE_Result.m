% Hyun Hak Kim, 2016.2.10

load MSE_result.mat
%load Index.mat

MSE_AR_REC = MSE_SP1_PCA_REC(:,:,1,[1,2,4]);  
MSE_AR_ROL = MSE_SP1_PCA_ROL(:,:,1,[1,2,4]);  

[~,s2,s3,s4] = size(MSE_SP1_PCA_REC);
hstep = [1,2,4];

for d2 = 1:1:s2
    for d3 = 1:1:s3-1
        for d4 = 1:1:s4-1
            dm_result.SP1_PCA_REC(d2,d3,d4) = dmtest(MSE_AR_REC(:,d2,1,d4),MSE_SP1_PCA_REC(:,d2,d3+1,hstep(d4)));
            dm_result.SP1_ICA_REC(d2,d3,d4) = dmtest(MSE_AR_REC(:,d2,1,d4),MSE_SP1_ICA_REC(:,d2,d3+1,hstep(d4)));
            dm_result.SP1_SPCA_REC(d2,d3,d4) = dmtest(MSE_AR_REC(:,d2,1,d4),MSE_SP1_SPCA_REC(:,d2,d3+1,hstep(d4)));
            dm_result.SP1L_PCA_REC(d2,d3,d4)= dmtest(MSE_AR_REC(:,d2,1,d4),MSE_SP1L_PCA_REC(:,d2,d3+1,hstep(d4)));
            dm_result.SP1L_ICA_REC(d2,d3,d4)= dmtest(MSE_AR_REC(:,d2,1,d4),MSE_SP1L_ICA_REC(:,d2,d3+1,hstep(d4)));
            dm_result.SP1L_SPCA_REC(d2,d3,d4)= dmtest(MSE_AR_REC(:,d2,1,d4),MSE_SP1L_SPCA_REC(:,d2,d3+1,hstep(d4)));
        end
    end
end

[~,s2,s3,s4] = size(MSE_SP2_PCA_REC);
for d2 = 1:1:s2
    for d3 = 1:1:s3-1
        for d4 = 1:1:s4-1
            dm_result.SP2_PCA_REC(d2,d3,d4) = dmtest(MSE_AR_REC(:,d2,1,d4),MSE_SP2_PCA_REC(:,d2,d3+1,hstep(d4)));
            dm_result.SP2_ICA_REC(d2,d3,d4) = dmtest(MSE_AR_REC(:,d2,1,d4),MSE_SP2_ICA_REC(:,d2,d3+1,hstep(d4)));
            dm_result.SP2_SPCA_REC(d2,d3,d4) = dmtest(MSE_AR_REC(:,d2,1,d4),MSE_SP2_SPCA_REC(:,d2,d3+1,hstep(d4)));
            dm_result.SP2L_PCA_REC(d2,d3,d4)= dmtest(MSE_AR_REC(:,d2,1,d4),MSE_SP2L_PCA_REC(:,d2,d3+1,hstep(d4)));
            dm_result.SP2L_ICA_REC(d2,d3,d4)= dmtest(MSE_AR_REC(:,d2,1,d4),MSE_SP2L_ICA_REC(:,d2,d3+1,hstep(d4)));
            dm_result.SP2L_SPCA_REC(d2,d3,d4)= dmtest(MSE_AR_REC(:,d2,1,d4),MSE_SP2L_SPCA_REC(:,d2,d3+1,hstep(d4)));
        end
    end
end
[~,s2,s3,s4] = size(MSE_SP3_REC);
for d2 = 1:1:s2
    for d3 = 1:1:s3-1
        for d4 = 1:1:s4-1
            dm_result.SP3_REC(d2,d3,d4) = dmtest(MSE_AR_REC(:,d2,1,d4),MSE_SP3_REC(:,d2,d3+1,hstep(d4)));
        end
    end
end

[~,s2,s3,s4] = size(MSE_SP4_REC);
for d2 = 1:1:s2
    for d3 = 1:1:s3-1
        for d4 = 1:1:s4-1
            dm_result.SP4_REC(d2,d3,d4) = dmtest(MSE_AR_REC(:,d2,1,d4),MSE_SP4_REC(:,d2,d3+1,hstep(d4)));
        end
    end
end

% Rolling Result
[~,s2,s3,s4] = size(MSE_SP1_PCA_ROL);
hstep = [1,2,4];

for d2 = 1:1:s2
    for d3 = 1:1:s3-1
        for d4 = 1:1:s4-1
            dm_result.SP1_PCA_ROL(d2,d3,d4) = dmtest(MSE_AR_ROL(:,d2,1,d4),MSE_SP1_PCA_ROL(:,d2,d3+1,hstep(d4)));
            dm_result.SP1_ICA_ROL(d2,d3,d4) = dmtest(MSE_AR_ROL(:,d2,1,d4),MSE_SP1_ICA_ROL(:,d2,d3+1,hstep(d4)));
            dm_result.SP1_SPCA_ROL(d2,d3,d4) = dmtest(MSE_AR_ROL(:,d2,1,d4),MSE_SP1_SPCA_ROL(:,d2,d3+1,hstep(d4)));
            dm_result.SP1L_PCA_ROL(d2,d3,d4)= dmtest(MSE_AR_ROL(:,d2,1,d4),MSE_SP1L_PCA_ROL(:,d2,d3+1,hstep(d4)));
            dm_result.SP1L_ICA_ROL(d2,d3,d4)= dmtest(MSE_AR_ROL(:,d2,1,d4),MSE_SP1L_ICA_ROL(:,d2,d3+1,hstep(d4)));
            dm_result.SP1L_SPCA_ROL(d2,d3,d4)= dmtest(MSE_AR_ROL(:,d2,1,d4),MSE_SP1L_SPCA_ROL(:,d2,d3+1,hstep(d4)));
        end
    end
end

[~,s2,s3,s4] = size(MSE_SP2_PCA_ROL);
for d2 = 1:1:s2
    for d3 = 1:1:s3-1
        for d4 = 1:1:s4-1
            dm_result.SP2_PCA_ROL(d2,d3,d4) = dmtest(MSE_AR_ROL(:,d2,1,d4),MSE_SP2_PCA_ROL(:,d2,d3+1,hstep(d4)));
            dm_result.SP2_ICA_ROL(d2,d3,d4) = dmtest(MSE_AR_ROL(:,d2,1,d4),MSE_SP2_ICA_ROL(:,d2,d3+1,hstep(d4)));
            dm_result.SP2_SPCA_ROL(d2,d3,d4) = dmtest(MSE_AR_ROL(:,d2,1,d4),MSE_SP2_SPCA_ROL(:,d2,d3+1,hstep(d4)));
            dm_result.SP2L_PCA_ROL(d2,d3,d4)= dmtest(MSE_AR_ROL(:,d2,1,d4),MSE_SP2L_PCA_ROL(:,d2,d3+1,hstep(d4)));
            dm_result.SP2L_ICA_ROL(d2,d3,d4)= dmtest(MSE_AR_ROL(:,d2,1,d4),MSE_SP2L_ICA_ROL(:,d2,d3+1,hstep(d4)));
            dm_result.SP2L_SPCA_ROL(d2,d3,d4)= dmtest(MSE_AR_ROL(:,d2,1,d4),MSE_SP2L_SPCA_ROL(:,d2,d3+1,hstep(d4)));
        end
    end
end
[~,s2,s3,s4] = size(MSE_SP3_ROL);
for d2 = 1:1:s2
    for d3 = 1:1:s3-1
        for d4 = 1:1:s4-1
            dm_result.SP3_ROL(d2,d3,d4) = dmtest(MSE_AR_ROL(:,d2,1,d4),MSE_SP3_ROL(:,d2,d3+1,hstep(d4)));
        end
    end
end

[~,s2,s3,s4] = size(MSE_SP4_ROL);
for d2 = 1:1:s2
    for d3 = 1:1:s3-1
        for d4 = 1:1:s4-1
            dm_result.SP4_ROL(d2,d3,d4) = dmtest(MSE_AR_ROL(:,d2,1,d4),MSE_SP4_ROL(:,d2,d3+1,hstep(d4)));
        end
    end
end


% Indexing dm_result
[d1,~,~] = size(dm_result.SP1_PCA_REC);
for i1=1:1:d1
     dm_select.h1.SP1_REC(1,i1) = dm_result.SP1_PCA_REC(i1,Index.rec.h1(1,i1)-1,1);
     dm_select.h1.SP1_REC(2,i1) = dm_result.SP1_ICA_REC(i1,Index.rec.h1(2,i1)-1,1);
     dm_select.h1.SP1_REC(3,i1) = dm_result.SP1_SPCA_REC(i1,Index.rec.h1(3,i1)-1,1);
     dm_select.h1.SP1L_REC(1,i1) = dm_result.SP1L_PCA_REC(i1,Index.rec.h1(4,i1)-1,1);
     if Index.rec.h1(5,i1)>1
         dm_select.h1.SP1L_REC(2,i1) = dm_result.SP1L_ICA_REC(i1,Index.rec.h1(5,i1)-1,1);
     else
         dm_select.h1.SP1L_REC(2,i1) = -99999;
     end
     dm_select.h1.SP1L_REC(3,i1) = dm_result.SP1L_SPCA_REC(i1,Index.rec.h1(6,i1)-1,1);
     dm_select.h1.SP2_REC(1,i1) = dm_result.SP2_PCA_REC(i1,Index.rec.h1(7,i1)-1,1);
     dm_select.h1.SP2_REC(2,i1) = dm_result.SP2_ICA_REC(i1,Index.rec.h1(8,i1)-1,1);
     dm_select.h1.SP2_REC(3,i1) = dm_result.SP2_SPCA_REC(i1,Index.rec.h1(9,i1)-1,1);
     dm_select.h1.SP2L_REC(1,i1) = dm_result.SP2L_PCA_REC(i1,Index.rec.h1(10,i1)-1,1);
     dm_select.h1.SP2L_REC(2,i1) = dm_result.SP2L_ICA_REC(i1,Index.rec.h1(11,i1)-1,1);
     dm_select.h1.SP2L_REC(3,i1) = dm_result.SP2L_SPCA_REC(i1,Index.rec.h1(12,i1)-1,1);
     dm_select.h1.SP3_REC(1,i1) = dm_result.SP3_REC(i1,Index.rec.h1(13,i1)-1,1);
     dm_select.h1.SP4_REC(1,i1) = dm_result.SP4_REC(i1,Index.rec.h1(14,i1)-1,1);

     dm_select.h3.SP1_REC(1,i1) = dm_result.SP1_PCA_REC(i1,Index.rec.h3(1,i1)-1,1);
     if Index.rec.h3(2,i1)>1
        dm_select.h3.SP1_REC(2,i1) = dm_result.SP1_ICA_REC(i1,Index.rec.h3(2,i1)-1,1);
     else
        dm_select.h3.SP1_REC(2,i1) = -99999;
     end
     dm_select.h3.SP1_REC(3,i1) = dm_result.SP1_SPCA_REC(i1,Index.rec.h3(3,i1)-1,1);
     dm_select.h3.SP1L_REC(1,i1) = dm_result.SP1L_PCA_REC(i1,Index.rec.h3(4,i1)-1,1);
     if Index.rec.h3(5,i1)>1
         dm_select.h3.SP1L_REC(2,i1) = dm_result.SP1L_ICA_REC(i1,Index.rec.h3(5,i1)-1,1);
     else
         dm_select.h3.SP1L_REC(2,i1) = -99999;
     end
     dm_select.h3.SP1L_REC(3,i1) = dm_result.SP1L_SPCA_REC(i1,Index.rec.h3(6,i1)-1,1);
     dm_select.h3.SP2_REC(1,i1) = dm_result.SP2_PCA_REC(i1,Index.rec.h3(7,i1)-1,1);
     dm_select.h3.SP2_REC(2,i1) = dm_result.SP2_ICA_REC(i1,Index.rec.h3(8,i1)-1,1);
     dm_select.h3.SP2_REC(3,i1) = dm_result.SP2_SPCA_REC(i1,Index.rec.h3(9,i1)-1,1);
     dm_select.h3.SP2L_REC(1,i1) = dm_result.SP2L_PCA_REC(i1,Index.rec.h3(10,i1)-1,1);
     dm_select.h3.SP2L_REC(2,i1) = dm_result.SP2L_ICA_REC(i1,Index.rec.h3(11,i1)-1,1);
     dm_select.h3.SP2L_REC(3,i1) = dm_result.SP2L_SPCA_REC(i1,Index.rec.h3(12,i1)-1,1);
     if Index.rec.h3(13,i1)>1
         dm_select.h3.SP3_REC(1,i1) = dm_result.SP3_REC(i1,Index.rec.h3(13,i1)-1,1);
     else
         dm_select.h3.SP3_REC(1,i1) = -99999;
     end
     dm_select.h3.SP4_REC(1,i1) = dm_result.SP4_REC(i1,Index.rec.h3(14,i1)-1,1);

     if Index.rec.h12(1,i1)>1
        dm_select.h12.SP1_REC(1,i1) = dm_result.SP1_PCA_REC(i1,Index.rec.h12(1,i1)-1,1);
     else
        dm_select.h12.SP1_REC(1,i1) = -99999; 
     end
     if Index.rec.h12(2,i1)>1
         dm_select.h12.SP1_REC(2,i1) = dm_result.SP1_ICA_REC(i1,Index.rec.h12(2,i1)-1,1);
     else
         dm_select.h12.SP1_REC(2,i1) = -99999;
     end
     dm_select.h12.SP1_REC(3,i1) = dm_result.SP1_SPCA_REC(i1,Index.rec.h12(3,i1)-1,1);
     if Index.rec.h12(4,i1)>1
         dm_select.h12.SP1L_REC(1,i1) = dm_result.SP1L_PCA_REC(i1,Index.rec.h12(4,i1)-1,1);
     else
         dm_select.h12.SP1L_REC(1,i1) = -99999;
     end
     if Index.rec.h12(5,i1)>1
         dm_select.h12.SP1L_REC(2,i1) = dm_result.SP1L_ICA_REC(i1,Index.rec.h12(5,i1)-1,1);
     else
         dm_select.h12.SP1L_REC(2,i1) = -999999;
     end
     if Index.rec.h12(6,i1)>1
         dm_select.h12.SP1L_REC(3,i1) = dm_result.SP1L_SPCA_REC(i1,Index.rec.h12(6,i1)-1,1);
     else
         dm_select.h12.SP1L_REC(3,i1) = -999999;
     end
     dm_select.h12.SP2_REC(1,i1) = dm_result.SP2_PCA_REC(i1,Index.rec.h12(7,i1)-1,1);
     dm_select.h12.SP2_REC(2,i1) = dm_result.SP2_ICA_REC(i1,Index.rec.h12(8,i1)-1,1);
     dm_select.h12.SP2_REC(3,i1) = dm_result.SP2_SPCA_REC(i1,Index.rec.h12(9,i1)-1,1);
     dm_select.h12.SP2L_REC(1,i1) = dm_result.SP2L_PCA_REC(i1,Index.rec.h12(10,i1)-1,1);
     dm_select.h12.SP2L_REC(2,i1) = dm_result.SP2L_ICA_REC(i1,Index.rec.h12(11,i1)-1,1);
     dm_select.h12.SP2L_REC(3,i1) = dm_result.SP2L_SPCA_REC(i1,Index.rec.h12(12,i1)-1,1);
     if Index.rec.h12(13,i1)>1
        dm_select.h12.SP3_REC(1,i1) = dm_result.SP3_REC(i1,Index.rec.h12(13,i1)-1,1);
     else
         dm_select.h12.SP3_REC(1,i1) = -99999;
     end
     if Index.rec.h12(14,i1)>1
        dm_select.h12.SP4_REC(1,i1) = dm_result.SP4_REC(i1,Index.rec.h12(14,i1)-1,1);
     else
         dm_select.h12.SP4_REC(1,i1) = -99999;
     end
end

dm_select.rec.h1 = [dm_select.h1.SP1_REC;dm_select.h1.SP1L_REC;...
                    dm_select.h1.SP2_REC;dm_select.h1.SP2L_REC;
                    dm_select.h1.SP3_REC;dm_select.h1.SP4_REC];
dm_select.rec.h3 = [dm_select.h3.SP1_REC;dm_select.h3.SP1L_REC;...
                    dm_select.h3.SP2_REC;dm_select.h3.SP2L_REC;
                    dm_select.h3.SP3_REC;dm_select.h3.SP4_REC];
dm_select.rec.h12 = [dm_select.h12.SP1_REC;dm_select.h12.SP1L_REC;...
                    dm_select.h12.SP2_REC;dm_select.h12.SP2L_REC;
                    dm_select.h12.SP3_REC;dm_select.h12.SP4_REC];
dm_select.rec.all = [dm_select.rec.h1;dm_select.rec.h3;dm_select.rec.h12];
% Indexing dm_result
[d1,~,~] = size(dm_result.SP1_PCA_ROL);
for i1=1:1:d1
     if Index.rol.h1(1,i1)>1; dm_select.h1.SP1_ROL(1,i1)  = dm_result.SP1_PCA_ROL(i1,Index.rol.h1(1,i1)-1,1);     else dm_select.h1.SP1_ROL(1,i1) = -99999;    end;
     if Index.rol.h1(2,i1)>1; dm_select.h1.SP1_ROL(2,i1)  = dm_result.SP1_ICA_ROL(i1,Index.rol.h1(2,i1)-1,1);     else dm_select.h1.SP1_ROL(2,i1) = -99999;    end;
     if Index.rol.h1(3,i1)>1; dm_select.h1.SP1_ROL(3,i1)  = dm_result.SP1_SPCA_ROL(i1,Index.rol.h1(3,i1)-1,1);    else dm_select.h1.SP1_ROL(3,i1) = -99999;    end;
     if Index.rol.h1(4,i1)>1; dm_select.h1.SP1L_ROL(1,i1) = dm_result.SP1L_PCA_ROL(i1,Index.rol.h1(4,i1)-1,1);    else dm_select.h1.SP1L_ROL(1,i1) = -99999;   end;
     if Index.rol.h1(5,i1)>1; dm_select.h1.SP1L_ROL(2,i1) = dm_result.SP1L_ICA_ROL(i1,Index.rol.h1(5,i1)-1,1);    else dm_select.h1.SP1L_ROL(2,i1) = -99999;   end;
     if Index.rol.h1(6,i1)>1; dm_select.h1.SP1L_ROL(3,i1) = dm_result.SP1L_SPCA_ROL(i1,Index.rol.h1(6,i1)-1,1);   else dm_select.h1.SP1L_ROL(3,i1) = -99999;   end;
     if Index.rol.h1(7,i1)>1; dm_select.h1.SP2_ROL(1,i1)  = dm_result.SP2_PCA_ROL(i1,Index.rol.h1(7,i1)-1,1);     else dm_select.h1.SP2_ROL(1,i1) = -99999;    end;
     if Index.rol.h1(8,i1)>1; dm_select.h1.SP2_ROL(2,i1)  = dm_result.SP2_ICA_ROL(i1,Index.rol.h1(8,i1)-1,1);     else dm_select.h1.SP2_ROL(2,i1) = -99999;    end;
     if Index.rol.h1(9,i1)>1; dm_select.h1.SP2_ROL(3,i1)  = dm_result.SP2_SPCA_ROL(i1,Index.rol.h1(9,i1)-1,1);    else dm_select.h1.SP2_ROL(3,i1) = -99999;    end;
     if Index.rol.h1(10,i1)>1;dm_select.h1.SP2L_ROL(1,i1) = dm_result.SP2L_PCA_ROL(i1,Index.rol.h1(10,i1)-1,1);   else dm_select.h1.SP2L_ROL(1,i1) = -99999;   end;
     if Index.rol.h1(11,i1)>1;dm_select.h1.SP2L_ROL(2,i1) = dm_result.SP2L_ICA_ROL(i1,Index.rol.h1(11,i1)-1,1);   else dm_select.h1.SP2L_ROL(2,i1) = -99999;   end;
     if Index.rol.h1(12,i1)>1;dm_select.h1.SP2L_ROL(3,i1) = dm_result.SP2L_SPCA_ROL(i1,Index.rol.h1(12,i1)-1,1);  else dm_select.h1.SP2L_ROL(3,i1) = -99999;   end;
     if Index.rol.h1(13,i1)>1;dm_select.h1.SP3_ROL(1,i1)  = dm_result.SP3_ROL(i1,Index.rol.h12(13,i1)-1,1);       else dm_select.h1.SP3_ROL(1,i1) = -99999;    end;
     if Index.rol.h1(14,i1)>1;dm_select.h1.SP4_ROL(1,i1)  = dm_result.SP4_ROL(i1,Index.rol.h12(14,i1)-1,1);       else dm_select.h1.SP4_ROL(1,i1) = -99999;    end;
     
     if Index.rol.h3(1,i1)>1; dm_select.h3.SP1_ROL(1,i1)  = dm_result.SP1_PCA_ROL(i1,Index.rol.h3(1,i1)-1,1);     else dm_select.h3.SP1_ROL(1,i1) = -99999;    end;
     if Index.rol.h3(2,i1)>1; dm_select.h3.SP1_ROL(2,i1)  = dm_result.SP1_ICA_ROL(i1,Index.rol.h3(2,i1)-1,1);     else dm_select.h3.SP1_ROL(2,i1) = -99999;    end;
     if Index.rol.h3(3,i1)>1; dm_select.h3.SP1_ROL(3,i1)  = dm_result.SP1_SPCA_ROL(i1,Index.rol.h3(3,i1)-1,1);    else dm_select.h3.SP1_ROL(3,i1) = -99999;    end;
     if Index.rol.h3(4,i1)>1; dm_select.h3.SP1L_ROL(1,i1) = dm_result.SP1L_PCA_ROL(i1,Index.rol.h3(4,i1)-1,1);    else dm_select.h3.SP1L_ROL(1,i1) = -99999;   end;
     if Index.rol.h3(5,i1)>1; dm_select.h3.SP1L_ROL(2,i1) = dm_result.SP1L_ICA_ROL(i1,Index.rol.h3(5,i1)-1,1);    else dm_select.h3.SP1L_ROL(2,i1) = -99999;   end;
     if Index.rol.h3(6,i1)>1; dm_select.h3.SP1L_ROL(3,i1) = dm_result.SP1L_SPCA_ROL(i1,Index.rol.h3(6,i1)-1,1);   else dm_select.h3.SP1L_ROL(3,i1) = -99999;   end;
     if Index.rol.h3(7,i1)>1; dm_select.h3.SP2_ROL(1,i1)  = dm_result.SP2_PCA_ROL(i1,Index.rol.h3(7,i1)-1,1);     else dm_select.h3.SP2_ROL(1,i1) = -99999;    end;
     if Index.rol.h3(8,i1)>1; dm_select.h3.SP2_ROL(2,i1)  = dm_result.SP2_ICA_ROL(i1,Index.rol.h3(8,i1)-1,1);     else dm_select.h3.SP2_ROL(2,i1) = -99999;    end;
     if Index.rol.h3(9,i1)>1; dm_select.h3.SP2_ROL(3,i1)  = dm_result.SP2_SPCA_ROL(i1,Index.rol.h3(9,i1)-1,1);    else dm_select.h3.SP2_ROL(3,i1) = -99999;    end;
     if Index.rol.h3(10,i1)>1;dm_select.h3.SP2L_ROL(1,i1) = dm_result.SP2L_PCA_ROL(i1,Index.rol.h3(10,i1)-1,1);   else dm_select.h3.SP2L_ROL(1,i1) = -99999;   end;
     if Index.rol.h3(11,i1)>1;dm_select.h3.SP2L_ROL(2,i1) = dm_result.SP2L_ICA_ROL(i1,Index.rol.h3(11,i1)-1,1);   else dm_select.h3.SP2L_ROL(2,i1) = -99999;   end;
     if Index.rol.h3(12,i1)>1;dm_select.h3.SP2L_ROL(3,i1) = dm_result.SP2L_SPCA_ROL(i1,Index.rol.h3(12,i1)-1,1);  else dm_select.h3.SP2L_ROL(3,i1) = -99999;   end;
     if Index.rol.h3(13,i1)>1;dm_select.h3.SP3_ROL(1,i1)  = dm_result.SP3_ROL(i1,Index.rol.h3(13,i1)-1,1);       else dm_select.h3.SP3_ROL(1,i1) = -99999;    end;
     if Index.rol.h3(14,i1)>1;dm_select.h3.SP4_ROL(1,i1)  = dm_result.SP4_ROL(i1,Index.rol.h3(14,i1)-1,1);       else dm_select.h3.SP4_ROL(1,i1) = -99999;    end;
     
     if Index.rol.h12(1,i1)>1; dm_select.h12.SP1_ROL(1,i1)  = dm_result.SP1_PCA_ROL(i1,Index.rol.h12(1,i1)-1,1);     else dm_select.h12.SP1_ROL(1,i1) = -99999;    end;
     if Index.rol.h12(2,i1)>1; dm_select.h12.SP1_ROL(2,i1)  = dm_result.SP1_ICA_ROL(i1,Index.rol.h12(2,i1)-1,1);     else dm_select.h12.SP1_ROL(2,i1) = -99999;    end;
     if Index.rol.h12(3,i1)>1; dm_select.h12.SP1_ROL(3,i1)  = dm_result.SP1_SPCA_ROL(i1,Index.rol.h12(3,i1)-1,1);    else dm_select.h12.SP1_ROL(3,i1) = -99999;    end;
     if Index.rol.h12(4,i1)>1; dm_select.h12.SP1L_ROL(1,i1) = dm_result.SP1L_PCA_ROL(i1,Index.rol.h12(4,i1)-1,1);    else dm_select.h12.SP1L_ROL(1,i1) = -99999;   end;
     if Index.rol.h12(5,i1)>1; dm_select.h12.SP1L_ROL(2,i1) = dm_result.SP1L_ICA_ROL(i1,Index.rol.h12(5,i1)-1,1);    else dm_select.h12.SP1L_ROL(2,i1) = -99999;   end;
     if Index.rol.h12(6,i1)>1; dm_select.h12.SP1L_ROL(3,i1) = dm_result.SP1L_SPCA_ROL(i1,Index.rol.h12(6,i1)-1,1);   else dm_select.h12.SP1L_ROL(3,i1) = -99999;   end;
     if Index.rol.h12(7,i1)>1; dm_select.h12.SP2_ROL(1,i1)  = dm_result.SP2_PCA_ROL(i1,Index.rol.h12(7,i1)-1,1);     else dm_select.h12.SP2_ROL(1,i1) = -99999;    end;
     if Index.rol.h12(8,i1)>1; dm_select.h12.SP2_ROL(2,i1)  = dm_result.SP2_ICA_ROL(i1,Index.rol.h12(8,i1)-1,1);     else dm_select.h12.SP2_ROL(2,i1) = -99999;    end;
     if Index.rol.h12(9,i1)>1; dm_select.h12.SP2_ROL(3,i1)  = dm_result.SP2_SPCA_ROL(i1,Index.rol.h12(9,i1)-1,1);    else dm_select.h12.SP2_ROL(3,i1) = -99999;    end;
     if Index.rol.h12(10,i1)>1;dm_select.h12.SP2L_ROL(1,i1) = dm_result.SP2L_PCA_ROL(i1,Index.rol.h12(10,i1)-1,1);   else dm_select.h12.SP2L_ROL(1,i1) = -99999;   end;
     if Index.rol.h12(11,i1)>1;dm_select.h12.SP2L_ROL(2,i1) = dm_result.SP2L_ICA_ROL(i1,Index.rol.h12(11,i1)-1,1);   else dm_select.h12.SP2L_ROL(2,i1) = -99999;   end;
     if Index.rol.h12(12,i1)>1;dm_select.h12.SP2L_ROL(3,i1) = dm_result.SP2L_SPCA_ROL(i1,Index.rol.h12(12,i1)-1,1);  else dm_select.h12.SP2L_ROL(3,i1) = -99999;   end;
     if Index.rol.h12(13,i1)>1;dm_select.h12.SP3_ROL(1,i1)  = dm_result.SP3_ROL(i1,Index.rol.h12(13,i1)-1,1);       else dm_select.h12.SP3_ROL(1,i1) = -99999;    end;
     if Index.rol.h12(14,i1)>1;dm_select.h12.SP4_ROL(1,i1)  = dm_result.SP4_ROL(i1,Index.rol.h12(14,i1)-1,1);       else dm_select.h12.SP4_ROL(1,i1) = -99999;    end;
end

dm_select.rol.h1 = [dm_select.h1.SP1_ROL;dm_select.h1.SP1L_ROL;...
                    dm_select.h1.SP2_ROL;dm_select.h1.SP2L_ROL;
                    dm_select.h1.SP3_ROL;dm_select.h1.SP4_ROL];
dm_select.rol.h3 = [dm_select.h3.SP1_ROL;dm_select.h3.SP1L_ROL;...
                    dm_select.h3.SP2_ROL;dm_select.h3.SP2L_ROL;
                    dm_select.h3.SP3_ROL;dm_select.h3.SP4_ROL];
dm_select.rol.h12 = [dm_select.h12.SP1_ROL;dm_select.h12.SP1L_ROL;...
                    dm_select.h12.SP2_ROL;dm_select.h12.SP2L_ROL;
                    dm_select.h12.SP3_ROL;dm_select.h12.SP4_ROL];
dm_select.rol.all = [dm_select.rol.h1;dm_select.rol.h3;dm_select.rol.h12];
                
                
                
                
                
                
                
                
                
                
                


load Result_SP1_PCA_REC;
SetResult_SP1
Yhat.REC.SP1.PCA = Yhat;
MSE.REC.SP1.PCA = MSE;
MSEr.REC.SP1.PCA = MSE_ratio;



MSE_SP1_PCA_REC;
MSE_SP1_ICA_REC;
MSE_SP1_SPCA_REC;
MSE_SP1L_ICA_REC;   % NOT YET
MSE_SP1L_ICA_REC;   
MSE_SP1L_SPCA_REC;
MSE_SP2_PCA_REC;
MSE_SP2_ICA_REC;
MSE_SP2_SPCA_REC;
MSE_SP2L_PCA_REC;
MSE_SP2L_ICA_REC;
MSE_SP2L_SPCA_REC;

MSE_SP1_PCA_ROL;
MSE_SP1_PCA_ROL;   % NOT YET
MSE_SP1_SPCA_ROL;
MSE_SP1L_ICA_ROL;  % NOT YET
MSE_SP1L_ICA_ROL;
MSE_SP1L_SPCA_ROL;
MSE_SP2_PCA_ROL;
MSE_SP2_ICA_ROL;
MSE_SP2_SPCA_ROL;
MSE_SP2L_PCA_ROL;
MSE_SP2L_ICA_ROL;
MSE_SP2L_SPCA_ROL;





MSE(:,:,:,:,1) = MSE_SP1_PCA_REC;
MSE(:,:,:,:,2) = MSE_SP1_ICA_REC;
MSE(:,:,:,:,3) = MSE_SP1_SPCA_REC;
MSE(:,:,:,:,4) = MSE_SP1L_PCA_REC;   
MSE(:,:,:,:,5) = MSE_SP1L_ICA_REC;   
MSE(:,:,:,:,6) = MSE_SP1L_SPCA_REC;
MSE(:,:,:,:,7) = MSE_SP2_PCA_REC;
MSE(:,:,:,:,8) = MSE_SP2_ICA_REC;
MSE(:,:,:,:,9) = MSE_SP2_SPCA_REC;
MSE(:,:,:,:,10) = MSE_SP2L_PCA_REC;
MSE(:,:,:,:,11) = MSE_SP2L_ICA_REC;
MSE(:,:,:,:,12) = MSE_SP2L_SPCA_REC;

MSE(:,:,:,:,13) = MSE_SP1_PCA_ROL;
MSE(:,:,:,:,14) = MSE_SP1_ICA_ROL;   
MSE(:,:,:,:,15) = MSE_SP1_SPCA_ROL;
MSE(:,:,:,:,16) = MSE_SP1L_PCA_ROL;  
MSE(:,:,:,:,17) = MSE_SP1L_ICA_ROL;
MSE(:,:,:,:,18) = MSE_SP1L_SPCA_ROL;
MSE(:,:,:,:,19) = MSE_SP2_PCA_ROL;
MSE(:,:,:,:,20) = MSE_SP2_ICA_ROL;
MSE(:,:,:,:,21) = MSE_SP2_SPCA_ROL;
MSE(:,:,:,:,22) = MSE_SP2L_PCA_ROL;
MSE(:,:,:,:,23) = MSE_SP2L_ICA_ROL;
MSE(:,:,:,:,24) = MSE_SP2L_SPCA_ROL;

[s1,s2,s3,s4,s5]=size(MSE);
hstep = [1,2,4];

MSE_ratio = nan(s3,s2,length(hstep),s5);

for d = 1:1:s5
    for h = 1:1:length(hstep)
        MSE_ratio(1,:,h,d) = sum(MSE(:,:,1,hstep(h),d));
        for i = 2 : 1 : s3
            MSE_ratio(i,:,h,d) = sum(MSE(:,:,i,h))./sum(MSE(:,:,1,h));
        end
    end
end

