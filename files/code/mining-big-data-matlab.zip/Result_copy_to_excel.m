% TEST RESULT COPYING TO EXCEL PROCEDURE 

% Relative Mean Square Forecasting Error ----------------------------------

% P = 400
S1=dmtest_4d(MSE_SP1_400);
R1 = [MSE_SP1_400_ratio(:,:,1);nan(1,11);MSE_SP1_400_ratio(:,:,2);nan(1,11);MSE_SP1_400_ratio(:,:,3);nan(1,11);MSE_SP1_400_ratio(:,:,4)];
R2 = [zeros(1,11);S1(:,:,1);nan(1,11);zeros(1,11);S1(:,:,2);nan(1,11);zeros(1,11);S1(:,:,3);nan(1,11);zeros(1,11);S1(:,:,4)];

S1=dmtest_4d(MSE_SP1L_400);
R1 = [MSE_SP1L_400_ratio(:,:,1);nan(1,11);MSE_SP1L_400_ratio(:,:,2);nan(1,11);MSE_SP1L_400_ratio(:,:,3);nan(1,11);MSE_SP1L_400_ratio(:,:,4)];
R2 = [zeros(1,11);S1(:,:,1);nan(1,11);zeros(1,11);S1(:,:,2);nan(1,11);zeros(1,11);S1(:,:,3);nan(1,11);zeros(1,11);S1(:,:,4)];

S1=dmtest_4d(MSE_SP2_400);
R1 = [MSE_SP2_400_ratio([1,2,3,7,8,9,11,12,13,14],:,1);nan(1,11);MSE_SP2_400_ratio([1,2,3,7,8,9,11,12,13,14],:,2);nan(1,11);MSE_SP2_400_ratio([1,2,3,7,8,9,11,12,13,14],:,3);nan(1,11);MSE_SP2_400_ratio([1,2,3,7,8,9,11,12,13,14],:,4)];
R2 = [zeros(1,11);S1([1,2,6,7,8,10,11,12,13],:,1);nan(1,11);zeros(1,11);S1([1,2,6,7,8,10,11,12,13],:,2);nan(1,11);zeros(1,11);S1([1,2,6,7,8,10,11,12,13],:,3);nan(1,11);zeros(1,11);S1([1,2,6,7,8,10,11,12,13],:,4)];

S1=dmtest_4d(MSE_SP3_400);
R1 = [MSE_SP3_400_ratio([1,2,3,7,8,9,10,11,12,13,14],:,1);nan(4,11);MSE_SP3_400_ratio([1,2,3,7,8,9,10,11,12,13,14],:,2);nan(4,11);MSE_SP3_400_ratio([1,2,3,7,8,9,10,11,12,13,14],:,4)];
R2 = [zeros(1,11);S1([1,2,6,7,8,9,10,11,12,13],:,1);nan(4,11);zeros(1,11);S1([1,2,6,7,8,9,10,11,12,13],:,2);nan(4,11);zeros(1,11);S1([1,2,6,7,8,9,10,11,12,13],:,4)];

% P = 300
S1=dmtest_4d(MSE_SP1_300);
R1 = [MSE_SP1_300_ratio(:,:,1);nan(1,11);MSE_SP1_300_ratio(:,:,2);nan(1,11);MSE_SP1_300_ratio(:,:,3);nan(1,11);MSE_SP1_300_ratio(:,:,4)];
R2 = [zeros(1,11);S1(:,:,1);nan(1,11);zeros(1,11);S1(:,:,2);nan(1,11);zeros(1,11);S1(:,:,3);nan(1,11);zeros(1,11);S1(:,:,4)];

S1=dmtest_4d(MSE_SP1L_300);
R1 = [MSE_SP1L_300_ratio(:,:,1);nan(1,11);MSE_SP1L_300_ratio(:,:,2);nan(1,11);MSE_SP1L_300_ratio(:,:,3);nan(1,11);MSE_SP1L_300_ratio(:,:,4)];
R2 = [zeros(1,11);S1(:,:,1);nan(1,11);zeros(1,11);S1(:,:,2);nan(1,11);zeros(1,11);S1(:,:,3);nan(1,11);zeros(1,11);S1(:,:,4)];

S1=dmtest_4d(MSE_SP2_300);
R1 = [MSE_SP2_300_ratio([1,2,3,7,8,9,11,12,13,14],:,1);nan(1,11);MSE_SP2_300_ratio([1,2,3,7,8,9,11,12,13,14],:,2);nan(1,11);MSE_SP2_300_ratio([1,2,3,7,8,9,11,12,13,14],:,3);nan(1,11);MSE_SP2_300_ratio([1,2,3,7,8,9,11,12,13,14],:,4)];
R2 = [zeros(1,11);S1([1,2,6,7,8,10,11,12,13],:,1);nan(1,11);zeros(1,11);S1([1,2,6,7,8,10,11,12,13],:,2);nan(1,11);zeros(1,11);S1([1,2,6,7,8,10,11,12,13],:,3);nan(1,11);zeros(1,11);S1([1,2,6,7,8,10,11,12,13],:,4)];

S1=dmtest_4d(MSE_SP3_300);
R1 = [MSE_SP3_300_ratio([1,2,3,7,8,9,10,11,12,13,14],:,1);nan(4,11);MSE_SP3_300_ratio([1,2,3,7,8,9,10,11,12,13,14],:,2);nan(4,11);MSE_SP3_300_ratio([1,2,3,7,8,9,10,11,12,13,14],:,4)];
R2 = [zeros(1,11);S1([1,2,6,7,8,9,10,11,12,13],:,1);nan(4,11);zeros(1,11);S1([1,2,6,7,8,9,10,11,12,13],:,2);nan(4,11);zeros(1,11);S1([1,2,6,7,8,9,10,11,12,13],:,4)];

% P = 200
S1=dmtest_4d(MSE_SP1_200);
R1 = [MSE_SP1_200_ratio(:,:,1);nan(1,11);MSE_SP1_200_ratio(:,:,2);nan(1,11);MSE_SP1_200_ratio(:,:,3);nan(1,11);MSE_SP1_200_ratio(:,:,4)];
R2 = [zeros(1,11);S1(:,:,1);nan(1,11);zeros(1,11);S1(:,:,2);nan(1,11);zeros(1,11);S1(:,:,3);nan(1,11);zeros(1,11);S1(:,:,4)];

S1=dmtest_4d(MSE_SP1L_200);
R1 = [MSE_SP1L_200_ratio(:,:,1);nan(1,11);MSE_SP1L_200_ratio(:,:,2);nan(1,11);MSE_SP1L_200_ratio(:,:,3);nan(1,11);MSE_SP1L_200_ratio(:,:,4)];
R2 = [zeros(1,11);S1(:,:,1);nan(1,11);zeros(1,11);S1(:,:,2);nan(1,11);zeros(1,11);S1(:,:,3);nan(1,11);zeros(1,11);S1(:,:,4)];

S1=dmtest_4d(MSE_SP2_200);
R1 = [MSE_SP2_200_ratio([1,2,3,7,8,9,11,12,13,14],:,1);nan(1,11);MSE_SP2_200_ratio([1,2,3,7,8,9,11,12,13,14],:,2);nan(1,11);MSE_SP2_200_ratio([1,2,3,7,8,9,11,12,13,14],:,3);nan(1,11);MSE_SP2_200_ratio([1,2,3,7,8,9,11,12,13,14],:,4)];
R2 = [zeros(1,11);S1([1,2,6,7,8,10,11,12,13],:,1);nan(1,11);zeros(1,11);S1([1,2,6,7,8,10,11,12,13],:,2);nan(1,11);zeros(1,11);S1([1,2,6,7,8,10,11,12,13],:,3);nan(1,11);zeros(1,11);S1([1,2,6,7,8,10,11,12,13],:,4)];

S1=dmtest_4d(MSE_SP3_200);
R1 = [MSE_SP3_200_ratio([1,2,3,7,8,9,10,11,12,13,14],:,1);nan(4,11);MSE_SP3_200_ratio([1,2,3,7,8,9,10,11,12,13,14],:,2);nan(4,11);MSE_SP3_200_ratio([1,2,3,7,8,9,10,11,12,13,14],:,4)];
R2 = [zeros(1,11);S1([1,2,6,7,8,9,10,11,12,13],:,1);nan(4,11);zeros(1,11);S1([1,2,6,7,8,9,10,11,12,13],:,2);nan(4,11);zeros(1,11);S1([1,2,6,7,8,9,10,11,12,13],:,4)];

% PICK THE BEST PROCEDURE -------------------------------------------------

% P = 200
BestMet1  = PickTheBest(MSE_SP1_200_ratio);
BestMet1L = PickTheBest(MSE_SP1L_200_ratio);
%MSE_SP2_200_ratio([4,5,6,10],:,:) = 10e3;
BestMet2  = PickTheBest(MSE_SP2_200_ratio);
%MSE_SP3_200_ratio([4,5,6],:,:) = 10e3;
BestMet3  = PickTheBest(MSE_SP3_200_ratio);

% P = 300
BestMet1  = PickTheBest(MSE_SP1_300_ratio);
BestMet1L = PickTheBest(MSE_SP1L_300_ratio);
%MSE_SP2_300_ratio([4,5,6,10],:,:) = 10e3;
BestMet2  = PickTheBest(MSE_SP2_300_ratio);
%MSE_SP3_300_ratio([4,5,6],:,:) = 10e3;
BestMet3  = PickTheBest(MSE_SP3_300_ratio);

% P = 400
BestMet1  = PickTheBest(MSE_SP1_400_ratio);
BestMet1L = PickTheBest(MSE_SP1L_400_ratio);
%MSE_SP2_400_ratio([4,5,6,10],:,:) = 10e3;
BestMet2  = PickTheBest(MSE_SP2_400_ratio);
%MSE_SP3_400_ratio([4,5,6],:,:) = 10e3;
BestMet3  = PickTheBest(MSE_SP3_400_ratio);

% PICK THE BEST SPECIFICATION ---------------------------------------------

% P = 400;
for h = 1:1:4
    [mR1,mV1] = min(MSE_SP1_400_ratio(2:end,:,h));
    [mR2,mV2] = min(MSE_SP1L_400_ratio(2:end,:,h));
    [mR3,mV3] = min(MSE_SP2_400_ratio(2:end,:,h));
    [mR4,mV4] = min(MSE_SP3_400_ratio(2:end,:,h));
    [mR,mV] = min([mR1;mR2;mR3;mR4]);
    BestSP(h,:) = mV;
    clear mR* mV*
end

% P = 300;
for h = 1:1:4
    [mR1,mV1] = min(MSE_SP1_300_ratio(2:end,:,h));
    [mR2,mV2] = min(MSE_SP1L_300_ratio(2:end,:,h));
    [mR3,mV3] = min(MSE_SP2_300_ratio(2:end,:,h));
    [mR4,mV4] = min(MSE_SP3_300_ratio(2:end,:,h));
    [mR,mV] = min([mR1;mR2;mR3;mR4]);
    BestSP(h,:) = mV;
    clear mR* mV*
end

% P = 200;
for h = 1:1:4
    [mR1,mV1] = min(MSE_SP1_200_ratio(2:end,:,h));
    [mR2,mV2] = min(MSE_SP1L_200_ratio(2:end,:,h));
    [mR3,mV3] = min(MSE_SP2_200_ratio(2:end,:,h));
    [mR4,mV4] = min(MSE_SP3_200_ratio(2:end,:,h));
    [mR,mV] = min([mR1;mR2;mR3;mR4]);
    BestSP(h,:) = mV;
    clear mR* mV*
end

% Rolling Estimation ------------------------------------------------------

% Yhat FIXING 
Yhat_SP1L_ROL(:,:,:,[1:3]) = Yhat_SP1_ROL(:,:,:,[1:3]);
Yhat_SP2_ROL(:,:,:,[1:3]) = Yhat_SP1_ROL(:,:,:,[1:3]);
Yhat_SP3_ROL(:,:,:,[1:3]) = Yhat_SP1_ROL(:,:,:,[1:3]);

% Mean redirecting
Yhat_SP1L_ROL(:,:,:,14) = sum(Yhat_SP1L_ROL(:,:,:,[1:13]),4)/13;
Yhat_SP2_ROL(:,:,:,14)  = sum(Yhat_SP2_ROL(:,:,:,[1,2,3,7,8,9,11,12,13]),4)/9;
Yhat_SP3_ROL(:,:,:,14)  = sum(Yhat_SP3_ROL(:,:,:,[1,2,3,7,8,9,10,11,12,13]),4)/10;

% MSE_ratio RE-calculating
[rr cc dd kk] = size(Yhat_SP1_ROL);

for h=1:1:dd
    for l = 1 : 1 : kk
        MSE_ROL_SP1(:,:,l,h) = (Yhat_SP1_ROL(:,:,h,l)-Y_real).^2;
        MSE_ROL_SP1L(:,:,l,h)= (Yhat_SP1L_ROL(:,:,h,l)-Y_real).^2;        
        MSE_ROL_SP2(:,:,l,h) = (Yhat_SP2_ROL(:,:,h,l)-Y_real).^2;
        MSE_ROL_SP3(:,:,l,h) = (Yhat_SP3_ROL(:,:,h,l)-Y_real).^2;
    end
end

for h=1:1:dd
    MSE_ratio_ROL_SP1(1,:,h) = sum(MSE_ROL_SP1(:,:,1,h));
    MSE_ratio_ROL_SP1L(1,:,h)= sum(MSE_ROL_SP1L(:,:,1,h));
    MSE_ratio_ROL_SP2(1,:,h) = sum(MSE_ROL_SP2(:,:,1,h));
    MSE_ratio_ROL_SP3(1,:,h) = sum(MSE_ROL_SP3(:,:,1,h));
    for i = 2 : 1 : kk
        MSE_ratio_ROL_SP1(i,:,h) = sum(MSE_ROL_SP1(:,:,i,h))./sum(MSE_ROL_SP1(:,:,1,h));
        MSE_ratio_ROL_SP1L(i,:,h)= sum(MSE_ROL_SP1L(:,:,i,h))./sum(MSE_ROL_SP1L(:,:,1,h));
        MSE_ratio_ROL_SP2(i,:,h) = sum(MSE_ROL_SP2(:,:,i,h))./sum(MSE_ROL_SP2(:,:,1,h));
        MSE_ratio_ROL_SP3(i,:,h) = sum(MSE_ROL_SP3(:,:,i,h))./sum(MSE_ROL_SP3(:,:,1,h));
    end
end
clear rr cc dd kk h i l

% SAVED to Core_P300_ROL.mat till here

% DM-TEST
[S1] = dmtest_4d(MSE_ROL_SP1);
[S1L] = dmtest_4d(MSE_ROL_SP1L)
[S2] = dmtest_4d(MSE_ROL_SP2)
[S3] = dmtest_4d(MSE_ROL_SP3)

% COPYING TO EXCEL 
R1 = [MSE_ratio_ROL_SP1(:,:,1);nan(1,11);MSE_ratio_ROL_SP1(:,:,2);nan(1,11);MSE_ratio_ROL_SP1(:,:,3);nan(1,11);MSE_ratio_ROL_SP1(:,:,4)];
R2 = [zeros(1,11);S1(:,:,1);nan(1,11);zeros(1,11);S1(:,:,2);nan(1,11);zeros(1,11);S1(:,:,3);nan(1,11);zeros(1,11);S1(:,:,4)];

R1 = [MSE_ratio_ROL_SP1L(:,:,1);nan(1,11);MSE_ratio_ROL_SP1L(:,:,2);nan(1,11);MSE_ratio_ROL_SP1L(:,:,3);nan(1,11);MSE_ratio_ROL_SP1L(:,:,4)];
R2 = [zeros(1,11);S1L(:,:,1);nan(1,11);zeros(1,11);S1L(:,:,2);nan(1,11);zeros(1,11);S1L(:,:,3);nan(1,11);zeros(1,11);S1L(:,:,4)];

R1 = [MSE_ratio_ROL_SP2([1,2,3,7,8,9,11,12,13,14],:,1);nan(1,11);MSE_ratio_ROL_SP2([1,2,3,7,8,9,11,12,13,14],:,2);nan(1,11);MSE_ratio_ROL_SP2([1,2,3,7,8,9,11,12,13,14],:,3);nan(1,11);MSE_ratio_ROL_SP2([1,2,3,7,8,9,11,12,13,14],:,4)];
R2 = [zeros(1,11);S2([1,2,6,7,8,10,11,12,13],:,1);nan(1,11);zeros(1,11);S2([1,2,6,7,8,10,11,12,13],:,2);nan(1,11);zeros(1,11);S2([1,2,6,7,8,10,11,12,13],:,3);nan(1,11);zeros(1,11);S2([1,2,6,7,8,10,11,12,13],:,4)];

R1 = [MSE_ratio_ROL_SP3([1,2,3,7,8,9,10,11,12,13,14],:,1);nan(4,11);MSE_ratio_ROL_SP3([1,2,3,7,8,9,10,11,12,13,14],:,2);nan(4,11);MSE_ratio_ROL_SP3([1,2,3,7,8,9,10,11,12,13,14],:,4)];
R2 = [zeros(1,11);S3([1,2,6,7,8,9,10,11,12,13],:,1);nan(4,11);zeros(1,11);S3([1,2,6,7,8,9,10,11,12,13],:,2);nan(4,11);zeros(1,11);S3([1,2,6,7,8,9,10,11,12,13],:,4)];

% Pick the BEST 

% for ROLLING 

% BEST in each specification
BestMet1  = PickTheBest(MSE_ratio_ROL_SP1);
BestMet1L = PickTheBest(MSE_ratio_ROL_SP1L);
MSE_SP2_300_ratio([4,5,6,10],:,:) = 10e3;
BestMet2  = PickTheBest(MSE_ratio_ROL_SP2);
MSE_SP3_300_ratio([4,5,6],:,:) = 10e3;
BestMet3  = PickTheBest(MSE_ratio_ROL_SP3);

% BEST Specification OF BEST Methods
for h = 1:1:4
    [mR1,mV1] = min(MSE_ratio_ROL_SP1(2:end,:,h));
    [mR2,mV2] = min(MSE_ratio_ROL_SP1L(2:end,:,h));
    [mR3,mV3] = min(MSE_ratio_ROL_SP2(2:end,:,h));
    [mR4,mV4] = min(MSE_ratio_ROL_SP3(2:end,:,h));
    [mR,mV] = min([mR1;mR2;mR3;mR4]);
    BestSP(h,:) = mV;
    BestSPV(h,:) = mR;
    clear mR* mV* 
end
clear h
% P = 300;
for h = 1:1:4
    [mR1,mV1] = min(MSE_SP1_300_ratio(2:end,:,h));
    [mR2,mV2] = min(MSE_SP1L_300_ratio(2:end,:,h));
    [mR3,mV3] = min(MSE_SP2_300_ratio(2:end,:,h));
    [mR4,mV4] = min(MSE_SP3_300_ratio(2:end,:,h));
    [mRre,mVre] = min([mR1;mR2;mR3;mR4]);
    BestSPre(h,:) = mVre;
    BestSPreV(h,:) = mRre;
    clear mR* mV*
end
clear h

for h = 1:1:4
    [mRBest,mVBest] = min([BestSPreV(h,:);BestSPV(h,:)]);
    BestEST(h,:) = mVBest;
    BestESTV(h,:) = mRBest;
    clear mRBest mVBest
end
clear h

% Table 8. Panel B

% #1
for h=1:1:4
    [mRre1,mVre1] = min(MSE_SP1_300_ratio(2:end,:,h));
    [mRro1,mVro1] = min(MSE_ratio_ROL_SP1(2:end,:,h));
    [mRest1,mVest1] = min([mRre1;mRro1]);
    BestRERO(h,:,1) = mVest1;
    %clear mR* mV*
    [mRre1L,mVre1L] = min(MSE_SP1L_300_ratio(2:end,:,h));
    [mRro1L,mVro1L] = min(MSE_ratio_ROL_SP1L(2:end,:,h));
    [mRest1L,mVest1L] = min([mRre1L;mRro1L]);
    BestRERO(h,:,2) = mVest1L;
    %clear mR* mV*    
    [mRre2,mVre2] = min(MSE_SP2_300_ratio(2:end,:,h));
    [mRro2,mVro2] = min(MSE_ratio_ROL_SP2(2:end,:,h));
    [mRest2,mVest2] = min([mRre2;mRro2]);
    BestRERO(h,:,3) = mVest2;
    %clear mR* mV*    
    [mRre3,mVre3] = min(MSE_SP3_300_ratio(2:end,:,h));
    [mRro3,mVro3] = min(MSE_ratio_ROL_SP3(2:end,:,h));
    [mRest3,mVest3] = min([mRre3;mRro3]);
    BestRERO(h,:,4) = mVest3;
    [mRSP,mVSP] = min([mRest1;mRest1L;mRest2;mRest3]);
    BestSP2(h,:) = mVSP;
    clear mR* mV*    
end
clear h
[BestRERO(:,:,1);BestRERO(:,:,2);BestRERO(:,:,3);BestRERO(:,:,4)];


% SUB PERIOD DIVISION
% PANEL A
    MSE = MSE_SP1_300;          % <---------- Change MSE appropriately ----------------------------------------------------------------------------------------------

    MSE1=MSE(1:73,:,:,:);             % 84:06~90:06
    MSE2=MSE(82:201,:,:,:);           % 91:03~01:02
    MSE3=MSE(210:282,:,:,:);          % 01:11~07:11
    MSE4=MSE([1:73,82:201,210:282],:,:,:);   % Expansion
    MSE5=MSE([74:81,202:209],:,:,:);   %Recession

    %[rr cc dd kk]=size(Yhat);
    dd=4; kk=14;
    for h=1:1:dd
        MSE1_ratio(1,:,h) = sum(MSE1(:,:,1,h));
        MSE2_ratio(1,:,h) = sum(MSE2(:,:,1,h));
        MSE3_ratio(1,:,h) = sum(MSE3(:,:,1,h));
        MSE4_ratio(1,:,h) = sum(MSE4(:,:,1,h));
        MSE5_ratio(1,:,h) = sum(MSE5(:,:,1,h));
    %    MSE6_ratio(1,:,h) = sum(MSE6(:,:,1,h));
    %    MSE7_ratio(1,:,h) = sum(MSE7(:,:,1,h));
        for i = 2 : 1 : kk
            MSE1_ratio(i,:,h) = sum(MSE1(:,:,i,h))./sum(MSE1(:,:,1,h));
            MSE2_ratio(i,:,h) = sum(MSE2(:,:,i,h))./sum(MSE2(:,:,1,h));
            MSE3_ratio(i,:,h) = sum(MSE3(:,:,i,h))./sum(MSE3(:,:,1,h));
            MSE4_ratio(i,:,h) = sum(MSE4(:,:,i,h))./sum(MSE4(:,:,1,h));
            MSE5_ratio(i,:,h) = sum(MSE5(:,:,i,h))./sum(MSE5(:,:,1,h));
    %        MSE6_ratio(i,:,h) = sum(MSE6(:,:,i,h))./sum(MSE6(:,:,1,h));
    %        MSE7_ratio(i,:,h) = sum(MSE7(:,:,i,h))./sum(MSE7(:,:,1,h));
        end
    end

    [BestMet1, BestMetN1, BestMet_V1]  = PickTheBest(MSE1_ratio);
    [BestMet2, BestMetN2, BestMet_V2]  = PickTheBest(MSE2_ratio);
    [BestMet3, BestMetN3, BestMet_V3]  = PickTheBest(MSE3_ratio);
    [BestMet4, BestMetN4, BestMet_V4]  = PickTheBest(MSE4_ratio);
    [BestMet5, BestMetN5, BestMet_V5]  = PickTheBest(MSE5_ratio);

    [BestMetN1(1,:);BestMetN2(1,:);BestMetN3(1,:);BestMetN4(1,:);BestMetN5(1,:)]
    [BestMet_V1(1,:);BestMet_V2(1,:);BestMet_V3(1,:);BestMet_V4(1,:);BestMet_V5(1,:)]


% PANEL B 
for j =1:1:4
    if j==1
        MSE = MSE_SP1_300;          
    elseif j==2
        MSE = MSE_SP1L_300;          
    elseif j==3
        MSE = MSE_SP2_300;          
    elseif j==4
        MSE = MSE_SP3_300;          
    end        
    MSE1(:,:,:,:,j)=MSE(1:73,:,:,:);             % 84:06~90:06
    MSE2(:,:,:,:,j)=MSE(82:201,:,:,:);           % 91:03~01:02
    MSE3(:,:,:,:,j)=MSE(210:282,:,:,:);          % 01:11~07:11
    MSE4(:,:,:,:,j)=MSE([1:73,82:201,210:282],:,:,:);   % Expansion
    MSE5(:,:,:,:,j)=MSE([74:81,202:209],:,:,:);   %Recession


    dd=4; kk=14;
    for h=1:1:dd
        MSE1_ratio(1,:,h,j) = sum(MSE1(:,:,1,h,j));
        MSE2_ratio(1,:,h,j) = sum(MSE2(:,:,1,h,j));
        MSE3_ratio(1,:,h,j) = sum(MSE3(:,:,1,h,j));
        MSE4_ratio(1,:,h,j) = sum(MSE4(:,:,1,h,j));
        MSE5_ratio(1,:,h,j) = sum(MSE5(:,:,1,h,j));
        %    MSE6_ratio(1,:,h) = sum(MSE6(:,:,1,h));
        %    MSE7_ratio(1,:,h) = sum(MSE7(:,:,1,h));
        for i = 2 : 1 : kk
            MSE1_ratio(i,:,h,j) = sum(MSE1(:,:,i,h,j))./sum(MSE1(:,:,1,h,j));
            MSE2_ratio(i,:,h,j) = sum(MSE2(:,:,i,h,j))./sum(MSE2(:,:,1,h,j));
            MSE3_ratio(i,:,h,j) = sum(MSE3(:,:,i,h,j))./sum(MSE3(:,:,1,h,j));
            MSE4_ratio(i,:,h,j) = sum(MSE4(:,:,i,h,j))./sum(MSE4(:,:,1,h,j));
            MSE5_ratio(i,:,h,j) = sum(MSE5(:,:,i,h,j))./sum(MSE5(:,:,1,h,j));
            %        MSE6_ratio(i,:,h) = sum(MSE6(:,:,i,h))./sum(MSE6(:,:,1,h));
            %        MSE7_ratio(i,:,h) = sum(MSE7(:,:,i,h))./sum(MSE7(:,:,1,h));
        end
    end
end


for h=1:1:4
    for j =1:1:4
        [mR1,mV1] = min(MSE1_ratio(2:end,:,h,j));
        mR_min1(j,:,h) = mR1;
        [mR2,mV2] = min(MSE2_ratio(2:end,:,h,j));
        mR_min2(j,:,h) = mR2;
        [mR3,mV3] = min(MSE3_ratio(2:end,:,h,j));
        mR_min3(j,:,h) = mR3;
        [mR4,mV4] = min(MSE4_ratio(2:end,:,h,j));
        mR_min4(j,:,h) = mR4;
        [mR5,mV5] = min(MSE5_ratio(2:end,:,h,j));
        mR_min5(j,:,h) = mR5;
    end
    [mRR1,mVV1] = min(mR_min1(:,:,h));
    [mRR2,mVV2] = min(mR_min2(:,:,h));
    [mRR3,mVV3] = min(mR_min3(:,:,h));
    [mRR4,mVV4] = min(mR_min4(:,:,h));
    [mRR5,mVV5] = min(mR_min5(:,:,h));
    BestMet_SUB1(h,:) = mVV1;
    BestMet_SUB2(h,:) = mVV2;
    BestMet_SUB3(h,:) = mVV3;
    BestMet_SUB4(h,:) = mVV4;
    BestMet_SUB5(h,:) = mVV5;
end





























