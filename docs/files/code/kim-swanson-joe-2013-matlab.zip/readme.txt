MATLAB Codes for 
Hyun Hak Kim and Norman R. Swanson
"Forecasting Financial and Macroeconomic Variables Using Data Reduction Methods:
New Empirical Evidence", Journal of Econometrics, 2013

Replicating the results - 

All codes are made by Hyun Hak Kim (khdouble@bok.or.kr)

# Many of codes are using Econometric Toolbox by James P. LeSage
  You can get these codes from www.spatial-econometrics.com 

# Also, to run the following main program, you may need to download approporiate program 
  for various shrinkage methods 

# For "Bayesian Model Averaging"
  See Gary Koop's webpage
  http://personal.strath.ac.uk/gary.koop/bayes_matlab_code_by_koop_and_korobilis.html

# For "Least Angle Regression" and "Elastic Net"
  See the Karl Sjostrand webpage 
  http://www2.imm.dtu.dk/pubdb/views/publication_details.php?id=3897

# For "Non-negative Garotte"
  Daniel F. Schmidt and Enes Makalic's code is used. 

# Other MATLAB code for shrinkage methods are in the folder and made by Hyun Hak Kim 

# Please be aware of the running time of each specicifcation. 
  Since it runs all shrinkage methods in once, it usually takes more than a couple of hours in a certain home PC. 

-------------------------------------------------------------------------------

Dataset02.mat 
-> This includes 144 macroeconomic variables that is used in the paper

1. Table 3 to 6 are summarized from the result of following programs. 
   Once you run the program, you can choose 

SP1.m

-> By running this program, you can get the result of 14 forecasting methods 
   under Specification Type 1 without lags with factors estimated by PCA. 
   By assigning output file, you can get the Table 3 at the end.

SP1_L.m

-> This gives you the result of Specification Type 1 with lags, with factors 
   estimated by PCA, like Table 4. 

SP2.m

-> By same way, you can get the result like Table 5 by running this program.  

SP3.m 

-> By same way, you can get the result like Table 6 by running this program.  

2. Tables 7-8 are reproduced using the result in Table 3 to 6. 
   Therefore, you need to save the result of Table 3 to 6 

3. Reality Check test 

RealCheck_v06.m
-> It replicates the result of the reality check.