%a Using Corradi & Swanson (2005), IER, 
% Generate Test Statistic and Boostrap Critical Values. 
% VOLUME
% 1. Add 'beta' matrix.
% 2. Modify loop for three cases. 
% 3. Keep the length of lags max which is 4. (p=4)
% 4. Stastisc completed
% 5. Keep the number of factors for all sample period for bootstrapping (nf=8)
% 6. CBADL and IC_OLS -> control fixed number of predictors 
% 6c. for Specification Type 2

% Permutations for R and P. 
% First set T =560 which means cut first 33 observations.
% Case 1. R=160, P=400
% Case 2. R=260, P=300
% Case 3. R=360, P=200
clear

disp(' ');disp('Starting Forecasting for FACTOR MODEL');disp(' ');
disp('Specification Type 2 : Estimation with Factors from selected variables from All Regressors')
disp(' ');
pcase = input('Select size of P. 1 for P=400, 2 for P=300, 3 for P=200 ');
disp(' ');
rero = input('Select 1 for Recursive Model, 2 for Rolling Estimation Model - ');

T = 560;

%pcase = 3;
sim_op= 0;

if pcase == 1
    R=160; P=400;
elseif pcase == 2
    R=260; P=300;
elseif pcase == 3
    R=360; P=200;
end    
load Dataset02.mat;         % Call orginal data files.

% Parameter Setting -------------------------------------------------------
c = 1.96;                   % Critical Value for Bagging 
M = 50;                     % Boosting iteration
nburn = 100; nkeep = 1000;  % Loop for BMA
hmax = 12; pmax = 4;        % Setting for max horizon and max lag.
sp = 156;   rw = 156;       % Starting period of forecasting // Rolling windows size
intv = 5;                  % For interval of progress display.
xx = TrDataTr;              % Set explanatory data which are alread transformed. 
yy = TrYvarTr;%(:,1);              % Set dependant data which are alread transformed.

% Estimation On/Off Control -----------------------------------------------
% If method is 1, it's on. else if's off. 
mc = ones(1,13);            % All estimation are turned on. 
%mc = zeros(1,13); 
%mc([1,7,8,9,11,12,13])=1;
mc([2,3,4,5])=0;


if rero == 1;
    load betas_re.mat;
    load betas_re_sel.mat;
else 
    load betas_ro.mat;
    load betas_ro_sel.mat;
end

[ mx , nx ] = size(xx);[ my , ny ] = size(yy);

yhat_ar=zeros(P,ny,4);
yhat_ols=zeros(P,ny,4);
yhat_CADL=zeros(P,ny,4);
yhat_faar=zeros(P,ny,4);
yhat_pcr=zeros(P,ny,4);
yhat_bag=zeros(P,ny,4);
yhat_cbst=zeros(P,ny,4);
yhat_bma1=zeros(P,ny,4);
yhat_bma2=zeros(P,ny,4);
yhat_ridge=zeros(P,ny,4);
yhat_lars=zeros(P,ny,4);
yhat_en=zeros(P,ny,4);
yhat_nng=zeros(P,ny,4);

disp(' ');disp('Progress Report');disp(' ')
        
% Pre-allocation 
seld_all = zeros(P,ny);
n_fac = zeros(P,ny,4);
        
% Main Loop Program -------------------------------------------------------
xx = xx(end-hmax-pmax-T+1:end,:);
yy = yy(end-hmax-pmax-T+1:end,:);
%date_T = DataDateTr(end-hmax-pmax-T+1:end,:);
j=1;

for mm = 1:1:7          
    % The following if phrases are for implementing each methods with
    % associated selected variables by each type of method. 
    if mm == 1
        mc(1) = 1;        mc(6) = 1;
    elseif mm == 2
        mc = zeros(1,13);
        mc(1) = 1;        mc(7) = 1;
    elseif mm == 3
        mc = zeros(1,13);
        mc(1) = 1;        mc(8) = 1;
    elseif mm == 4 
        mc = zeros(1,13);
        mc(1) = 1;        mc(9) = 1;
    elseif mm == 5 
        mc = zeros(1,13);
        mc(1) = 1;        mc(11) = 1;
    elseif mm == 6 
        mc = zeros(1,13);
        mc(1) = 1;        mc(12) = 1;
    elseif mm == 7 
        mc = zeros(1,13);
        mc(1) = 1;        mc(13) = 1;
    end



for i = 1 : 1 : P

        if rero == 1
            xx_h1  = xx(pmax+hmax:pmax+hmax+i+R-1,:);           %date_xx_h1 = date_T(pmax+hmax:pmax+hmax+i+R-1,:);
            xx_h3  = xx(pmax+hmax-2:pmax+hmax+i+R-3,:);
            xx_h6  = xx(pmax+hmax-5:pmax+hmax+i+R-6,:);
            xx_h12 = xx(pmax+hmax-11:pmax+hmax+i+R-12,:);
        else 
            xx_h1  = xx(pmax+hmax-1+(i-1):pmax+hmax-1+i+R-1,:);
            xx_h3  = xx(pmax+hmax-3+(i-1):pmax+hmax-1+i+R-3,:);
            xx_h6  = xx(pmax+hmax-6+(i-1):pmax+hmax-1+i+R-6,:);
            xx_h12 = xx(pmax+hmax-12+(i-1):pmax+hmax-1+i+R-12,:);
        end
    
        %if sim_op == 0
        n_fac_h1  = numfac(xx_h1,20);
        n_fac_h3  = numfac(xx_h3,20);
        n_fac_h6  = numfac(xx_h6,20);
        n_fac_h12 = numfac(xx_h12,20);
                
        n_fac(i,j,1)=n_fac_h1;
        n_fac(i,j,2)=n_fac_h3;
        n_fac(i,j,3)=n_fac_h6;
        n_fac(i,j,4)=n_fac_h12;
            
        [SCORE1, matLoads1]  = Factor_Load(xx_h1,20);
        [SCORE3, matLoads3]  = Factor_Load(xx_h3,20);
        [SCORE6, matLoads6]  = Factor_Load(xx_h6,20);
        [SCORE12,matLoads12] = Factor_Load(xx_h12,20);
        clear matLoads1 matLoads3 matLoads6 matLoads12
        
        fac1 = SCORE1(1:end-1,1:n_fac_h1);
        fac3 = SCORE3(1:end-1,1:n_fac_h3);
        fac6 = SCORE6(1:end-1,1:n_fac_h6);
        fac12 = SCORE12(1:end-1,1:n_fac_h12);
        %end
    
    for j = 1 : 1 : ny
    progtime2(i,j,intv)         % Progress Time Display.

    y = yy(:,j);
    xx_ex = xx;
    xx_ex(:,YInd(j))=[];            % Set Explanatory Variable excluding Target Variable

        if rero == 1
            yyt = y(1:i+R+hmax+pmax-2,:);        ylag = divlag(yyt,pmax+hmax-1);        
        else 
            yyt = y(i:i+R+hmax+pmax-2,:);        ylag = divlag(yyt,pmax+hmax-1);        
        end
        %ylag = divlag(yyt,pmax+hmax);
        %date_P_lag = divlag(date_P,pmax+hmax);
        y_tar  = ylag(:,1);         % DV for 1 step ahead forecasting
        %date_P_tar = date_P_lag(:,1);
        
        % Setting lagged variable of dependent variable
        [IC_tar,sel_tar]=ar_sel(y_tar);
        seld = sel_tar(2);             seld_all(i,j) = seld;
        %seld = pmax;       % Keep the max length
        y_lags_h1  = [ones(rows(ylag),1),ylag(:,2:2+seld-1)];   %date_P_h1 = date_P_lag(:,2:2+seld-1);
        y_lags_h3  = [ones(rows(ylag),1),ylag(:,4:4+seld-1)];            
        y_lags_h6  = [ones(rows(ylag),1),ylag(:,7:7+seld-1)];            
        y_lags_h12 = [ones(rows(ylag),1),ylag(:,13:13+seld-1)];            
    
        if rero == 1
            xx_ex_h1  = xx_ex(pmax+hmax:pmax+hmax+i+R-1,:); 
            xx_ex_h3  = xx_ex(pmax+hmax-2:pmax+hmax+i+R-3,:);
            xx_ex_h6  = xx_ex(pmax+hmax-5:pmax+hmax+i+R-6,:);
            xx_ex_h12 = xx_ex(pmax+hmax-11:pmax+hmax+i+R-12,:);
        else
            xx_ex_h1  = xx_ex(pmax+hmax-1+(i-1):pmax+hmax-1+i+R-1,:); 
            xx_ex_h3  = xx_ex(pmax+hmax-3+(i-1):pmax+hmax-1+i+R-3,:);
            xx_ex_h6  = xx_ex(pmax+hmax-6+(i-1):pmax+hmax-1+i+R-6,:);
            xx_ex_h12 = xx_ex(pmax+hmax-12+(i-1):pmax+hmax-1+i+R-12,:);
        end    
        xx_sel_h1 = xx_h1(:,find(betas_sel(:,i,j,mm,1)==1)');
        xx_sel_h3 = xx_h3(:,find(betas_sel(:,i,j,mm,2)==1)');
        xx_sel_h6 = xx_h6(:,find(betas_sel(:,i,j,mm,3)==1)');        
        xx_sel_h12= xx_h12(:,find(betas_sel(:,i,j,mm,4)==1)');     

        betas_sel_ex=betas_sel;
        betas_sel_ex(YInd(j),i,j,mm,:)=0;
        xx_sel_ex_h1 = xx_ex_h1(:,find(betas_sel_ex(:,i,j,mm,1)==1)');
        xx_sel_ex_h3 = xx_ex_h3(:,find(betas_sel_ex(:,i,j,mm,2)==1)');
        xx_sel_ex_h6 = xx_ex_h6(:,find(betas_sel_ex(:,i,j,mm,3)==1)');        
        xx_sel_ex_h12= xx_ex_h12(:,find(betas_sel_ex(:,i,j,mm,4)==1)');     

        if cols(xx_sel_h1)>=20       
           %n_fac_h1  = numfac(xx_sel_h1,20);
           n_fac_h1=8;
           [SCORE1, matLoads1]  = Factor_Load(xx_sel_h1,20);
           fac1 = SCORE1(1:end-1,1:n_fac_h1);
           xvar_h1  = [y_lags_h1,fac1];
           predx_h1  = [ones(1,1),ylag(end,1:1+seld-1),SCORE1(end,1:n_fac_h1)];
           predx_fac1 = SCORE1(end,1:n_fac_h1);
           clear SCORE1 matLoads1
        elseif cols(xx_sel_ex_h1)>0&cols(xx_sel_ex_h1)<20
           fac1 = xx_sel_ex_h1(1:end-1,:);
           xvar_h1  = [y_lags_h1,fac1];
           predx_fac1 = xx_sel_ex_h1(end,:);
           predx_h1  = [ones(1,1),ylag(end,1:1+seld-1),predx_fac1(end,:)];
        elseif cols(xx_sel_ex_h1)==0
           %n_fac_h1  = numfac(xx_h1,20);
           n_fac_h1=8;
           [SCORE1, matLoads1]  = Factor_Load(xx_h1,20);
           fac1 = SCORE1(1:end-1,1:n_fac_h1);
           xvar_h1  = [y_lags_h1,fac1];
           predx_h1  = [ones(1,1),ylag(end,1:1+seld-1),SCORE1(end,1:n_fac_h1)];
           predx_fac1 = SCORE1(end,1:n_fac_h1);
           clear SCORE1 matLoads1
        end
        
        if cols(xx_sel_h3)>=20       
           %n_fac_h3  = numfac(xx_sel_h3,20);
           n_fac_h3=8;
           [SCORE3, matLoads3]  = Factor_Load(xx_sel_h3,20);
           fac3 = SCORE3(1:end-1,1:n_fac_h3);
           xvar_h3  = [y_lags_h3,fac3];
           predx_h3  = [ones(1,1),ylag(end,3:3+seld-1),SCORE3(end,1:n_fac_h3)];
           predx_fac3 = SCORE3(end,1:n_fac_h3);
           clear SCORE3 matLoads3
        elseif cols(xx_sel_ex_h3)>0&cols(xx_sel_ex_h3)<20
           fac3 = xx_sel_ex_h3(1:end-1,:);
           xvar_h3  = [y_lags_h3,fac3];
           predx_fac3 = xx_sel_ex_h3(end,:);
           predx_h3  = [ones(1,1),ylag(end,3:3+seld-1),predx_fac3(end,:)];
        elseif cols(xx_sel_ex_h3)==0
           %n_fac_h3  = numfac(xx_h3,20);
           n_fac_h3 = 8;
           [SCORE3, matLoads3]  = Factor_Load(xx_h3,20);
           fac3 = SCORE3(1:end-1,1:n_fac_h3);
           xvar_h3  = [y_lags_h3,fac3];
           predx_h3  = [ones(1,1),ylag(end,1:1+seld-1),SCORE3(end,1:n_fac_h3)];
           predx_fac3 = SCORE3(end,1:n_fac_h3);
           clear SCORE3 matLoads3
        end
        
        if cols(xx_sel_h6)>=20       
           %n_fac_h6  = numfac(xx_sel_h6,20);
           n_fac_h6=8;
           [SCORE6, matLoads6]  = Factor_Load(xx_sel_h6,20);
           fac6 = SCORE6(1:end-1,1:n_fac_h6);
           xvar_h6  = [y_lags_h6,fac6];
           predx_h6  = [ones(1,1),ylag(end,6:6+seld-1),SCORE6(end,1:n_fac_h6)];
           predx_fac6 = SCORE6(end,1:n_fac_h6);
           clear SCORE6 matLoads6
        elseif cols(xx_sel_ex_h6)>0&cols(xx_sel_ex_h6)<20
           fac6 = xx_sel_ex_h6(1:end-1,:);
           xvar_h6  = [y_lags_h6,fac6];
           predx_fac6 = xx_sel_ex_h6(end,:);
           predx_h6  = [ones(1,1),ylag(end,6:6+seld-1),predx_fac6(end,:)];
        elseif cols(xx_sel_ex_h6)==0
           %n_fac_h6  = numfac(xx_h6,20);
           n_fac_h6=8;
           [SCORE6, matLoads6]  = Factor_Load(xx_h6,20);
           fac6 = SCORE6(1:end-1,1:n_fac_h6);
           xvar_h6  = [y_lags_h6,fac6];
           predx_h6  = [ones(1,1),ylag(end,6:6+seld-1),SCORE6(end,1:n_fac_h6)];
           predx_fac6 = SCORE6(end,1:n_fac_h6);
           clear SCORE6 matLoads6
        end            
        
        if cols(xx_sel_h12)>=20       
           %n_fac_h12 = numfac(xx_sel_h12,20);
           n_fac_h12=8;
           [SCORE12,matLoads12] = Factor_Load(xx_sel_h12,20);
           fac12= SCORE12(1:end-1,1:n_fac_h12);
           xvar_h12 = [y_lags_h12,fac12];
           predx_h12 = [ones(1,1),ylag(end,12:12+seld-1),SCORE12(end,1:n_fac_h12)];
           predx_fac12= SCORE12(end,1:n_fac_h12);
           clear SCORE12 matLoads12
        elseif cols(xx_sel_ex_h12)>0&cols(xx_sel_ex_h12)<20
           fac12= xx_sel_ex_h12(1:end-1,:);
           xvar_h12 = [y_lags_h12,fac12];
           predx_fac12= xx_sel_ex_h12(end,:);
           predx_h12 = [ones(1,1),ylag(end,12:12+seld-1),predx_fac12(end,:)];
        elseif cols(xx_sel_ex_h12)==0
           %n_fac_h12 = numfac(xx_h12,20);
           n_fac_h12=8;
           [SCORE12,matLoads12] = Factor_Load(xx_h12,20);
           fac12= SCORE12(1:end-1,1:n_fac_h12);
           xvar_h12 = [y_lags_h12,fac12];
           predx_h12 = [ones(1,1),ylag(end,12:12+seld-1),SCORE12(end,1:n_fac_h12)];
           predx_fac12= SCORE12(end,1:n_fac_h12);
           clear SCORE12 matLoads12
        end
        
        B_h1  = (y_lags_h1' *y_lags_h1)\y_lags_h1'*y_tar;
        B_h3  = (y_lags_h3' *y_lags_h3)\y_lags_h3'*y_tar;
        B_h6  = (y_lags_h6' *y_lags_h6)\y_lags_h6'*y_tar;
        B_h12 = (y_lags_h12'*y_lags_h12)\y_lags_h12'*y_tar;
        
        z0_h1 = y_tar - y_lags_h1 * B_h1 ;         % Residual : z0 
        z0_h3 = y_tar - y_lags_h3 * B_h3 ;         % Residual : z0 
        z0_h6 = y_tar - y_lags_h6 * B_h6 ;         % Residual : z0 
        z0_h12 = y_tar - y_lags_h12 * B_h12 ;      % Residual : z0 
    
    % ---------------------------------------------------------------------
    % LARS, EN, NNG Setup--------------------------------------------------
        facnorm_h1  = normalize([fac1;predx_fac1]);
        %znorm_h1  = center(z0_h1);
        znorm_h1  = (z0_h1);
        facnorm_h3  = normalize([fac3;predx_fac3]);
        %znorm_h3  = center(z0_h3);
        znorm_h3  = (z0_h3);
        facnorm_h6  = normalize([fac6;predx_fac6]);
        %znorm_h6  = center(z0_h6);
        znorm_h6  = (z0_h6);
        facnorm_h12 = normalize([fac12;predx_fac12]);
        %znorm_h12 = center(z0_h12);
        znorm_h12 = (z0_h12);
    % ---------------------------------------------------------------------

    % Saving the predictors for AR terms
    pred_ar(i,1:length(ylag(end, 1: 1+seld-1))+1,1) = [1,ylag(end,1: 1+seld-1)];
    pred_ar(i,1:length(ylag(end, 3: 3+seld-1))+1,2) = [1,ylag(end,3: 3+seld-1)];
    pred_ar(i,1:length(ylag(end, 6: 6+seld-1))+1,3) = [1,ylag(end,6: 6+seld-1)];
    pred_ar(i,1:length(ylag(end,12:12+seld-1))+1,4) = [1,ylag(end,12:12+seld-1)];
    
    
% -------------------------------------------------------------------------        
% Starting Main Program ( Different Forecating Methods )         
% -------------------------------------------------------------------------
        if mc(1) == 1
            % [1] Autoregressive
            predx_ar_h1  = [ones(1,1),ylag(end,1:1+seld-1)];
            predx_ar_h3  = [ones(1,1),ylag(end,3:3+seld-1)];
            predx_ar_h6  = [ones(1,1),ylag(end,6:6+seld-1)];
            predx_ar_h12 = [ones(1,1),ylag(end,12:12+seld-1)];
            
            
            yhat_ar(i,j,1) = predx_ar_h1*B_h1;
            yhat_ar(i,j,2) = predx_ar_h3*B_h3;
            yhat_ar(i,j,3) = predx_ar_h6*B_h6;
            yhat_ar(i,j,4) = predx_ar_h12*B_h12;
            
            clear xvar_ar_h1 xvar_ar_h3 xvar_ar_h6 xvar_ar_h12 %predx_ar_h1 predx_ar_h3 predx_ar_h6 predx_ar_h12
            clear beta_ar_h1 beta_ar_h3 beta_ar_h6 beta_ar_h12
        end
% -------------------------------------------------------------------------            
% -------------------------------------------------------------------------
        if mc(6) == 1
            % [6] Bagging
            
            [yhat_bag_t_h1,qq,qqq,beta_bag1]  = bagging_shrink2(y_tar,xvar_h1,seld,fac1,predx_fac1,[ones(1,1),ylag(end,1:1+seld-1)],c);
            [yhat_bag_t_h3,qq,qqq,beta_bag3]  = bagging_shrink2(y_tar,xvar_h3,seld,fac3,predx_fac3,[ones(1,1),ylag(end,3:3+seld-1)],c);
            [yhat_bag_t_h6,qq,qqq,beta_bag6]  = bagging_shrink2(y_tar,xvar_h6,seld,fac6,predx_fac6,[ones(1,1),ylag(end,6:6+seld-1)],c);
            [yhat_bag_t_h12,qq,qqq,beta_bag12]= bagging_shrink2(y_tar,xvar_h12,seld,fac12,predx_fac12,[ones(1,1),ylag(end,12:12+seld-1)],c);
            
            yhat_bag(i,j,1) = yhat_bag_t_h1;
            yhat_bag(i,j,2) = yhat_bag_t_h3;
            yhat_bag(i,j,3) = yhat_bag_t_h6;
            yhat_bag(i,j,4) = yhat_bag_t_h12;
            clear yhat_bag_t_h1 yhat_bag_t_h3 yhat_bag_t_h6 yhat_bag_t_h12 lamda pac_hat
        end
% -------------------------------------------------------------------------
        if mc(7) == 1
        % [7] Component Boosting 
        
        %[PHI,beta,IC,beta_IC_h1]= com_boost_ic(xvar_h1,y_tar,.5,M);
        %[PHI,beta,IC,beta_IC_h3]= com_boost_ic(xvar_h3,y_tar,.5,M);
        %[PHI,beta,IC,beta_IC_h6]= com_boost_ic(xvar_h6,y_tar,.5,M);
        %[PHI,beta,IC,beta_IC_h12]= com_boost_ic(xvar_h12,y_tar,.5,M);
        
        [qq,qqq,qqqq,beta_IC_h1] = com_boost_ic(fac1,z0_h1,.5,M);
        [qq,qqq,qqqq,beta_IC_h3] = com_boost_ic(fac3,z0_h3,.5,M);
        [qq,qqq,qqqq,beta_IC_h6] = com_boost_ic(fac6,z0_h6,.5,M);
        [PHI,beta,IC,beta_IC_h12]= com_boost_ic(fac12,z0_h12,.5,M);

        yhat_cbst(i,j,1) = predx_ar_h1*B_h1 + predx_fac1 * beta_IC_h1;    
        yhat_cbst(i,j,2) = predx_ar_h3*B_h3 + predx_fac3 * beta_IC_h3;    
        yhat_cbst(i,j,3) = predx_ar_h6*B_h6 + predx_fac6 * beta_IC_h6;    
        yhat_cbst(i,j,4) = predx_ar_h12*B_h12+ predx_fac12* beta_IC_h12;    
        clear PHI beta IC beta_IC_h1 beta_IC_h3 beta_IC_h6 beta_IC_h12
        end
% -------------------------------------------------------------------------
        if mc(8) == 1
        % [8] Bayesian Model Averaging I ( g = 1/n)
        
        opt1 = 0; opt2 = 1; opt3 = 1;        
        
        beta_bma1_h1  = bma_koop(nburn,nkeep,z0_h1,fac1,opt1,opt2,opt3);
        beta_bma1_h3  = bma_koop(nburn,nkeep,z0_h3,fac3,opt1,opt2,opt3);
        beta_bma1_h6  = bma_koop(nburn,nkeep,z0_h6,fac6,opt1,opt2,opt3);
        beta_bma1_h12 = bma_koop(nburn,nkeep,z0_h12,fac12,opt1,opt2,opt3);

        yhat_bma1(i,j,1) = predx_ar_h1*B_h1 + predx_fac1 * beta_bma1_h1;    
        yhat_bma1(i,j,2) = predx_ar_h3*B_h3 + predx_fac3 * beta_bma1_h3;    
        yhat_bma1(i,j,3) = predx_ar_h6*B_h6 + predx_fac6 * beta_bma1_h6;    
        yhat_bma1(i,j,4) = predx_ar_h12*B_h12 + predx_fac12 * beta_bma1_h12;    
        end
% -------------------------------------------------------------------------
        if mc(9) == 1
        % [9] Bayesian Model Averaging I ( g = 1/(k^2))
        
        opt1 = 1; opt2 = 1; opt3 = 1;    
        beta_bma2_h1 = bma_koop(nburn,nkeep,z0_h1,fac1,opt1,opt2,opt3);
        beta_bma2_h3 = bma_koop(nburn,nkeep,z0_h3,fac3,opt1,opt2,opt3);
        beta_bma2_h6 = bma_koop(nburn,nkeep,z0_h6,fac6,opt1,opt2,opt3);
        beta_bma2_h12= bma_koop(nburn,nkeep,z0_h12,fac12,opt1,opt2,opt3);

        yhat_bma2(i,j,1) = predx_ar_h1*B_h1 + predx_fac1 * beta_bma2_h1;    
        yhat_bma2(i,j,2) = predx_ar_h3*B_h3 + predx_fac3 * beta_bma2_h3;    
        yhat_bma2(i,j,3) = predx_ar_h6*B_h6 + predx_fac6 * beta_bma2_h6;    
        yhat_bma2(i,j,4) = predx_ar_h12*B_h12 + predx_fac12 * beta_bma2_h12;    
        
        end
% -------------------------------------------------------------------------
        if mc(10) == 1
        % [10] Ridge Regression
        re_h1 = ridge(z0_h1,fac1);
        re_h3 = ridge(z0_h3,fac3);
        re_h6 = ridge(z0_h6,fac6);
        re_h12 = ridge(z0_h12,fac12);
        
        beta_ridge_h1 = re_h1.beta;
        beta_ridge_h3 = re_h3.beta;
        beta_ridge_h6 = re_h6.beta;
        beta_ridge_h12 = re_h12.beta;
        
        yhat_ridge(i,j,1) = predx_ar_h1*B_h1 + predx_fac1*beta_ridge_h1;    
        yhat_ridge(i,j,2) = predx_ar_h3*B_h3 + predx_fac3*beta_ridge_h3;    
        yhat_ridge(i,j,3) = predx_ar_h6*B_h6 + predx_fac6*beta_ridge_h6;    
        yhat_ridge(i,j,4) = predx_ar_h12*B_h12+predx_fac12*beta_ridge_h12;
        clear beta_ridge_h1 beta_ridge_h3 beta_ridge_h6 beta_ridge_h12
        
        end
% -------------------------------------------------------------------------            
        if mc(11) == 1
        % [11] Least Angle Regression
        
        %[w_h1, B_h1, C, sbc, fpe, th]=arfit(y_tar , seld, seld, 'zero');
        %[w_h3, B_h3, C, sbc, fpe, th]=arfit(y_tar , seld, seld, 'zero');
        %[w_h6, B_h6, C, sbc, fpe, th]=arfit(y_tar , seld, seld, 'zero');
        %[w_h12, B_h12, C, sbc, fpe, th]=arfit(y_tar , seld, seld, 'zero');

        % Step 1. Put AR residual to lars on factors
        
        beta_tar1 = lars(facnorm_h1(1:end-1,:), znorm_h1,'lars',0,0,[],1);
        beta_tar3 = lars(facnorm_h3(1:end-1,:), znorm_h3,'lars',0,0,[],1);
        beta_tar6 = lars(facnorm_h6(1:end-1,:), znorm_h6,'lars',0,0,[],1);
        beta_tar12= lars(facnorm_h12(1:end-1,:), znorm_h12,'lars',0,0,[],1);
        
        beta_tar1  = real(beta_tar1);
        beta_tar3  = real(beta_tar3);
        beta_tar6  = real(beta_tar6);
        beta_tar12 = real(beta_tar12);
        
        %beta_tar1 = lars(fac1, z0_h1,'lasso',0,0,[],1);
        %beta_tar3 = lars(fac3, z0_h3,'lasso',0,0,[],1);
        %beta_tar6 = lars(fac6, z0_h6,'lasso',0,0,[],1);
        %beta_tar12 = lars(fac12, z0_h12,'lasso',0,0,[],1);
        
        IC_h1  = zeros(cols(fac1),1);
        IC_h3  = zeros(cols(fac3),1);
        IC_h6  = zeros(cols(fac6),1);
        IC_h12 = zeros(cols(fac12),1);
        
        for f = 1: 1: cols(fac1)
            sig2_h1  = (z0_h1  - fac1  * beta_tar1(f+1,:)')' *(z0_h1  - fac1  * beta_tar1(f+1,:)');
            IC_h1(f,1)  = log(sig2_h1)  + ( cols(beta_tar1)  * log(rows(z0_h1) )) / rows(z0_h1);
        end
        for f = 1: 1: cols(fac3)
            sig2_h3  = (z0_h3  - fac3  * beta_tar3(f+1,:)')' *(z0_h3  - fac3  * beta_tar3(f+1,:)');
            IC_h3(f,1)  = log(sig2_h3)  + ( cols(beta_tar3)  * log(rows(z0_h3) )) / rows(z0_h3);
        end
        for f = 1: 1: cols(fac6)
            sig2_h6  = (z0_h6  - fac6  * beta_tar6(f+1,:)')' *(z0_h6  - fac6  * beta_tar6(f+1,:)');
            IC_h6(f,1)  = log(sig2_h6)  + ( cols(beta_tar6)  * log(rows(z0_h6) )) / rows(z0_h6);
        end
        for f = 1: 1: cols(fac12)
            sig2_h12 = (z0_h12 - fac12 * beta_tar12(f+1,:)')'*(z0_h12 - fac12 * beta_tar12(f+1,:)');
            IC_h12(f,1) = log(sig2_h12) + ( cols(beta_tar12) * log(rows(z0_h12) )) / rows(z0_h12);
        end
        
        [val_h1,IC_i_h1] = min(IC_h1);
        [val_h3,IC_i_h3] = min(IC_h3);
        [val_h6,IC_i_h6] = min(IC_h6);
        [val_h12,IC_i_h12] = min(IC_h12);
        
        beta_IC_h1  = beta_tar1(IC_i_h1+1,:);      % Finding beta by BIC
        beta_IC_h3  = beta_tar3(IC_i_h3+1,:);      % Finding beta by BIC
        beta_IC_h6  = beta_tar6(IC_i_h6+1,:);      % Finding beta by BIC
        beta_IC_h12 = beta_tar12(IC_i_h12+1,:);      % Finding beta by BIC
        
        beta_lars_h1 = [B_h1;beta_IC_h1'];           % Put together 
        beta_lars_h3 = [B_h3;beta_IC_h3'];           % Put together 
        beta_lars_h6 = [B_h6;beta_IC_h6'];           % Put together 
        beta_lars_h12= [B_h12;beta_IC_h12'];           % Put together 
        
        %yhat_lars(i,j,1) = mean(z0_h1) + [ones(1,1),(ylag(end,1:1+seld-1)-mean(z0_h1)),facnorm_h1(end,:)] * beta_lars_h1;
        %yhat_lars(i,j,2) = mean(z0_h3) + [ones(1,1),(ylag(end,3:3+seld-1)-mean(z0_h3)),facnorm_h3(end,:)] * beta_lars_h3;
        %yhat_lars(i,j,3) = mean(z0_h6) + [ones(1,1),(ylag(end,6:6+seld-1)-mean(z0_h6)),facnorm_h6(end,:)] * beta_lars_h6;
        %yhat_lars(i,j,4) = mean(z0_h12)+ [ones(1,1),(ylag(end,12:12+seld-1)-mean(z0_h12)),facnorm_h12(end,:)]* beta_lars_h12;
        
        yhat_lars(i,j,1) = [1,ylag(end,1 : 1+seld-1),facnorm_h1(end,:) ] * beta_lars_h1;
        yhat_lars(i,j,2) = [1,ylag(end,3 : 3+seld-1),facnorm_h3(end,:) ] * beta_lars_h3;
        yhat_lars(i,j,3) = [1,ylag(end,6 : 6+seld-1),facnorm_h6(end,:) ] * beta_lars_h6;
        yhat_lars(i,j,4) = [1,ylag(end,12:12+seld-1),facnorm_h12(end,:)] * beta_lars_h12;
        clear beta_lars_h1 beta_lars_h3 beta_lars_h6 beta_lars_h12
        end
% -------------------------------------------------------------------------
        if mc(12) == 1
        % [12] Elastic Net
        
        % Step 1. Put AR residual to lars on factors
        
        beta1_en_h1 = larsen(facnorm_h1(1:end-1,:), znorm_h1,0.1,0,1);
        beta1_en_h3 = larsen(facnorm_h3(1:end-1,:), znorm_h3,0.1,0,1);
        beta1_en_h6 = larsen(facnorm_h6(1:end-1,:), znorm_h6,0.1,0,1);
        beta1_en_h12 = larsen(facnorm_h12(1:end-1,:), znorm_h12,0.1,0,1);

        beta_en_h1  = real(beta1_en_h1);
        beta_en_h3  = real(beta1_en_h3);
        beta_en_h6  = real(beta1_en_h6);
        beta_en_h12 = real(beta1_en_h12);
        
        IC_h1  = zeros(cols(fac1),1);
        IC_h3  = zeros(cols(fac3),1);
        IC_h6  = zeros(cols(fac6),1);
        IC_h12 = zeros(cols(fac12),1);
        
        for f = 1: 1: cols(fac1)
            sig2_h1  = (z0_h1  - fac1  * beta_en_h1(f+1,:)')' *(z0_h1  - fac1  * beta_en_h1(f+1,:)');
            IC_h1(f,1)  = log(sig2_h1)  + ( cols(beta_en_h1)  * log(rows(z0_h1) )) / rows(z0_h1);
        end
        for f = 1: 1: cols(fac3)
            sig2_h3  = (z0_h3  - fac3  * beta_en_h3(f+1,:)')' *(z0_h3  - fac3  * beta_en_h3(f+1,:)');
            IC_h3(f,1)  = log(sig2_h3)  + ( cols(beta_en_h3)  * log(rows(z0_h3) )) / rows(z0_h3);
        end
        for f = 1: 1: cols(fac6)
            sig2_h6  = (z0_h6  - fac6  * beta_en_h6(f+1,:)')' *(z0_h6  - fac6  * beta_en_h6(f+1,:)');
            IC_h6(f,1)  = log(sig2_h6)  + ( cols(beta_en_h6)  * log(rows(z0_h6) )) / rows(z0_h6);
        end
        for f = 1: 1: cols(fac12)
            sig2_h12 = (z0_h12 - fac12 * beta_en_h12(f+1,:)')'*(z0_h12 - fac12 * beta_en_h12(f+1,:)');
            IC_h12(f,1) = log(sig2_h12) + ( cols(beta_en_h12) * log(rows(z0_h12) )) / rows(z0_h12);
        end
         
        [val_h1,IC_i_h1]   = min(IC_h1);
        [val_h3,IC_i_h3]   = min(IC_h3);
        [val_h6,IC_i_h6]   = min(IC_h6);
        [val_h12,IC_i_h12] = min(IC_h12);
        
        beta_en_IC_h1  = beta1_en_h1(IC_i_h1+1,:);      % Finding beta by BIC
        beta_en_IC_h3  = beta1_en_h3(IC_i_h3+1,:);      % Finding beta by BIC
        beta_en_IC_h6  = beta1_en_h6(IC_i_h6+1,:);      % Finding beta by BIC
        beta_en_IC_h12 = beta1_en_h12(IC_i_h12+1,:);    % Finding beta by BIC
    
        beta_en_h1  = [B_h1;beta_en_IC_h1'];           % Put together 
        beta_en_h3  = [B_h3;beta_en_IC_h3'];           % Put together 
        beta_en_h6  = [B_h6;beta_en_IC_h6'];           % Put together                 
        beta_en_h12 = [B_h12;beta_en_IC_h12'];         % Put together 
        
        %yhat_en(i,j,1) = predx_h1 * beta_en_h1;
        %yhat_en(i,j,2) = predx_h3 * beta_en_h3;
        %yhat_en(i,j,3) = predx_h6 * beta_en_h6;
        %yhat_en(i,j,4) = predx_h12 * beta_en_h12;

        yhat_en(i,j,1) = mean(z0_h1) + [ones(1,1),(ylag(end,1:1+seld-1)-mean(z0_h1)),facnorm_h1(end,:)] * beta_en_h1;
        yhat_en(i,j,2) = mean(z0_h3) + [ones(1,1),(ylag(end,3:3+seld-1)-mean(z0_h3)),facnorm_h3(end,:)] * beta_en_h3;
        yhat_en(i,j,3) = mean(z0_h6) + [ones(1,1),(ylag(end,6:6+seld-1)-mean(z0_h6)),facnorm_h6(end,:)] * beta_en_h6;
        yhat_en(i,j,4) = mean(z0_h12)+ [ones(1,1),(ylag(end,12:12+seld-1)-mean(z0_h12)),facnorm_h12(end,:)]* beta_en_h12;
        clear beta_en_h1 beta_en_h3 beta_en_h6 beta_en_h12
        
        end
% -------------------------------------------------------------------------
        if mc(13) == 1
        % [13] Nonnegative Garrote
        
        % Step 1. Put AR residual to lars on factors
        
        [beta13_h1,qq,qqq] = nng_garotte_new(facnorm_h1(1:end-1,:), znorm_h1);
        [beta13_h3,qq,qqq] = nng_garotte_new(facnorm_h3(1:end-1,:), znorm_h3);
        [beta13_h6,qq,qqq] = nng_garotte_new(facnorm_h6(1:end-1,:), znorm_h6);
        [beta13_h12,qq,qqq]= nng_garotte_new(facnorm_h12(1:end-1,:),znorm_h12);
        
        beta_nng_h1  = [B_h1;beta13_h1];           % Put together 
        beta_nng_h3  = [B_h3;beta13_h3];           % Put together 
        beta_nng_h6  = [B_h6;beta13_h6];           % Put together 
        beta_nng_h12 = [B_h12;beta13_h12];           % Put together 
    
        %yhat_nng(i,j,1) = predx_h1 * beta_nng_h1;
        %yhat_nng(i,j,2) = predx_h3 * beta_nng_h3;
        %yhat_nng(i,j,3) = predx_h6 * beta_nng_h6;
        %yhat_nng(i,j,4) = predx_h12 * beta_nng_h12;
        
        yhat_nng(i,j,1) = mean(z0_h1) + [ones(1,1),(ylag(end,1:1+seld-1)-mean(z0_h1)),facnorm_h1(end,:)] * beta_nng_h1;
        yhat_nng(i,j,2) = mean(z0_h3) + [ones(1,1),(ylag(end,3:3+seld-1)-mean(z0_h3)),facnorm_h3(end,:)] * beta_nng_h3;
        yhat_nng(i,j,3) = mean(z0_h6) + [ones(1,1),(ylag(end,6:6+seld-1)-mean(z0_h6)),facnorm_h6(end,:)] * beta_nng_h6;
        yhat_nng(i,j,4) = mean(z0_h12)+ [ones(1,1),(ylag(end,12:12+seld-1)-mean(z0_h12)),facnorm_h12(end,:)]* beta_nng_h12;
        clear beta_nng_h1 beta_nng_h3 beta_nng_h6 beta_nng_h12

        end
% -------------------------------------------------------------------------
        
    end
    clear xx_ex
end
end

disp(' ')
if rero == 1
    disp('End of the Estimation for RECURSIVE Sample Estimation Under Specification Type 2')
else
    disp('End of the Estimation for ROLLING Sample Estimation Under Specification Type 2')
end
disp(' ')

% Result ------------------------------------------------------------------ 

Y_real = TrYvarTr(end-P+1:end,:); % Actual Value : Mar.1974~May.2009

%Yhat(:,:,:,1)=yhat_ar; Yhat(:,:,:,2)=yhat_cbst; Yhat(:,:,:,3)=yhat_bma1; Yhat(:,:,:,4)=yhat_bma2;
%Yhat(:,:,:,5)=yhat_lars; Yhat(:,:,:,6)=yhat_en; Yhat(:,:,:,7)=yhat_nng;
%Yhat(:,:,:,8)=sum(Yhat(:,:,:,1:7),4)/7;

Yhat(:,:,:,1)=yhat_ar;Yhat(:,:,:,2)=yhat_ols; 
Yhat(:,:,:,3)=yhat_CADL;Yhat(:,:,:,4)=yhat_faar; Yhat(:,:,:,5)=yhat_pcr;
Yhat(:,:,:,6)=yhat_bag; Yhat(:,:,:,7)=yhat_cbst; 
Yhat(:,:,:,8)=yhat_bma1; Yhat(:,:,:,9)=yhat_bma2;
Yhat(:,:,:,10)=yhat_ridge; Yhat(:,:,:,11)=yhat_lars; Yhat(:,:,:,12)=yhat_en; Yhat(:,:,:,13)=yhat_nng;
Yhat(:,:,:,14)=sum(Yhat(:,:,:,[1,7,8,9,11,12,13]),4)/7;


%Yhat(rows(Yhat),:,:,:) = [];        % Get rid of last forecasting since it is for unobserved sample.(June.2009)
[rr cc dd kk] = size(Yhat);

MSE = zeros(rr,cc,kk,dd);
MSE_ratio = zeros(kk,cc,dd);

for h=1:1:dd
    for l = 1 : 1 : kk
        MSE(:,:,l,h) = (Yhat(:,:,h,l)-Y_real).^2;
    end
end

for h=1:1:dd
    MSE_ratio(1,:,h) = sum(MSE(:,:,1,h));
    for i = 2 : 1 : kk
        MSE_ratio(i,:,h) = sum(MSE(:,:,i,h))./sum(MSE(:,:,1,h));
    end
end



