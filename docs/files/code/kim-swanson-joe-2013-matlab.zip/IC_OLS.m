function [vec,ICvec,S_F] = IC_OLS(y1,y_lags,xx,choose,IC_h1)
% Autoregressive with Exogenous Variable
% by Hyun Hak Kim, June, 2010
% 
% Input -  y1     : the dependent variable
%          y_lags : lagged value of the dependent variable
%          xx     : vector of exogenous variables
%          choose : parameter to set how many exogenous variables are included in the model 
%          IC_h1  : value of information criteria 
% Output - vec    : vector of selected exogenous variable
%          ICvec  : value of information criteria to decide the lage of exogenous variables
%


            ICvec = IC_h1(2); % SIC value.
            [mmx,nnx]=size(xx);
            xxx = [xx;[1:1:nnx]];
            for d = 1:1:choose;
                clear BIC;
                for f = 1:1:cols(xxx);
                    if (d == 1) || (S_F(d-1)==0);
                        t_xvar = [y_lags,xxx(1:mmx,f)];
                        %t_beta_arx = pinv(xxx(1:mmx,f)'*xxx(1:mmx,f))*xxx(1:mmx,f)'*y1_h1;
                        t_beta_arx = pinv(t_xvar'*t_xvar)*t_xvar'*y1;
                        t_yhat = t_xvar*t_beta_arx;
                        eps2 = (y1-t_yhat).^2;
                        %clear BIC;
                        BIC(:,f) = log((1/mmx)*sum(eps2)) + (1 * log(mmx)) / mmx;                    
                        [ICt,vect] = min(BIC);
                    
                     elseif (d>1)||(S_F(d-1)==1)
                        t_xvar2=[y_lags,x_inc(1:mmx,:),xxx(1:mmx,f)];
                        %t_bet_arx = pinv([x_inc(1:mmx,:),xxx(1:mmx,f)]'*[x_inc(1:mmx,:),xxx(1:mmx,f)])*[x_inc(1:mmx,:),xxx(1:mmx,f)]'*y1;
                        t_beta_arx = pinv(t_xvar2'*t_xvar2)*t_xvar2'*y1;
                        t_yhat = t_xvar2*t_beta_arx;
                        eps2 = (y1-t_yhat).^2;
                        %clear BIC;
                        BIC(:,f) = log((1/mmx)*sum(eps2)) + (1 * log(mmx)) / mmx;                    
                        [ICt,vect] = min(BIC);
                        
                    end
                end
                if d==1
                    if ICt<IC_h1(2);
                        x_inc(:,d) = xxx(:,vect);
                        vec(d) = xxx(mmx+1,vect);
                        ICvec=[ICvec,ICt];
                        S_F(d)=1;
                        xxx(:,vect) = [];
                    else
                        vec(d)=0;
                        ICvec=[ICvec,ICt];
                        S_F(d)=0;
                        xxx(:,vect)=[];
                    end
                else
                  if S_F(d-1)==1
                    if ICt<ICvec(d-1);
                        x_inc(:,d) = xxx(:,vect);
                        vec(d) = xxx(mmx+1,vect);
                        ICvec=[ICvec,ICt];
                        S_F(d)=1;
                        xxx(:,vect) = [];
                    else
                        ICvec=[ICvec,ICt];
                        vec(d)=0;
                        S_F(d)=0;
                        xxx(:,vect)=[];
                    end
                  else
                    t_ICvec=ICvec;
                    %t_ICvec(find(S_F==0))=[];
                    if ICt<min(t_ICvec);
                        x_inc(:,d) = xxx(:,vect);
                        vec(d) = xxx(mmx+1,vect);
                        ICvec=[ICvec,ICt];
                        S_F(d)=1;
                        xxx(:,vect) = [];
                    else
                        ICvec=[ICvec,ICt];
                        vec(d)=0;
                        S_F(d)=0;
                        xxx(:,vect)=[];
                    end
                  end
                      
                end
                end
            end
            
