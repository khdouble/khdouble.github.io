function [beta_CADL,yhat_CADL,predx_adl] = CBADL(y1,xx3,ylag,y_lags,seld,pmax,hmax,h)
% Combined Bivariate Autoregressive Distributed Lags Model 
% Input - y1 - dependent variables
%         xx3 - explanatory variables 
%         ylag - lags of the dependent
%         y_lags - vector of lagged variable of dependet to correponds to explantor variable
%                  (see the main progrm the difference b/w ylag and y_lags)
%         seld - selected lag length
%         pmax - max of lag length 
%         hmax - max of forecast horizon
%         h - forcast horizon
% Output - beta_CADL - coefficient of the model 
%          yhat_CADL - fitted value of the model 
%          predx_adl - predictor of the model which is used to forecast next forecast horizon




% by Hyun Hak Kim
% June, 2010

[ mx3 , nx3, ox3 ] = size(xx3);
    %beta_CADL = zeros(nx3,1);
    yhat_adl = zeros(nx3,1);
    
    for k = 1 : 1 : nx3
        %disp(k)
            
        x_k = xx3(:,k); % Pick x data
                
        [IC,selx]=ar_sel(x_k); %[IC,sely]=ar_sel(yy);
                
        selx = selx(2);
            
        if selx == 0
           selx=1;
         end            
                
        % For easier calculation, I limit the length of x to be
        % less than or equal to the length of y. 
                
        if selx > seld 
           selx = seld;
        end
                
        adl_xlag = divlag(x_k,pmax+hmax-1);

        adl_x_lags = adl_xlag(:,h+1:h+selx);

        adl_xvar = [y_lags,adl_x_lags];
                
        %beta_CADL(:,k) = (adl_xvar'*adl_xvar)\adl_xvar'*y1;
        beta_CADL = (adl_xvar'*adl_xvar)\adl_xvar'*y1;
              
        predx_adl = [ylag(end,h:h+seld-1),adl_xlag(end,h:h+selx-1)];
                    
        yhat_adl(k) = predx_adl * beta_CADL;
        %clear beta_CADL
    end
    yhat_CADL = mean(yhat_adl);
