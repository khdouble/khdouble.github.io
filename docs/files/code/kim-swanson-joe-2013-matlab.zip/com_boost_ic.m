function [PHI,beta,IC,beta_IC]= com_boost_ic(X,Y,nu,M);
% Component-Wise Boosting 
% Based on Bai and Ng (2009), "Boosting Diffusion Indices"
% by Hyun Hak Kim
% June, 2010
%
% Input - X - vector explanatory variables
%         Y - the dependent variables
%         nu - tuning parameter
%         M - max number of iteration
% Output - PHI - value of learner (fitted value)
%          beta - coefficient at all iterations 
%          IC - information criteria to obtain optimal estimate
%          beta_IC - optimal estimate to minimize the information criteria 


[mm,nn]=size(X);

mean_y = mean(Y);

PHI(:,1) = mean_y * ones(rows(Y),1);

%re0 = ols(PHI(:,1),X);

%beta(:,1) = re0.beta;
beta(:,1) = zeros(cols(X),1);
B(:,:,1) = zeros(mm,mm,1);

for m = 1 : 1 : M

%CRI =1;
%m=1;
%while CRI>0.00000000000000000001

u = Y - PHI(:,m);
for i = 1 : 1 : nn
    z = X(:,i);
    re1 = ols(u,z);
    SSR(i) = re1.sige;
end
    [val,i_m] = min(SSR);
    zz = X(:,i_m);
    re2 = ols(u,zz);
    phi = re2.yhat;
    PHI(:,m+1) = PHI(:,m) + nu * phi;
    % Calculating stopping time
    PM = zz*inv(zz'*zz)*zz';
    B(:,:,m+1) = B(:,:,m) + nu * PM * ( eye(mm)- B(:,:,m) );
    df = trace(B(:,:,m+1));
    sig2m = (Y-PHI(:,m+1))'*(Y-PHI(:,m+1));
    IC(m,1) = log(sig2m) + (log(mm) * df) / mm ;

    CRI = sum(PHI(:,m+1)-PHI(:,m));
    loc = zeros(cols(X),1);
    loc(i_m,1) = 1;
    beta(:,m+1) = beta(:,m) + nu * re2.beta * loc;
     
end 
[val,IC_m] = min(IC);
beta_IC = beta(:,IC_m+1);