function [yhat_bag,lamda,pc_hat,beta_bag] = bagging_shrink2(y1,xvar,seld,fac,fac1,ylag,c)
% Bagging with Shrinkage Way 
% from Stock and Watson(2005), 'Empirical Comparison of Forecasting Methods'
% by Hyun Hak Kim 
% July 2010
%
% Input - y1 - the dependent variable
%         xvar - explanatory variable
%         seld - selected lag length of the dependent
%         fac - vector of factors
%         fac1 - vector of factor to be predictor to forecast y_t+h
%         ylag - lagged set of the dependent
%         c - tuning paramters
% Output - yhat_bag - forecasted value for y_t+h. it depends on what you assign on fac1
%          beta_bag - coefficient of the model 
        
            beta_bag = (xvar'*xvar)\xvar'*y1;
        
            % Shrinakage Bagging estimation
            lamda = beta_bag(1:seld+1,:);
            delta = beta_bag(seld+2:rows(beta_bag));
    
            resid = y1(:,1) - xvar*beta_bag;
            sigu = resid'*resid;
        
            sige = sigu/(rows(xvar)-cols(xvar));
            %sige = sigu/sqrt(rows(fac));
            %tmp = sige*diag(inv(fac'*fac));
            tmp = sige*diag(inv(xvar'*xvar));
            tstat = beta_bag./(sqrt(tmp));
            
            t_delta = tstat(seld+1:rows(beta_bag));
            t_delta = real(t_delta);
            
            % Forecasting 

            pred_fac = fac1;
            %pred_W   = ylag(rows(ylag),cols(ylag)-seld:cols(ylag)-1);
            pred_W = ylag;
            
            psi_bag = zeros(cols(fac),1);
            %for k = 1 : 1 : n_fac
            for k = 1 : 1 : cols(fac)
                if abs(t_delta(k))<c
                    psi_bag(k,1)=0;
                else
                    psi_bag(k,1) = 1 - normcdf(t_delta(k)+c)+normcdf(t_delta(k)-c)+(normpdf(t_delta(k)-c)-normpdf(t_delta(k)+c))/t_delta(k);
                end
            end
            pc_hat = pred_fac*(delta.*psi_bag);
            
            beta_bag = [lamda;delta.*psi_bag];
        
            yhat_bag = pred_W*lamda + pc_hat;
