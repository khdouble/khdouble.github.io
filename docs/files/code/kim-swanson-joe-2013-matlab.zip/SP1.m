% This program replicates
% Specification Type 1 without lags
% of Hyun Hak Kim ans Norman Swanson (2013)
% "Forecasting Financial and Macroeconomic Variables Using Data Reduction 
% Methods: New Empirical Evidence", Journal of Econometrics, 2013
% 
% Dataset is included as "Dataset02.mat" 
% See the appendix of the paper for details about variables in the set
% Dataset is trimmed into 560 observations to get an even number. 
% (which means we cut first 33 observations.)
%
% This program is automatic system to replicate the result like Table 3. 
% You have an option to select estimation type, Recursive or Rolling. 
%
% Main Results. 
% Yhat - includes all predicted value in out-of-sample periods. 
% MSE - includes mean square forecasting error of 14 forecasting methods
%       against actual value.
% MSE_ratio - includes relative mean square forecasting error of 13
%             forecasting methods against those of autoregressive models.
%
% At the end of process, you are asked to assign result file. Then it will
% produce results like Table 3 for recursive and rolling estimation as you
% select.
clear
disp(' ');
disp('Starting Forecasting for Specification Type 1 : Estimation with Factors from All Regressors');disp(' ');
% pcase = input('Select size of P. 1 for P=400, 2 for P=300, 3 for P=200 ');
% disp(' ');
disp('*** Select Estimation Strategy');disp(' ');
rero = input('1 for Recursive Model, 2 for Rolling Estimation Model - ');disp(' ');
T = 560;
R = 260; 
P = 300;
% if pcase == 1
%     R=160; P=400;
% elseif pcase == 2
%     R=260; P=300;
% elseif pcase == 3
%     R=360; P=200;
% end    
load Dataset02.mat;         % Call orginal data files.

% Parameter Setting -------------------------------------------------------
c = 1.96;                   % Critical Value for Bagging 
M = 50;                     % Boosting iteration
nburn = 100; nkeep = 1000;  % Loop for BMA
hmax = 12; pmax = 4;        % Setting for max horizon and max lag.
% sp = 156;   rw = 156;       % Starting period of forecasting // Rolling windows size
intv = 20;                  % For interval of progress display. Default is set as 20 and it displays the progress in every 20 observations.
xx = TrDataTr;              % Set explanatory data which are alread transformed. 
yy = TrYvarTr;              % Set dependant data which are alread transformed.

% Estimation On/Off Control -----------------------------------------------
% If method is 1, it's on. else if's off. 
mc = ones(1,13);            % All estimation are turned on. 

[ mx , nx ] = size(xx);[ my , ny ] = size(yy);

yhat_ar=zeros(P,ny,4);yhat_ols=zeros(P,ny,4);yhat_CADL=zeros(P,ny,4);yhat_faar=zeros(P,ny,4);
yhat_pcr=zeros(P,ny,4);yhat_bag=zeros(P,ny,4);yhat_cbst=zeros(P,ny,4);yhat_bma1=zeros(P,ny,4);
yhat_bma2=zeros(P,ny,4);yhat_ridge=zeros(P,ny,4);yhat_lars=zeros(P,ny,4);yhat_en=zeros(P,ny,4);
yhat_nng=zeros(P,ny,4);

beta_ar = nan(P,25,ny,4);beta_ols = nan(P,25,ny,4);beta_CADL = nan(P,25,ny,4);
beta_faar = nan(P,25,ny,4);beta_pcr = nan(P,25,ny,4);beta_bag = nan(P,25,ny,4);
beta_cbst= nan(P,25,ny,4);beta_bma1 = nan(P,25,ny,4);beta_bma2 = nan(P,25,ny,4);
beta_ridge = nan(P,25,ny,4);beta_lars = nan(P,25,ny,4);beta_en = nan(P,25,ny,4);
beta_nng = nan(P,25,ny,4);

% Predictor matrix for BOOSTSTRPPING. 
pred_ar  = nan(P,25,4);pred_arx = nan(P,25,4);pred_adl = nan(P,25,4);
pred_far = nan(P,25,4);pred_pcr = nan(P,25,4);pred_nfr = nan(P,25,4);

disp('*** Progress Report');disp(' ')
        
% Pre-allocation 
seld_all = zeros(P,ny);n_fac = zeros(P,ny,4);
        
% Main Loop Program -------------------------------------------------------
xx = xx(end-hmax-pmax-T+1:end,:);
yy = yy(end-hmax-pmax-T+1:end,:);
%date_T = DataDateTr(end-hmax-pmax-T+1:end,:);
j=1;

for i = 1 : 1 : P
        if rero == 1
            xx_h1  = xx(pmax+hmax:pmax+hmax+i+R-1,:);           %date_xx_h1 = date_T(pmax+hmax:pmax+hmax+i+R-1,:);
            xx_h3  = xx(pmax+hmax-2:pmax+hmax+i+R-3,:);
            xx_h6  = xx(pmax+hmax-5:pmax+hmax+i+R-6,:);
            xx_h12 = xx(pmax+hmax-11:pmax+hmax+i+R-12,:);
        else 
            xx_h1  = xx(pmax+hmax-1+(i-1):pmax+hmax-1+i+R-1,:);
            xx_h3  = xx(pmax+hmax-3+(i-1):pmax+hmax-1+i+R-3,:);
            xx_h6  = xx(pmax+hmax-6+(i-1):pmax+hmax-1+i+R-6,:);
            xx_h12 = xx(pmax+hmax-12+(i-1):pmax+hmax-1+i+R-12,:);
        end
        n_fac_h1  = numfac(xx_h1,20);
        n_fac_h3  = numfac(xx_h3,20);
        n_fac_h6  = numfac(xx_h6,20);
        n_fac_h12 = numfac(xx_h12,20);
                
        n_fac(i,j,1)=n_fac_h1;
        n_fac(i,j,2)=n_fac_h3;
        n_fac(i,j,3)=n_fac_h6;
        n_fac(i,j,4)=n_fac_h12;
            
        [SCORE1, matLoads1]  = Factor_Load(xx_h1,20);
        [SCORE3, matLoads3]  = Factor_Load(xx_h3,20);
        [SCORE6, matLoads6]  = Factor_Load(xx_h6,20);
        [SCORE12,matLoads12] = Factor_Load(xx_h12,20);
        clear matLoads1 matLoads3 matLoads6 matLoads12
        
        fac1 = SCORE1(1:end-1,1:n_fac_h1);
        fac3 = SCORE3(1:end-1,1:n_fac_h3);
        fac6 = SCORE6(1:end-1,1:n_fac_h6);
        fac12 = SCORE12(1:end-1,1:n_fac_h12);
    
    for j = 1 : 1 : ny
    progtime2(i,j,intv)         % Progress Time Display.

    y = yy(:,j);
    xx_ex = xx;
    xx_ex(:,YInd(j))=[];            % Set Explanatory Variable excluding Target Variable

        if rero == 1
            yyt = y(1:i-1+R+pmax+hmax,:);
            %date_P = date_T(1:i-1+R+pmax+hmax,:);
        else 
            yyt = y(i:i-1+R+pmax+hmax,:);
        end    
        ylag = divlag(yyt,pmax+hmax);
        %date_P_lag = divlag(date_P,pmax+hmax);
        y_tar  = ylag(:,1);         % DV for 1 step ahead forecasting
        %date_P_tar = date_P_lag(:,1);
        
        % Setting lagged variable of dependent variable
        [IC_tar,sel_tar]=ar_sel(y_tar);
        seld = sel_tar(2);             seld_all(i,j) = seld;
        %seld = pmax;       % Keep the max length
        y_lags_h1  = [ones(rows(ylag),1),ylag(:,2:2+seld-1)];   %date_P_h1 = date_P_lag(:,2:2+seld-1);
        y_lags_h3  = [ones(rows(ylag),1),ylag(:,4:4+seld-1)];            
        y_lags_h6  = [ones(rows(ylag),1),ylag(:,7:7+seld-1)];            
        y_lags_h12 = [ones(rows(ylag),1),ylag(:,13:13+seld-1)];            
    
        if rero == 1
            xx_ex_h1  = xx_ex(pmax+hmax:pmax+hmax+i+R-1,:); 
            xx_ex_h3  = xx_ex(pmax+hmax-2:pmax+hmax+i+R-3,:);
            xx_ex_h6  = xx_ex(pmax+hmax-5:pmax+hmax+i+R-6,:);
            xx_ex_h12 = xx_ex(pmax+hmax-11:pmax+hmax+i+R-12,:);
        else
            xx_ex_h1  = xx_ex(pmax+hmax-1+(i-1):pmax+hmax-1+i+R-1,:); 
            xx_ex_h3  = xx_ex(pmax+hmax-3+(i-1):pmax+hmax-1+i+R-3,:);
            xx_ex_h6  = xx_ex(pmax+hmax-6+(i-1):pmax+hmax-1+i+R-6,:);
            xx_ex_h12 = xx_ex(pmax+hmax-12+(i-1):pmax+hmax-1+i+R-12,:);
        end    
    
        B_h1  = (y_lags_h1' *y_lags_h1)\y_lags_h1'*y_tar;
        B_h3  = (y_lags_h3' *y_lags_h3)\y_lags_h3'*y_tar;
        B_h6  = (y_lags_h6' *y_lags_h6)\y_lags_h6'*y_tar;
        B_h12 = (y_lags_h12'*y_lags_h12)\y_lags_h12'*y_tar;
        
        z0_h1 = y_tar - y_lags_h1 * B_h1 ;         % Residual : z0 
        z0_h3 = y_tar - y_lags_h3 * B_h3 ;         % Residual : z0 
        z0_h6 = y_tar - y_lags_h6 * B_h6 ;         % Residual : z0 
        z0_h12 = y_tar - y_lags_h12 * B_h12 ;      % Residual : z0 
    
        
        xvar_h1  = [y_lags_h1,fac1];
        xvar_h3  = [y_lags_h3,fac3];
        xvar_h6  = [y_lags_h6,fac6];
        xvar_h12 = [y_lags_h12,fac12];
        
        predx_h1  = [ones(1,1),ylag(end,1:1+seld-1),SCORE1(end,1:n_fac_h1)];
        predx_h3  = [ones(1,1),ylag(end,3:3+seld-1),SCORE3(end,1:n_fac_h3)];
        predx_h6  = [ones(1,1),ylag(end,6:6+seld-1),SCORE6(end,1:n_fac_h6)];
        predx_h12 = [ones(1,1),ylag(end,12:12+seld-1),SCORE12(end,1:n_fac_h12)];
        
        predx_fac1 = SCORE1(end,1:n_fac_h1);
        predx_fac3 = SCORE3(end,1:n_fac_h3);
        predx_fac6 = SCORE6(end,1:n_fac_h6);
        predx_fac12= SCORE12(end,1:n_fac_h12);
        %clear SCORE1 SCORE3 SCORE6 SCORE12 
        
        
    % ---------------------------------------------------------------------
    % LARS, EN, NNG Setup--------------------------------------------------
        facnorm_h1  = normalize([fac1;predx_fac1]);
        %znorm_h1  = center(z0_h1);
        znorm_h1  = (z0_h1);
        facnorm_h3  = normalize([fac3;predx_fac3]);
        %znorm_h3  = center(z0_h3);
        znorm_h3  = (z0_h3);
        facnorm_h6  = normalize([fac6;predx_fac6]);
        %znorm_h6  = center(z0_h6);
        znorm_h6  = (z0_h6);
        facnorm_h12 = normalize([fac12;predx_fac12]);
        %znorm_h12 = center(z0_h12);
        znorm_h12 = (z0_h12);
    % ---------------------------------------------------------------------

    pred_far(i,1:length(predx_h1), 1) = predx_h1;
    pred_far(i,1:length(predx_h3), 2) = predx_h3;
    pred_far(i,1:length(predx_h6), 3) = predx_h6;
    pred_far(i,1:length(predx_h12),4) = predx_h12;

    % Saving the predictors for AR terms
    pred_ar(i,1:length(ylag(end, 1: 1+seld-1))+1,1) = [1,ylag(end,1: 1+seld-1)];
    pred_ar(i,1:length(ylag(end, 3: 3+seld-1))+1,2) = [1,ylag(end,3: 3+seld-1)];
    pred_ar(i,1:length(ylag(end, 6: 6+seld-1))+1,3) = [1,ylag(end,6: 6+seld-1)];
    pred_ar(i,1:length(ylag(end,12:12+seld-1))+1,4) = [1,ylag(end,12:12+seld-1)];
    
    
% -------------------------------------------------------------------------        
% Starting Main Program ( Different Forecating Methods )         
% -------------------------------------------------------------------------
        if mc(1) == 1
            % [1] Autoregressive
            predx_ar_h1  = [ones(1,1),ylag(end,1:1+seld-1)];
            predx_ar_h3  = [ones(1,1),ylag(end,3:3+seld-1)];
            predx_ar_h6  = [ones(1,1),ylag(end,6:6+seld-1)];
            predx_ar_h12 = [ones(1,1),ylag(end,12:12+seld-1)];
            
            yhat_ar(i,j,1) = predx_ar_h1*B_h1;
            yhat_ar(i,j,2) = predx_ar_h3*B_h3;
            yhat_ar(i,j,3) = predx_ar_h6*B_h6;
            yhat_ar(i,j,4) = predx_ar_h12*B_h12;
            
            clear xvar_ar_h1 xvar_ar_h3 xvar_ar_h6 xvar_ar_h12 %predx_ar_h1 predx_ar_h3 predx_ar_h6 predx_ar_h12
            clear beta_ar_h1 beta_ar_h3 beta_ar_h6 beta_ar_h12
        end
% -------------------------------------------------------------------------            
        if mc(2) == 1
            % [2] ARX Model
            choose = 6;
            %[vec_h1_att,ICvec_h1_att,S_F_h1_att] = IC_OLS2(y_tar,y_lags_h1,xx_ex_h1(1:rows(xx_h1)-1,:),choose,IC_tar);
            %[vec_h3_att,ICvec_h3_att,S_F_h3_att] = IC_OLS2(y_tar,y_lags_h3,xx_ex_h3(1:rows(xx_h3)-1,:),choose,IC_tar);
            %[vec_h6_att,ICvec_h6_att,S_F_h6_att] = IC_OLS2(y_tar,y_lags_h6,xx_ex_h6(1:rows(xx_h6)-1,:),choose,IC_tar);
            %[vec_h12_att,ICvec_h12_att,S_F_h12_att] = IC_OLS2(y_tar,y_lags_h12,xx_ex_h12(1:rows(xx_h12)-1,:),choose,IC_tar);
            [vec_h1_att,ICvec_h1_att,S_F_h1_att] = IC_OLS(y_tar,y_lags_h1,xx_ex_h1(1:rows(xx_h1)-1,:),choose,IC_tar);
            [vec_h3_att,ICvec_h3_att,S_F_h3_att] = IC_OLS(y_tar,y_lags_h3,xx_ex_h3(1:rows(xx_h3)-1,:),choose,IC_tar);
            [vec_h6_att,ICvec_h6_att,S_F_h6_att] = IC_OLS(y_tar,y_lags_h6,xx_ex_h6(1:rows(xx_h6)-1,:),choose,IC_tar);
            [vec_h12_att,ICvec_h12_att,S_F_h12_att] = IC_OLS(y_tar,y_lags_h12,xx_ex_h12(1:rows(xx_h12)-1,:),choose,IC_tar);
            
            vec_h1_att(vec_h1_att==0)=[];
            vec_h3_att(vec_h3_att==0)=[];
            vec_h6_att(vec_h6_att==0)=[];
            vec_h12_att(vec_h12_att==0)=[];
            
            xvar_arx_h1 = [y_lags_h1,xx_ex_h1(1:end-1,vec_h1_att)];
            xvar_arx_h3 = [y_lags_h3,xx_ex_h3(1:end-1,vec_h3_att)];
            xvar_arx_h6 = [y_lags_h6,xx_ex_h6(1:end-1,vec_h6_att)];
            xvar_arx_h12 = [y_lags_h12,xx_ex_h12(1:end-1,vec_h12_att)];
            
            beta_arx_h1 = (xvar_arx_h1'*xvar_arx_h1)\xvar_arx_h1'*y_tar;
            beta_arx_h3 = (xvar_arx_h3'*xvar_arx_h3)\xvar_arx_h3'*y_tar;
            beta_arx_h6 = (xvar_arx_h6'*xvar_arx_h6)\xvar_arx_h6'*y_tar;
            beta_arx_h12= (xvar_arx_h12'*xvar_arx_h12)\xvar_arx_h12'*y_tar;
            
            predx_arx_h1  = [1,ylag(end,1:1+seld-1),xx_ex_h1(end,vec_h1_att)];
            predx_arx_h3  = [1,ylag(end,3:3+seld-1),xx_ex_h3(end,vec_h3_att)];
            predx_arx_h6  = [1,ylag(end,6:6+seld-1),xx_ex_h6(end,vec_h6_att)];
            predx_arx_h12 = [1,ylag(end,12:12+seld-1),xx_ex_h12(end,vec_h12_att)];
            
            yhat_ols(i,j,1) = predx_arx_h1*beta_arx_h1;
            yhat_ols(i,j,2) = predx_arx_h3*beta_arx_h3;
            yhat_ols(i,j,3) = predx_arx_h6*beta_arx_h6;
            yhat_ols(i,j,4) = predx_arx_h12*beta_arx_h12;

            clear predx_arx_h1 predx_arx_h3 predx_arx_h6 predx_arx_h12
            clear beta_arx_h1 beta_arx_h3 beta_arx_h6 beta_arx_h12
            clear vec_h1_att vec_h3_att vec_h6_att vec_h12_att
            clear vec_h1 ICvec_h1 S_F_h1 vec_h3 ICvec_h3 S_F_h3 vec_h6 ICvec_h6 S_F_h6 vec_h12 ICvec_h12 S_F_h12
        end
% -------------------------------------------------------------------------            
        if mc(3) == 1
            % [3] CADL
            if rero == 1
                xx3 = xx_ex(1:i+R+hmax+pmax-2,:);            
            else
                xx3 = xx_ex(i:i+R+hmax+pmax-2,:);            
            end
            
            %[beta_CADL_h1, yhat_CADL_h1, predx_adl_h1] = CBADL2(y_tar,xx3,ylag,y_lags_h1(:,2:end),seld,pmax,hmax,1);
            %[beta_CADL_h3, yhat_CADL_h3, predx_adl_h3] = CBADL2(y_tar,xx3,ylag,y_lags_h3(:,2:end),seld,pmax,hmax,3);
            %[beta_CADL_h6, yhat_CADL_h6, predx_adl_h6] = CBADL2(y_tar,xx3,ylag,y_lags_h6(:,2:end),seld,pmax,hmax,6);
            %[beta_CADL_h12,yhat_CADL_h12,predx_adl_h12]= CBADL2(y_tar,xx3,ylag,y_lags_h12(:,2:end),seld,pmax,hmax,12);
            [beta_CADL_h1,yhat_CADL_h1]   = CBADL(y_tar,xx3,ylag,y_lags_h1(:,2:end),seld,pmax,hmax,1);
            [beta_CADL_h3,yhat_CADL_h3]   = CBADL(y_tar,xx3,ylag,y_lags_h3(:,2:end),seld,pmax,hmax,3);
            [beta_CADL_h6,yhat_CADL_h6]   = CBADL(y_tar,xx3,ylag,y_lags_h6(:,2:end),seld,pmax,hmax,6);
            [beta_CADL_h12,yhat_CADL_h12] = CBADL(y_tar,xx3,ylag,y_lags_h12(:,2:end),seld,pmax,hmax,12);
            
            yhat_CADL(i,j,1) = yhat_CADL_h1;
            yhat_CADL(i,j,2) = yhat_CADL_h3;
            yhat_CADL(i,j,3) = yhat_CADL_h6;
            yhat_CADL(i,j,4) = yhat_CADL_h12;
             
            clear yhat_CADL_h1 yhat_CADL_h3 yhat_CADL_h6 yhat_CADL_h12
            clear beta_CADL_h1 beta_CADL_h3 beta_CADL_h6 beta_CADL_h12
            clear pred_adl_h1 pred_adl_h3 pred_adl_h6 pred_adl_h12
        end
% -------------------------------------------------------------------------            
        if mc(4) == 1
            % [4] Principal Component Regression
        
            pcrfac1 = [ones(rows(fac1),1),fac1];
            pcrfac3 = [ones(rows(fac3),1),fac3];
            pcrfac6 = [ones(rows(fac6),1),fac6];
            pcrfac12= [ones(rows(fac12),1),fac12];
            
            beta_pcr_h1  = (pcrfac1'*pcrfac1)\pcrfac1'*y_tar;
            beta_pcr_h3  = (pcrfac3'*pcrfac3)\pcrfac3'*y_tar;
            beta_pcr_h6  = (pcrfac6'*pcrfac6)\pcrfac6'*y_tar;
            beta_pcr_h12 = (pcrfac12'*pcrfac12)\pcrfac12'*y_tar;
            
            yhat_pcr(i,j,1) = [ones(1,1),predx_fac1]*beta_pcr_h1;
            yhat_pcr(i,j,2) = [ones(1,1),predx_fac3]*beta_pcr_h3;    
            yhat_pcr(i,j,3) = [ones(1,1),predx_fac6]*beta_pcr_h6;    
            yhat_pcr(i,j,4) = [ones(1,1),predx_fac12]*beta_pcr_h12;                

            clear beta_pcr_h1 beta_pcr_h3 beta_pcr_h6 beta_pcr_h12
            clear pcr_fac1 pcr_fac3 pcr_fac6 pcr_fac12
        end
% -------------------------------------------------------------------------
        if mc(5) == 1
            % [5] Factor Augmented AR
            beta_faar_h1 = (xvar_h1'*xvar_h1)\xvar_h1'*y_tar;
            beta_faar_h3 = (xvar_h3'*xvar_h3)\xvar_h3'*y_tar;
            beta_faar_h6 = (xvar_h6'*xvar_h6)\xvar_h6'*y_tar;
            beta_faar_h12= (xvar_h12'*xvar_h12)\xvar_h12'*y_tar;

            yhat_faar(i,j,1) = predx_h1*beta_faar_h1;    
            yhat_faar(i,j,2) = predx_h3*beta_faar_h3;    
            yhat_faar(i,j,3) = predx_h6*beta_faar_h6;    
            yhat_faar(i,j,4) = predx_h12*beta_faar_h12;    
            
            clear beta_faar_h1 beta_faar_h3 beta_faar_h6 beta_faar_h12
        end
% -------------------------------------------------------------------------
        if mc(6) == 1
            % [6] Bagging
            
            [yhat_bag_t_h1,qq,qqq,beta_bag1]  = bagging_shrink2(y_tar,xvar_h1,seld,fac1,predx_fac1,[ones(1,1),ylag(end,1:1+seld-1)],c);
            [yhat_bag_t_h3,qq,qqq,beta_bag3]  = bagging_shrink2(y_tar,xvar_h3,seld,fac3,predx_fac3,[ones(1,1),ylag(end,3:3+seld-1)],c);
            [yhat_bag_t_h6,qq,qqq,beta_bag6]  = bagging_shrink2(y_tar,xvar_h6,seld,fac6,predx_fac6,[ones(1,1),ylag(end,6:6+seld-1)],c);
            [yhat_bag_t_h12,qq,qqq,beta_bag12]= bagging_shrink2(y_tar,xvar_h12,seld,fac12,predx_fac12,[ones(1,1),ylag(end,12:12+seld-1)],c);
            
            yhat_bag(i,j,1) = yhat_bag_t_h1;
            yhat_bag(i,j,2) = yhat_bag_t_h3;
            yhat_bag(i,j,3) = yhat_bag_t_h6;
            yhat_bag(i,j,4) = yhat_bag_t_h12;
            clear yhat_bag_t_h1 yhat_bag_t_h3 yhat_bag_t_h6 yhat_bag_t_h12 lamda pac_hat
        end
% -------------------------------------------------------------------------
        if mc(7) == 1
        % [7] Component Boosting 
        
        %[PHI,beta,IC,beta_IC_h1]= com_boost_ic(xvar_h1,y_tar,.5,M);
        %[PHI,beta,IC,beta_IC_h3]= com_boost_ic(xvar_h3,y_tar,.5,M);
        %[PHI,beta,IC,beta_IC_h6]= com_boost_ic(xvar_h6,y_tar,.5,M);
        %[PHI,beta,IC,beta_IC_h12]= com_boost_ic(xvar_h12,y_tar,.5,M);
        
        [qq,qqq,qqqq,beta_IC_h1] = com_boost_ic(fac1,z0_h1,.5,M);
        [qq,qqq,qqqq,beta_IC_h3] = com_boost_ic(fac3,z0_h3,.5,M);
        [qq,qqq,qqqq,beta_IC_h6] = com_boost_ic(fac6,z0_h6,.5,M);
        [PHI,beta,IC,beta_IC_h12]= com_boost_ic(fac12,z0_h12,.5,M);
        
        yhat_cbst(i,j,1) = predx_ar_h1*B_h1 + predx_fac1 * beta_IC_h1;    
        yhat_cbst(i,j,2) = predx_ar_h3*B_h3 + predx_fac3 * beta_IC_h3;    
        yhat_cbst(i,j,3) = predx_ar_h6*B_h6 + predx_fac6 * beta_IC_h6;    
        yhat_cbst(i,j,4) = predx_ar_h12*B_h12+ predx_fac12* beta_IC_h12;    
        clear PHI beta IC beta_IC_h1 beta_IC_h3 beta_IC_h6 beta_IC_h12
        end
% -------------------------------------------------------------------------
        if mc(8) == 1
        % [8] Bayesian Model Averaging I ( g = 1/n)
        
        opt1 = 0; opt2 = 1; opt3 = 1;        
        
        beta_bma1_h1  = bma_koop(nburn,nkeep,z0_h1,fac1,opt1,opt2,opt3);
        beta_bma1_h3  = bma_koop(nburn,nkeep,z0_h3,fac3,opt1,opt2,opt3);
        beta_bma1_h6  = bma_koop(nburn,nkeep,z0_h6,fac6,opt1,opt2,opt3);
        beta_bma1_h12 = bma_koop(nburn,nkeep,z0_h12,fac12,opt1,opt2,opt3);

        yhat_bma1(i,j,1) = predx_ar_h1*B_h1 + predx_fac1 * beta_bma1_h1;    
        yhat_bma1(i,j,2) = predx_ar_h3*B_h3 + predx_fac3 * beta_bma1_h3;    
        yhat_bma1(i,j,3) = predx_ar_h6*B_h6 + predx_fac6 * beta_bma1_h6;    
        yhat_bma1(i,j,4) = predx_ar_h12*B_h12 + predx_fac12 * beta_bma1_h12;    
        end
% -------------------------------------------------------------------------
        if mc(9) == 1
        % [9] Bayesian Model Averaging I ( g = 1/(k^2))
        
        opt1 = 1; opt2 = 1; opt3 = 1;    
        beta_bma2_h1 = bma_koop(nburn,nkeep,z0_h1,fac1,opt1,opt2,opt3);
        beta_bma2_h3 = bma_koop(nburn,nkeep,z0_h3,fac3,opt1,opt2,opt3);
        beta_bma2_h6 = bma_koop(nburn,nkeep,z0_h6,fac6,opt1,opt2,opt3);
        beta_bma2_h12= bma_koop(nburn,nkeep,z0_h12,fac12,opt1,opt2,opt3);

        yhat_bma2(i,j,1) = predx_ar_h1*B_h1 + predx_fac1 * beta_bma2_h1;    
        yhat_bma2(i,j,2) = predx_ar_h3*B_h3 + predx_fac3 * beta_bma2_h3;    
        yhat_bma2(i,j,3) = predx_ar_h6*B_h6 + predx_fac6 * beta_bma2_h6;    
        yhat_bma2(i,j,4) = predx_ar_h12*B_h12 + predx_fac12 * beta_bma2_h12;    
        
        end
% -------------------------------------------------------------------------
        if mc(10) == 1
        % [10] Ridge Regression
        re_h1 = ridge(z0_h1,fac1);
        re_h3 = ridge(z0_h3,fac3);
        re_h6 = ridge(z0_h6,fac6);
        re_h12 = ridge(z0_h12,fac12);
        
        beta_ridge_h1 = re_h1.beta;
        beta_ridge_h3 = re_h3.beta;
        beta_ridge_h6 = re_h6.beta;
        beta_ridge_h12 = re_h12.beta;
        
        yhat_ridge(i,j,1) = predx_ar_h1*B_h1 + predx_fac1*beta_ridge_h1;    
        yhat_ridge(i,j,2) = predx_ar_h3*B_h3 + predx_fac3*beta_ridge_h3;    
        yhat_ridge(i,j,3) = predx_ar_h6*B_h6 + predx_fac6*beta_ridge_h6;    
        yhat_ridge(i,j,4) = predx_ar_h12*B_h12+predx_fac12*beta_ridge_h12;
        clear beta_ridge_h1 beta_ridge_h3 beta_ridge_h6 beta_ridge_h12
        
        end
% -------------------------------------------------------------------------            
        if mc(11) == 1
        % [11] Least Angle Regression
        
        %[w_h1, B_h1, C, sbc, fpe, th]=arfit(y_tar , seld, seld, 'zero');
        %[w_h3, B_h3, C, sbc, fpe, th]=arfit(y_tar , seld, seld, 'zero');
        %[w_h6, B_h6, C, sbc, fpe, th]=arfit(y_tar , seld, seld, 'zero');
        %[w_h12, B_h12, C, sbc, fpe, th]=arfit(y_tar , seld, seld, 'zero');

        % Step 1. Put AR residual to lars on factors
        
        beta_tar1 = lars(facnorm_h1(1:end-1,:), znorm_h1,'lars',0,0,[],1);
        beta_tar3 = lars(facnorm_h3(1:end-1,:), znorm_h3,'lars',0,0,[],1);
        beta_tar6 = lars(facnorm_h6(1:end-1,:), znorm_h6,'lars',0,0,[],1);
        beta_tar12= lars(facnorm_h12(1:end-1,:), znorm_h12,'lars',0,0,[],1);
        
        beta_tar1  = real(beta_tar1);
        beta_tar3  = real(beta_tar3);
        beta_tar6  = real(beta_tar6);
        beta_tar12 = real(beta_tar12);
        
        %beta_tar1 = lars(fac1, z0_h1,'lasso',0,0,[],1);
        %beta_tar3 = lars(fac3, z0_h3,'lasso',0,0,[],1);
        %beta_tar6 = lars(fac6, z0_h6,'lasso',0,0,[],1);
        %beta_tar12 = lars(fac12, z0_h12,'lasso',0,0,[],1);
        
        IC_h1 = zeros(n_fac_h1,1);
        IC_h3 = zeros(n_fac_h3,1);
        IC_h6 = zeros(n_fac_h6,1);
        IC_h12 = zeros(n_fac_h12,1);
        
        for f = 1: 1: n_fac_h1
            sig2_h1  = (z0_h1  - fac1  * beta_tar1(f+1,:)')' *(z0_h1  - fac1  * beta_tar1(f+1,:)');
            IC_h1(f,1)  = log(sig2_h1)  + ( cols(beta_tar1)  * log(rows(z0_h1) )) / rows(z0_h1);
        end
        for f = 1: 1: n_fac_h3
            sig2_h3  = (z0_h3  - fac3  * beta_tar3(f+1,:)')' *(z0_h3  - fac3  * beta_tar3(f+1,:)');
            IC_h3(f,1)  = log(sig2_h3)  + ( cols(beta_tar3)  * log(rows(z0_h3) )) / rows(z0_h3);
        end
        for f = 1: 1: n_fac_h6
            sig2_h6  = (z0_h6  - fac6  * beta_tar6(f+1,:)')' *(z0_h6  - fac6  * beta_tar6(f+1,:)');
            IC_h6(f,1)  = log(sig2_h6)  + ( cols(beta_tar6)  * log(rows(z0_h6) )) / rows(z0_h6);
        end
        for f = 1: 1: n_fac_h12
            sig2_h12 = (z0_h12 - fac12 * beta_tar12(f+1,:)')'*(z0_h12 - fac12 * beta_tar12(f+1,:)');
            IC_h12(f,1) = log(sig2_h12) + ( cols(beta_tar12) * log(rows(z0_h12) )) / rows(z0_h12);
        end
        
        [val_h1,IC_i_h1] = min(IC_h1);
        [val_h3,IC_i_h3] = min(IC_h3);
        [val_h6,IC_i_h6] = min(IC_h6);
        [val_h12,IC_i_h12] = min(IC_h12);
        
        beta_IC_h1  = beta_tar1(IC_i_h1+1,:);      % Finding beta by BIC
        beta_IC_h3  = beta_tar3(IC_i_h3+1,:);      % Finding beta by BIC
        beta_IC_h6  = beta_tar6(IC_i_h6+1,:);      % Finding beta by BIC
        beta_IC_h12 = beta_tar12(IC_i_h12+1,:);      % Finding beta by BIC
        
        beta_lars_h1 = [B_h1;beta_IC_h1'];           % Put together 
        beta_lars_h3 = [B_h3;beta_IC_h3'];           % Put together 
        beta_lars_h6 = [B_h6;beta_IC_h6'];           % Put together 
        beta_lars_h12= [B_h12;beta_IC_h12'];           % Put together 
     
        %yhat_lars(i,j,1) = mean(z0_h1) + [ones(1,1),(ylag(end,1:1+seld-1)-mean(z0_h1)),facnorm_h1(end,:)] * beta_lars_h1;
        %yhat_lars(i,j,2) = mean(z0_h3) + [ones(1,1),(ylag(end,3:3+seld-1)-mean(z0_h3)),facnorm_h3(end,:)] * beta_lars_h3;
        %yhat_lars(i,j,3) = mean(z0_h6) + [ones(1,1),(ylag(end,6:6+seld-1)-mean(z0_h6)),facnorm_h6(end,:)] * beta_lars_h6;
        %yhat_lars(i,j,4) = mean(z0_h12)+ [ones(1,1),(ylag(end,12:12+seld-1)-mean(z0_h12)),facnorm_h12(end,:)]* beta_lars_h12;
        
        yhat_lars(i,j,1) = [1,ylag(end,1 : 1+seld-1),facnorm_h1(end,:) ] * beta_lars_h1;
        yhat_lars(i,j,2) = [1,ylag(end,3 : 3+seld-1),facnorm_h3(end,:) ] * beta_lars_h3;
        yhat_lars(i,j,3) = [1,ylag(end,6 : 6+seld-1),facnorm_h6(end,:) ] * beta_lars_h6;
        yhat_lars(i,j,4) = [1,ylag(end,12:12+seld-1),facnorm_h12(end,:)] * beta_lars_h12;

        pred_nfr(i,1:length([ylag(end,1 : 1+seld-1),facnorm_h1(end,:)] )+1,1) = [1,ylag(end,1 : 1+seld-1),facnorm_h1(end,:) ];
        pred_nfr(i,1:length([ylag(end,3 : 3+seld-1),facnorm_h3(end,:)] )+1,2) = [1,ylag(end,3 : 3+seld-1),facnorm_h3(end,:) ];
        pred_nfr(i,1:length([ylag(end,6 : 6+seld-1),facnorm_h6(end,:)] )+1,3) = [1,ylag(end,6 : 6+seld-1),facnorm_h6(end,:) ];
        pred_nfr(i,1:length([ylag(end,12:12+seld-1),facnorm_h12(end,:)])+1,4) = [1,ylag(end,12:12+seld-1),facnorm_h12(end,:)];
        
        clear beta_lars_h1 beta_lars_h3 beta_lars_h6 beta_lars_h12
        end
% -------------------------------------------------------------------------
        if mc(12) == 1
        % [12] Elastic Net
        
        % Step 1. Put AR residual to lars on factors
        
        beta1_en_h1 = larsen(facnorm_h1(1:end-1,:), znorm_h1,0.1,0,1);
        beta1_en_h3 = larsen(facnorm_h3(1:end-1,:), znorm_h3,0.1,0,1);
        beta1_en_h6 = larsen(facnorm_h6(1:end-1,:), znorm_h6,0.1,0,1);
        beta1_en_h12 = larsen(facnorm_h12(1:end-1,:), znorm_h12,0.1,0,1);

        beta_en_h1  = real(beta1_en_h1);
        beta_en_h3  = real(beta1_en_h3);
        beta_en_h6  = real(beta1_en_h6);
        beta_en_h12 = real(beta1_en_h12);

        IC_h1  = zeros(n_fac_h1,1);
        IC_h3  = zeros(n_fac_h3,1);
        IC_h6  = zeros(n_fac_h6,1);
        IC_h12 = zeros(n_fac_h12,1);
        
        for f = 1: 1: n_fac_h1
            sig2_h1  = (z0_h1  - fac1  * beta_en_h1(f+1,:)')' *(z0_h1  - fac1  * beta_en_h1(f+1,:)');
            IC_h1(f,1)  = log(sig2_h1)  + ( cols(beta_en_h1)  * log(rows(z0_h1) )) / rows(z0_h1);
        end
        for f = 1: 1: n_fac_h3
            sig2_h3  = (z0_h3  - fac3  * beta_en_h3(f+1,:)')' *(z0_h3  - fac3  * beta_en_h3(f+1,:)');
            IC_h3(f,1)  = log(sig2_h3)  + ( cols(beta_en_h3)  * log(rows(z0_h3) )) / rows(z0_h3);
        end
        for f = 1: 1: n_fac_h6
            sig2_h6  = (z0_h6  - fac6  * beta_en_h6(f+1,:)')' *(z0_h6  - fac6  * beta_en_h6(f+1,:)');
            IC_h6(f,1)  = log(sig2_h6)  + ( cols(beta_en_h6)  * log(rows(z0_h6) )) / rows(z0_h6);
        end
        for f = 1: 1: n_fac_h12
            sig2_h12 = (z0_h12 - fac12 * beta_en_h12(f+1,:)')'*(z0_h12 - fac12 * beta_en_h12(f+1,:)');
            IC_h12(f,1) = log(sig2_h12) + ( cols(beta_en_h12) * log(rows(z0_h12) )) / rows(z0_h12);
        end
         
        [val_h1,IC_i_h1]   = min(IC_h1);
        [val_h3,IC_i_h3]   = min(IC_h3);
        [val_h6,IC_i_h6]   = min(IC_h6);
        [val_h12,IC_i_h12] = min(IC_h12);
        
        beta_en_IC_h1  = beta1_en_h1(IC_i_h1+1,:);      % Finding beta by BIC
        beta_en_IC_h3  = beta1_en_h3(IC_i_h3+1,:);      % Finding beta by BIC
        beta_en_IC_h6  = beta1_en_h6(IC_i_h6+1,:);      % Finding beta by BIC
        beta_en_IC_h12 = beta1_en_h12(IC_i_h12+1,:);    % Finding beta by BIC
    
        beta_en_h1  = [B_h1;beta_en_IC_h1'];           % Put together 
        beta_en_h3  = [B_h3;beta_en_IC_h3'];           % Put together 
        beta_en_h6  = [B_h6;beta_en_IC_h6'];           % Put together                 
        beta_en_h12 = [B_h12;beta_en_IC_h12'];         % Put together 

        %yhat_en(i,j,1) = predx_h1 * beta_en_h1;
        %yhat_en(i,j,2) = predx_h3 * beta_en_h3;
        %yhat_en(i,j,3) = predx_h6 * beta_en_h6;
        %yhat_en(i,j,4) = predx_h12 * beta_en_h12;

        yhat_en(i,j,1) = mean(z0_h1) + [ones(1,1),(ylag(end,1:1+seld-1)-mean(z0_h1)),facnorm_h1(end,:)] * beta_en_h1;
        yhat_en(i,j,2) = mean(z0_h3) + [ones(1,1),(ylag(end,3:3+seld-1)-mean(z0_h3)),facnorm_h3(end,:)] * beta_en_h3;
        yhat_en(i,j,3) = mean(z0_h6) + [ones(1,1),(ylag(end,6:6+seld-1)-mean(z0_h6)),facnorm_h6(end,:)] * beta_en_h6;
        yhat_en(i,j,4) = mean(z0_h12)+ [ones(1,1),(ylag(end,12:12+seld-1)-mean(z0_h12)),facnorm_h12(end,:)]* beta_en_h12;
        clear beta_en_h1 beta_en_h3 beta_en_h6 beta_en_h12
        
        end
% -------------------------------------------------------------------------
        if mc(13) == 1
        % [13] Nonnegative Garrote
        
        % Step 1. Put AR residual to lars on factors
        
        [beta13_h1,qq,qqq] = nng_garotte_new(facnorm_h1(1:end-1,:), znorm_h1);
        [beta13_h3,qq,qqq] = nng_garotte_new(facnorm_h3(1:end-1,:), znorm_h3);
        [beta13_h6,qq,qqq] = nng_garotte_new(facnorm_h6(1:end-1,:), znorm_h6);
        [beta13_h12,qq,qqq]= nng_garotte_new(facnorm_h12(1:end-1,:),znorm_h12);
        
        beta_nng_h1  = [B_h1;beta13_h1];           % Put together 
        beta_nng_h3  = [B_h3;beta13_h3];           % Put together 
        beta_nng_h6  = [B_h6;beta13_h6];           % Put together 
        beta_nng_h12 = [B_h12;beta13_h12];           % Put together 
    
        %yhat_nng(i,j,1) = predx_h1 * beta_nng_h1;
        %yhat_nng(i,j,2) = predx_h3 * beta_nng_h3;
        %yhat_nng(i,j,3) = predx_h6 * beta_nng_h6;
        %yhat_nng(i,j,4) = predx_h12 * beta_nng_h12;
        
        yhat_nng(i,j,1) = mean(z0_h1) + [ones(1,1),(ylag(end,1:1+seld-1)-mean(z0_h1)),facnorm_h1(end,:)] * beta_nng_h1;
        yhat_nng(i,j,2) = mean(z0_h3) + [ones(1,1),(ylag(end,3:3+seld-1)-mean(z0_h3)),facnorm_h3(end,:)] * beta_nng_h3;
        yhat_nng(i,j,3) = mean(z0_h6) + [ones(1,1),(ylag(end,6:6+seld-1)-mean(z0_h6)),facnorm_h6(end,:)] * beta_nng_h6;
        yhat_nng(i,j,4) = mean(z0_h12)+ [ones(1,1),(ylag(end,12:12+seld-1)-mean(z0_h12)),facnorm_h12(end,:)]* beta_nng_h12;
        clear beta_nng_h1 beta_nng_h3 beta_nng_h6 beta_nng_h12

        end
% -------------------------------------------------------------------------
        
    end
    clear xx_ex
end
  
disp(' ')
if rero == 1
    disp('End of the Estimation for RECURSIVE Sample Estimation Under Specification Type 1')
else
    disp('End of the Estimation for ROLLING Sample Estimation Under Specification Type 1')
end
disp(' ')

% Result ------------------------------------------------------------------ 

Y_real = TrYvarTr(end-P+1:end,:); % Actual Value : Mar.1974~May.2009

Yhat(:,:,:,1)=yhat_ar;Yhat(:,:,:,2)=yhat_ols; 
Yhat(:,:,:,3)=yhat_CADL;Yhat(:,:,:,4)=yhat_faar; Yhat(:,:,:,5)=yhat_pcr;
Yhat(:,:,:,6)=yhat_bag; Yhat(:,:,:,7)=yhat_cbst; 
Yhat(:,:,:,8)=yhat_bma1; Yhat(:,:,:,9)=yhat_bma2;
Yhat(:,:,:,10)=yhat_ridge; Yhat(:,:,:,11)=yhat_lars; Yhat(:,:,:,12)=yhat_en; Yhat(:,:,:,13)=yhat_nng;
Yhat(:,:,:,14)=sum(Yhat(:,:,:,1:13),4)/13;

[rr cc dd kk] = size(Yhat);

MSE = zeros(rr,cc,kk,dd);
MSE_ratio = zeros(kk,cc,dd);

for h=1:1:dd
    for l = 1 : 1 : kk
        MSE(:,:,l,h) = (Yhat(:,:,h,l)-Y_real).^2;
    end
end

for h=1:1:dd
    MSE_ratio(1,:,h) = sum(MSE(:,:,1,h));
    for i = 2 : 1 : kk
        MSE_ratio(i,:,h) = sum(MSE(:,:,i,h))./sum(MSE(:,:,1,h));
    end
end

if rero == 1
    fn1=input('Specify the name of the file to store results: ','s');
    fid=fopen(fn1,'wt');
    
    fprintf(fid, '\n     Table 3. Relative Mean Square Forecast Errors: Recursive Estimation, Specification Type 1 (no lags)  \n');
    fprintf(fid, '\n                                               Panel A: Recursive, h = 1  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,1) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','ARX(SIC)', MSE_ratio(2,:,1) );
    fprintf(fid, '%s  %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Combined-ADL', MSE_ratio(3,:,1) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','FAAR', MSE_ratio(4,:,1) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','PCR', MSE_ratio(5,:,1) );
    fprintf(fid, '%s       %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Bagging', MSE_ratio(6,:,1) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(7,:,1) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(8,:,1) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(9,:,1) );
    fprintf(fid, '%s         %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Ridge', MSE_ratio(10,:,1) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(11,:,1) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(12,:,1) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(13,:,1) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(14,:,1) );    
    fprintf(fid, '\n                                                Panel B: Recursive, h = 3  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,2) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','ARX(SIC)', MSE_ratio(2,:,2) );
    fprintf(fid, '%s  %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Combined-ADL', MSE_ratio(3,:,2) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','FAAR', MSE_ratio(4,:,2) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','PCR', MSE_ratio(5,:,2) );
    fprintf(fid, '%s       %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Bagging', MSE_ratio(6,:,2) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(7,:,2) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(8,:,2) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(9,:,2) );
    fprintf(fid, '%s         %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Ridge', MSE_ratio(10,:,2) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(11,:,2) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(12,:,2) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(13,:,2) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(14,:,2) );    
    fprintf(fid, '\n                                                Panel C: Recursive, h = 12  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,4) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','ARX(SIC)', MSE_ratio(2,:,4) );
    fprintf(fid, '%s  %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Combined-ADL', MSE_ratio(3,:,4) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','FAAR', MSE_ratio(4,:,4) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','PCR', MSE_ratio(5,:,4) );
    fprintf(fid, '%s       %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Bagging', MSE_ratio(6,:,4) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(7,:,4) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(8,:,4) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(9,:,4) );
    fprintf(fid, '%s         %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Ridge', MSE_ratio(10,:,4) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(11,:,4) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(12,:,4) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(13,:,4) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(14,:,4) );    
    fclose(fid);

    save Result_SP1_Rec.mat Yhat MSE MSE_ratio;
else

    fn1=input('Specify the name of the file to store results: ','s');
    fid=fopen(fn1,'wt');
    
    fprintf(fid, '\n     Table 3-1. Relative Mean Square Forecast Errors: Rolling Estimation, Specification Type 1 (no lags)  \n');
    fprintf(fid, '\n                                               Panel A: Rolling, h = 1  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,1) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','ARX(SIC)', MSE_ratio(2,:,1) );
    fprintf(fid, '%s  %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Combined-ADL', MSE_ratio(3,:,1) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','FAAR', MSE_ratio(4,:,1) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','PCR', MSE_ratio(5,:,1) );
    fprintf(fid, '%s       %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Bagging', MSE_ratio(6,:,1) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(7,:,1) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(8,:,1) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(9,:,1) );
    fprintf(fid, '%s         %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Ridge', MSE_ratio(10,:,1) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(11,:,1) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(12,:,1) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(13,:,1) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(14,:,1) );    
    fprintf(fid, '\n                                                Panel B: Rolling, h = 3  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,2) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','ARX(SIC)', MSE_ratio(2,:,2) );
    fprintf(fid, '%s  %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Combined-ADL', MSE_ratio(3,:,2) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','FAAR', MSE_ratio(4,:,2) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','PCR', MSE_ratio(5,:,2) );
    fprintf(fid, '%s       %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Bagging', MSE_ratio(6,:,2) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(7,:,2) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(8,:,2) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(9,:,2) );
    fprintf(fid, '%s         %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Ridge', MSE_ratio(10,:,2) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(11,:,2) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(12,:,2) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(13,:,2) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(14,:,2) );    
    fprintf(fid, '\n                                                Panel C: Rolling, h = 12  \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, 'Method	      UR        PI      TB10Y     CPI      PPI      NPE      HS       IPX      M2       SNP      GDP \n');
    fprintf(fid, '-------------------------------------------------------------------------------------------------------------- \n');
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f   %1.3f    %1.3f    %1.3f    %1.3f \n','AR(SIC)', MSE_ratio(1,:,4) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','ARX(SIC)', MSE_ratio(2,:,4) );
    fprintf(fid, '%s  %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Combined-ADL', MSE_ratio(3,:,4) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','FAAR', MSE_ratio(4,:,4) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','PCR', MSE_ratio(5,:,4) );
    fprintf(fid, '%s       %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Bagging', MSE_ratio(6,:,4) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','C-Boosting', MSE_ratio(7,:,4) );
    fprintf(fid, '%s      %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/T)', MSE_ratio(8,:,4) );
    fprintf(fid, '%s    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','BMA(1/N^2)', MSE_ratio(9,:,4) );
    fprintf(fid, '%s         %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Ridge', MSE_ratio(10,:,4) );
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','LARS', MSE_ratio(11,:,4) );
    fprintf(fid, '%s            %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','EN', MSE_ratio(12,:,4) );
    fprintf(fid, '%s           %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','NNG', MSE_ratio(13,:,4) );    
    fprintf(fid, '%s          %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f    %1.3f \n','Mean', MSE_ratio(14,:,4) );    
    fclose(fid);

    save Result_SP1_Rol.mat Yhat MSE MSE_ratio
end
