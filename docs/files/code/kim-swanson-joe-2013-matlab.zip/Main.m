% Main Program to replicate the results in 
% Hyun Hak Kim and Norman R. Swanson
% "Forecasting Financial and Macroeconomic Variables Using Data Reduction 
% Methods: New Empirical Evidence", Journal of Econometrics, 2013
% 
% -------------------------------------------------------------------------
% 
% # Many of codes are using Econometric Toolbox by James P. LeSage
%   You can get these codes from www.spatial-econometrics.com 
% 
% -------------------------------------------------------------------------
%
% 1. Table 3 to 6 are summarized from the result of following programs. 
%    Once you run the program, you can choose 
% 
% SP1.m
% 
% -> By running this program, you can get the result of 14 forecasting methods 
%    under Specification Type 1 without lags with factors estimated by PCA. 
%    By assigning output file, you can get the Table 3 at the end.
% 
% SP1_L.m
% 
% -> This gives you the result of Specification Type 1 with lags, with factors 
%    estimated by PCA, like Table 4. 
% 
% SP2.m
% 
% -> By same way, you can get the result like Table 5 by running this program.  
% 
% SP3.m 
% 
% -> By same way, you can get the result like Table 6 by running this program.  
% 
% 2. Tables 7-8 are reproduced using the result in Table 3 to 6. 
%    Therefore, you need to save the result of Table 3 to 6 
%
% -------------------------------------------------------------------------
% See each program for details in implemnting the program. 
disp(' ')
disp('First, you need to select the specification type you want to run')
disp(' ')
disp('1 for Specification Type 1 without lags')
disp('2 for Specification Type 1 with lags')
disp('3 for Specification Type 2')
disp('4 for Specification Type 3')
disp(' ')
spec_cho = input('Select the Specification Type you want to run - ');
if spec_cho==1
    run SP1
elseif spec_cho==2
    run SP1L
elseif spec_cho==3
    run SP2
elseif spec_cho==4
    run SP3
else
    error('WARNING!! You should input numbers among 1 through 4 for selecting specification types')
end




temp=open('temp.mat')